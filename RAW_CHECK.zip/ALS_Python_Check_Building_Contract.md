# ALS‑Driven Python Validation Architecture

This document defines **how a Python system derives validation checks from an ALS Excel file**, including exactly **which sheets and columns are authoritative**, which are ignored, and how each sheet contributes to automated QC logic.

---

## 1. Design Principle

> The Python system never blindly consumes all ALS sheets or columns.
> It uses a **strict whitelist‑based contract** that maps **specific ALS sheets and columns** to **specific classes of validation checks**.

This guarantees:
- Deterministic behavior
- No false‑positive noise
- Audit‑ready traceability

---

## 2. Sheet Responsibility Matrix

| ALS Sheet | Purpose in Python | Check Types Generated |
|---------|------------------|----------------------|
| Forms | Structural expectations | Form presence, visit dependency, severity escalation |
| Fields | Field‑level rules | Required, format, range, CT, partial dates |
| Checks | Explicit logic | Conditional, cross‑form, temporal rules |
| Custom Functions | Behavioral intent | Derived consistency, dependency enforcement |
| Dictionaries | Reference only | Controlled terminology validation |
| Notes / Other | Ignored | Not used for automation |

---

## 3. FORMS Sheet

### Purpose
Defines **what forms must exist**, **when**, and **how critical they are**.

### Columns Used by Python
- FormOID
- DraftFormActive
- IsLog
- LinkFolderOID / Visit linkage
- Critical CRF for SDV?
- Critical – Safety
- Critical – Eligibility
- Critical – Consent
- Core/TA
- Protocol Version / Amendment

### Columns Ignored
- Orientation (portrait/landscape)
- View / Entry restrictions
- Wiki links, reviewer names
- UI‑only metadata

### Check Types Generated
- Required form missing
- Log form without records
- Visit present but form absent
- Severity escalation for safety / eligibility

---

## 4. FIELDS Sheet

### Purpose
Generates **80‑85% of automatic checks**.

### Columns Used

#### Requiredness & Presence
- IsRequired
- IsLog
- Field Hidden?
- Defaulted / Derived?

#### Format & Type
- DataFormat
- EproFormat
- ControlType
- Partial date indicators

#### Controlled Terminology
- DataDictionaryName
- CodingDictionary

#### Numeric Range
- LowerRange
- UpperRange
- UnitDictionaryName

#### Severity Classification (non‑rule‑creating)
- Critical Data
- Critical – Safety
- Critical – Endpoint
- Critical – Eligibility

### Columns Ignored
- Help text
- SAS label comments
- Free‑text implementation notes

### Check Types Generated
- Missing required field
- Invalid date / time
- Invalid CT value
- Out‑of‑range numeric |

---

## 5. CHECKS Sheet

### Purpose
Defines **explicit validation rules** that cannot be inferred.

### Required Columns
- CheckID
- Trigger Form
- Trigger Field
- Operator
- Trigger Value
- Target Form
- Target Field
- Expected Condition
- Severity
- Active Flag

### Check Types Generated
- Conditional requiredness
- Cross‑form dependencies
- Temporal logic checks
- Protocol compliance rules

### Columns Ignored
- Free‑text explanations beyond message template

---

## 6. CUSTOM FUNCTIONS Sheet

### Purpose
Defines **expected behavior**, not actual data derivation.

> Python interprets intent — it does NOT execute CF logic.

### Columns Used
- CF_ID
- CF_Type (Derive / Default / Dependency)
- Input Fields
- Output Field / Form
- Logic Description
- Active Flag

### How CFs Influence Checks

| CF Type | Effect in Python |
|-------|----------------|
| Derived | Suppress missing checks + consistency check |
| Defaulted | Suppress missing checks |
| Dependency | Expect downstream form / record |

### Columns Ignored
- UI behavior
- Execution syntax

---

## 7. Rule Construction Flow

```
Load ALS
↓
Filter sheets by role
↓
Whitelist columns
↓
Build Form Rule Registry
↓
Build Field Rule Registry
↓
Load Check Rules
↓
Apply CF Expectations
↓
Merge into Unified Rule Catalog
```

---

## 8. Why This Prevents Over‑Checking

- Derived fields are excluded from required checks
- Hidden fields are ignored
- Only explicit columns drive logic
- Checks and CFs override generic rules

Result:
- High signal‑to‑noise QC
- Reviewer trust
- Explainable validation output

---

## 9. Summary

- **Python knows what to check based on sheet role + column whitelist**
- **Not all ALS content is executable**
- **Checks and CFs complete the logic picture**
- **Every issue is traceable to an ALS source**

This document forms a **validation contract** between ALS authors and automation systems.
