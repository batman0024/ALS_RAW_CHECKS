# Developer Onboarding Guide

## 1. Mental Model

Think of ALS as a **contract**, not documentation.
Your job is **to enforce intent, not reimplement EDC logic**.

## 2. Execution Order
1. Parse ALS (only required sheets & columns)
2. Build rule registries
3. Read datasets
4. Apply CF expectations
5. Execute checks
6. Emit issues

## 3. Key Principles
- Never hardcode domain rules
- Never evaluate free text
- Always trace every issue to ALS source
- CFs define expectation, not computation

## 4. Adding New Checks
- Prefer `Checks` sheet
- Only extend `Fields` logic if column is structured

## 5. Review Safety
- All checks must explain `Observed vs Expected`
- Severity must be deterministic
