# ALS-Driven QC Platform

This repository contains a production-grade framework for building **ALS-driven clinical trial QC automation**, including figure QC, dataset validation, and reviewer workflows.

## Repository Purpose
- Translate ALS specifications into executable QC logic
- Generate deterministic, explainable data issues
- Support Streamlit-based review and export

## Key Documents
- `DEVELOPER_ONBOARDING.md` – How the system works end-to-end
- `RULE_ID_TAXONOMY.md` – Rule naming, classes, and examples
- `als_rule_schema.json` – Machine-validated schema for rule generation

## Intended Audience
- Clinical programmers
- Data standards engineers
- Python / Streamlit developers
- QA / Validation teams
