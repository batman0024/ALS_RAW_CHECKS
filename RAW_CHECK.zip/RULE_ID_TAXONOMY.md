# Rule ID Taxonomy

Rule IDs are mandatory and traceable.

## Format
```
<DOMAIN>_<CLASS>_<NNN>
```

## Classes
- FRM – Form-level
- FLD – Field-level
- CTL – Controlled terminology
- RNG – Range
- TMP – Temporal
- XFR – Cross-form
- DER – Derived consistency
- DEP – Dependency

## Examples
- AE_FLD_001 – Required AE start date missing
- LB_RNG_005 – Lab value outside range
- DM_DER_002 – Age derivation mismatch
- AE_DEP_010 – SAE form missing after AESER=Yes
