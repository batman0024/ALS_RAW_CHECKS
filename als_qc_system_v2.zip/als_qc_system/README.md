# ALS-Driven Clinical Data QC System v2.0

Deterministic, explainable, audit-ready quality control for clinical trial raw data.

## Stats (from raw_details.xlsx / Gilead GLIB Standards)
- **1,649 active rules** generated automatically
- **97 codelists** loaded from DataDictionaryEntries
- **988 edit checks** parsed and classified from the Checks sheet
- **328 custom functions** parsed (query messages extracted; source never executed)
- **44 unit tests** — 100% passing

## Quick Start

```bash
pip install -r requirements.txt
streamlit run app/main.py
```

## Python API

```python
from core.als_parser     import ALSParser
from core.dataset_loader import DatasetLoader
from core.rule_catalog   import RuleCatalog
from qc.engine           import QCEngine
from qc.exporter         import IssueExporter

als      = ALSParser("raw_details.xlsx").parse()
loader   = DatasetLoader()
datasets = loader.load_directory("path/to/sas/data/")   # SAS7BDAT, XPT, CSV, Excel
catalog  = RuleCatalog().build(als=als)
issues   = QCEngine(catalog, als_parser=als).run(datasets)
IssueExporter(issues, catalog_df=catalog.to_dataframe()).to_excel("qc_report.xlsx")
```

## Rule Classes Generated

| Class | Source | Description |
|-------|--------|-------------|
| FRM   | Forms sheet | Form presence (Critical for consent/safety/eligibility forms) |
| FLD   | Fields sheet | Required field missing; duplicate key detection |
| CTL   | DataDictionaryEntries | Value-Level Metadata (VLM) — exact codelist check |
| RNG   | Fields sheet | Hard range (Major) and NC soft range (Minor) |
| TMP   | Fields + Checks | Date comparisons; future dates; RFSTDTC violations |
| XFR   | Checks + CustomFunctions | Cross-form subject-level dependency |
| DEP   | Checks sheet | Conditional field presence |
| DER   | — | Derived output consistency |

## Tests

```bash
python -m unittest discover -s tests -v
# Ran 44 tests in 0.06s — OK
```

## Documentation

Open `docs/index.html` in a browser for full technical documentation.
