"""
app/main.py
===========
ALS-Driven Clinical Data QC System — Streamlit UI.

Tabs:
  📊 Dashboard   — summary stats, charts
  🚨 Issues      — filterable issue table
  📋 Rule Catalog — all generated rules
  📤 Export      — one-click downloads
"""

from __future__ import annotations
import logging
import sys
import tempfile
from pathlib import Path

import pandas as pd
import streamlit as st

# ── path setup ────────────────────────────────────────────────────────────────
ROOT = Path(__file__).parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from core.als_parser     import ALSParser
from core.dataset_loader import DatasetLoader
from core.rule_catalog   import RuleCatalog
from qc.engine           import QCEngine
from qc.exporter         import IssueExporter

logging.basicConfig(level=logging.INFO,
                    format="%(levelname)s %(name)s: %(message)s")

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="ALS Clinical QC",
    page_icon="🧬",
    layout="wide",
)

# ── Minimal CSS ───────────────────────────────────────────────────────────────
st.markdown("""
<style>
.metric-card {
    background: #1e2a3a;
    border-radius: 8px;
    padding: 1rem 1.5rem;
    border-left: 4px solid #4a9eff;
}
.sev-critical { color: #ff6b6b; font-weight: 700; }
.sev-major    { color: #ffa94d; font-weight: 700; }
.sev-minor    { color: #ffd43b; font-weight: 700; }
.sev-info     { color: #74c0fc; font-weight: 700; }
</style>
""", unsafe_allow_html=True)


# ── Session state helpers ─────────────────────────────────────────────────────
def _ss() -> dict:
    return st.session_state


def _reset():
    for k in list(st.session_state.keys()):
        del st.session_state[k]


# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.title("🧬 ALS Clinical QC")
    st.caption("v2.0 · Gilead-ready")
    st.divider()

    st.subheader("1. ALS Workbook (optional)")
    als_file = st.file_uploader(
        "raw_details.xlsx or any ALS",
        type=["xlsx", "xls"],
        key="als_upload",
    )

    st.subheader("2. Raw Datasets")
    st.caption("SAS7BDAT, XPT, CSV, or Excel — one or more files")
    data_files = st.file_uploader(
        "Upload datasets",
        type=["sas7bdat", "xpt", "csv", "xlsx", "xls"],
        accept_multiple_files=True,
        key="data_upload",
    )

    st.divider()
    run_btn = st.button("▶ Run QC", type="primary", use_container_width=True)
    if st.button("🔄 Reset", use_container_width=True):
        _reset()
        st.rerun()

    if "run_meta" in _ss():
        m = _ss()["run_meta"]
        st.divider()
        st.caption(f"Last run: {m.get('timestamp','')}")
        st.caption(f"Rules: {m.get('n_rules',0)} | Issues: {m.get('n_issues',0)}")


# ── Run QC ────────────────────────────────────────────────────────────────────
if run_btn:
    if not data_files:
        st.sidebar.warning("Please upload at least one dataset.")
    else:
        tmpdir = tempfile.mkdtemp()

        with st.spinner("Parsing ALS…"):
            als = None
            als_summary = {}
            if als_file:
                als_path = Path(tmpdir) / als_file.name
                als_path.write_bytes(als_file.read())
                try:
                    als = ALSParser(als_path).parse()
                    als_summary = als.summary()
                except Exception as exc:
                    st.error(f"ALS parse error: {exc}")

        with st.spinner("Loading datasets…"):
            loader = DatasetLoader()
            for uf in data_files:
                ds_path = Path(tmpdir) / uf.name
                ds_path.write_bytes(uf.read())
                loader.load_file(ds_path)
            datasets = loader.datasets

        with st.spinner("Building rule catalog…"):
            catalog = RuleCatalog().build(als=als)

        with st.spinner("Executing QC checks…"):
            engine = QCEngine(catalog, als_parser=als)
            issues = engine.run(datasets)

        _ss()["issues"]      = issues
        _ss()["catalog_df"]  = catalog.to_dataframe()
        _ss()["datasets"]    = datasets
        _ss()["als_summary"] = als_summary
        _ss()["run_meta"]    = {
            "timestamp": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S"),
            "n_rules":   len(catalog.active_rules),
            "n_issues":  len(issues),
        }
        st.success(f"✅ QC complete — {len(issues)} issues found across {len(catalog.active_rules)} rules.")
        st.rerun()


# ── Main content ──────────────────────────────────────────────────────────────
if "issues" not in _ss():
    st.info("Upload files and click **▶ Run QC** to start.")
    st.stop()

issues:     list  = _ss()["issues"]
catalog_df: pd.DataFrame = _ss()["catalog_df"]
datasets    = _ss()["datasets"]
als_summary = _ss().get("als_summary", {})

issues_df = pd.DataFrame([i.to_row() for i in issues]) if issues else pd.DataFrame()

tab_dash, tab_issues, tab_catalog, tab_export = st.tabs(
    ["📊 Dashboard", "🚨 Issues", "📋 Rule Catalog", "📤 Export"]
)

# ── Tab 1: Dashboard ──────────────────────────────────────────────────────────
with tab_dash:
    st.header("QC Dashboard")

    # Top KPI row
    c1, c2, c3, c4, c5 = st.columns(5)
    sev_map = issues_df["severity"].value_counts().to_dict() if not issues_df.empty else {}

    c1.metric("Total Issues",  len(issues))
    c2.metric("🔴 Critical",   sev_map.get("Critical", 0))
    c3.metric("🟠 Major",      sev_map.get("Major", 0))
    c4.metric("🟡 Minor",      sev_map.get("Minor", 0))
    c5.metric("🔵 Info",       sev_map.get("Info", 0))

    st.divider()

    col_a, col_b = st.columns(2)

    with col_a:
        st.subheader("Issues by Severity")
        if not issues_df.empty:
            sv = issues_df["severity"].value_counts().reset_index()
            sv.columns = ["Severity", "Count"]
            sv["Color"] = sv["Severity"].map({
                "Critical": "#ff6b6b", "Major": "#ffa94d",
                "Minor": "#ffd43b",    "Info": "#74c0fc",
            })
            st.bar_chart(sv.set_index("Severity")["Count"])
        else:
            st.info("No issues.")

    with col_b:
        st.subheader("Issues by Domain")
        if not issues_df.empty:
            dom = issues_df["domain"].value_counts().head(15).reset_index()
            dom.columns = ["Domain", "Count"]
            st.bar_chart(dom.set_index("Domain")["Count"])

    st.divider()
    col_c, col_d = st.columns(2)

    with col_c:
        st.subheader("Rule Catalog Summary")
        if not catalog_df.empty:
            rc_count = catalog_df["rule_class"].value_counts().reset_index()
            rc_count.columns = ["Rule Class", "Count"]
            st.dataframe(rc_count, use_container_width=True, hide_index=True)

    with col_d:
        st.subheader("ALS Contract Summary")
        if als_summary:
            for k, v in als_summary.items():
                if k != "parse_errors":
                    st.write(f"**{k}:** {v}")
        st.write(f"**Datasets loaded:** {len(datasets)}")
        for dom, ds in datasets.items():
            st.write(f"  · {dom}: {ds.row_count} rows × {len(ds.columns)} cols")

    # Issues by rule class
    st.subheader("Issues by Rule Class")
    if not issues_df.empty:
        merged = issues_df.merge(
            catalog_df[["rule_id", "rule_class"]].drop_duplicates(),
            on="rule_id", how="left"
        )
        cls_count = merged["rule_class"].value_counts().reset_index()
        cls_count.columns = ["Rule Class", "Count"]
        st.bar_chart(cls_count.set_index("Rule Class")["Count"])


# ── Tab 2: Issues ─────────────────────────────────────────────────────────────
with tab_issues:
    st.header(f"QC Issues ({len(issues)} total)")

    if issues_df.empty:
        st.success("No issues found.")
    else:
        # Filters
        fc1, fc2, fc3, fc4 = st.columns(4)
        with fc1:
            sev_filter = st.multiselect("Severity", ["Critical", "Major", "Minor", "Info"],
                                        default=["Critical", "Major"])
        with fc2:
            dom_opts = sorted(issues_df["domain"].dropna().unique())
            dom_filter = st.multiselect("Domain", dom_opts, default=[])
        with fc3:
            cls_opts = sorted(issues_df["rule_id"].str.extract(r'_([A-Z]+)_').iloc[:,0].dropna().unique())
            cls_filter = st.multiselect("Rule Class", cls_opts, default=[])
        with fc4:
            field_search = st.text_input("Field contains", "")

        # Apply filters
        filtered = issues_df.copy()
        if sev_filter:
            filtered = filtered[filtered["severity"].isin(sev_filter)]
        if dom_filter:
            filtered = filtered[filtered["domain"].isin(dom_filter)]
        if cls_filter:
            filtered = filtered[filtered["rule_id"].str.contains("|".join(cls_filter), na=False)]
        if field_search:
            filtered = filtered[filtered["field"].fillna("").str.contains(field_search, case=False)]

        st.caption(f"Showing {len(filtered)} of {len(issues_df)} issues")

        # Highlight severity
        def highlight_sev(val):
            colors = {"Critical": "background-color:#ffcccc",
                      "Major":    "background-color:#ffe5cc",
                      "Minor":    "background-color:#ffffcc",
                      "Info":     "background-color:#cce5ff"}
            return colors.get(val, "")

        display_cols = ["issue_id", "severity", "subject_id", "domain", "form", "field",
                        "observed_value", "expected_behavior", "clinical_explanation",
                        "als_reference", "visit"]
        display_cols = [c for c in display_cols if c in filtered.columns]

        styled = filtered[display_cols].style.applymap(
            highlight_sev, subset=["severity"]
        )
        st.dataframe(styled, use_container_width=True, height=500)


# ── Tab 3: Rule Catalog ───────────────────────────────────────────────────────
with tab_catalog:
    st.header(f"Rule Catalog ({len(catalog_df)} active rules)")

    if catalog_df.empty:
        st.info("No rules generated.")
    else:
        cc1, cc2 = st.columns(2)
        with cc1:
            cls_sel = st.multiselect("Filter by Rule Class",
                                     sorted(catalog_df["rule_class"].unique()), default=[])
        with cc2:
            src_sel = st.multiselect("Filter by Source Sheet",
                                     sorted(catalog_df["source_sheet"].unique()), default=[])

        cat_filtered = catalog_df.copy()
        if cls_sel:
            cat_filtered = cat_filtered[cat_filtered["rule_class"].isin(cls_sel)]
        if src_sel:
            cat_filtered = cat_filtered[cat_filtered["source_sheet"].isin(src_sel)]

        st.dataframe(cat_filtered, use_container_width=True, height=500)


# ── Tab 4: Export ─────────────────────────────────────────────────────────────
with tab_export:
    st.header("Export Results")

    exporter = IssueExporter(issues, catalog_df=catalog_df)

    col_e1, col_e2, col_e3 = st.columns(3)

    with col_e1:
        st.subheader("📊 Excel (Audit-Ready)")
        st.caption("Summary + All Issues + per-severity sheets + Rule Catalog")
        tmpf = tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False)
        try:
            exporter.to_excel(tmpf.name)
            with open(tmpf.name, "rb") as f:
                st.download_button("⬇ Download Excel",
                                   data=f.read(),
                                   file_name="qc_issues.xlsx",
                                   mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                                   use_container_width=True)
        except Exception as exc:
            st.error(f"Excel export error: {exc}")

    with col_e2:
        st.subheader("📄 CSV (Flat)")
        if not issues_df.empty:
            csv_bytes = issues_df.to_csv(index=False).encode("utf-8-sig")
            st.download_button("⬇ Download CSV",
                               data=csv_bytes,
                               file_name="qc_issues.csv",
                               mime="text/csv",
                               use_container_width=True)

    with col_e3:
        st.subheader("🗂 Rule Catalog CSV")
        if not catalog_df.empty:
            cat_bytes = catalog_df.to_csv(index=False).encode("utf-8-sig")
            st.download_button("⬇ Download Rule Catalog",
                               data=cat_bytes,
                               file_name="rule_catalog.csv",
                               mime="text/csv",
                               use_container_width=True)
