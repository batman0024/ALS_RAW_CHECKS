"""
core/als_parser.py
==================
ALS Excel Parser — maps real raw_details.xlsx column structure.

The ALS is a CONTRACT.  Columns outside the whitelist are silently ignored.
Each sheet is mapped to canonical internal names so the rest of the system
never depends on vendor-specific column labels.
"""

from __future__ import annotations
import logging
from pathlib import Path
import pandas as pd

logger = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Column maps  (vendor name → canonical name)
# Matching is case-insensitive; all other columns are dropped.
# ──────────────────────────────────────────────────────────────────────────────

FORMS_MAP = {
    "OID":                    "FormOID",
    "DraftFormName":          "FormName",
    "DraftFormActive":        "Active",
    "IsTemplate":             "IsTemplate",
    "Critical CRF for SDV?":  "CriticalSDV",
    "Core/TA":                "CoreTA",
}

FIELDS_MAP = {
    "FormOID":                "FormOID",
    "FieldOID":               "FieldOID",
    "DraftFieldName":         "FieldName",
    "DraftFieldActive":       "Active",
    "DataFormat":             "DataFormat",
    "DataDictionaryName":     "Dictionary",
    "ControlType":            "ControlType",
    "IsRequired":             "IsRequired",
    "LowerRange":             "LowerRange",
    "UpperRange":             "UpperRange",
    "NCLowerRange":           "NCLowerRange",
    "NCUpperRange":           "NCUpperRange",
    "DefaultValue":           "DefaultValue",
    "SASLabel":               "SASLabel",
    "Field Hidden?":          "IsHidden",
    "Defaulted / Derived?":   "IsDerived",
    "Critical Data":          "CriticalRole",
    "Critical - Safety":      "CriticalSafety",
    "Critical - Consent":     "CriticalConsent",
    "Critical - Eligibility": "CriticalEligibility",
    "Critical - Endpoint":    "CriticalEndpoint",
    "QueryFutureDate":        "QueryFutureDate",
}

CHECKS_MAP = {
    "CheckName":                     "CheckID",
    "CheckActive":                   "Active",
    "BypassDuringMigration":         "BypassMigration",
    "Target FormOID":                "TargetForm",
    "Target FieldOID":               "TargetField",
    "Associated Custom Function(s)": "CF_Linked",
    "Description of Logic":         "Logic",
    "Query Message":                 "QueryMessage",
    "Requires Response?":            "RequiresResponse",
    "Core/TA":                       "CoreTA",
    "Dynamic":                       "Dynamic",
}

DICT_MAP = {
    "DataDictionaryName": "DictionaryName",
    "CodedData":          "CodedValue",
    "UserDataString":     "DisplayLabel",
    "Ordinal":            "Ordinal",
    "Specify":            "AllowSpecify",
}

UNIT_MAP = {
    "UnitDictionaryName": "UnitDictionaryName",
    "CodedUnit":          "CodedUnit",
    "UnitString":         "UnitString",
}

CF_MAP = {
    "FunctionName": "CF_ID",
    "SourceCode":   "SourceCode",
    "Lang":         "Language",
}


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def _rename_df(df: pd.DataFrame, col_map: dict) -> pd.DataFrame:
    lower_map = {k.lower(): v for k, v in col_map.items()}
    rename = {}
    for col in df.columns:
        canonical = lower_map.get(col.strip().lower())
        if canonical:
            rename[col] = canonical
    df = df.rename(columns=rename)
    keep = [c for c in col_map.values() if c in df.columns]
    return df[keep].copy()


def _to_bool(series: pd.Series) -> pd.Series:
    return series.map(
        lambda v: str(v).strip().upper() in {"TRUE", "YES", "Y", "1"}
        if pd.notna(v) else False
    )


# ──────────────────────────────────────────────────────────────────────────────
# Parser
# ──────────────────────────────────────────────────────────────────────────────

class ALSParser:
    """
    Parses a raw_details.xlsx-style ALS workbook into canonical DataFrames.

    Exposes:
      .forms             — active form definitions
      .fields            — field definitions with dictionary, range, criticality
      .checks            — edit checks with logic descriptions & query messages
      .dictionaries      — {dict_name: [valid_coded_values]}
      .unit_dicts        — {unit_dict_name: [coded_units]}
      .custom_functions  — CF metadata (source never executed)
    """

    def __init__(self, path: str | "Path"):
        self.path = Path(path)
        self.forms:            pd.DataFrame = pd.DataFrame()
        self.fields:           pd.DataFrame = pd.DataFrame()
        self.checks:           pd.DataFrame = pd.DataFrame()
        self.custom_functions: pd.DataFrame = pd.DataFrame()
        self.dictionaries:    dict[str, list[str]] = {}
        self.unit_dicts:      dict[str, list[str]] = {}
        self._parse_errors:   list[str] = []

    def parse(self) -> "ALSParser":
        if not self.path.exists():
            raise FileNotFoundError(f"ALS file not found: {self.path}")

        logger.info("Parsing ALS: %s", self.path)
        xl = pd.ExcelFile(self.path, engine="openpyxl")
        sheets = xl.sheet_names

        if "Forms" in sheets:
            raw = xl.parse("Forms")
            self.forms = _rename_df(raw, FORMS_MAP)
            if "Active" in self.forms.columns:
                self.forms["Active"] = _to_bool(self.forms["Active"])
            self.forms = self._derive_form_criticality(self.forms)
            logger.info("  Forms: %d rows", len(self.forms))

        if "Fields" in sheets:
            raw = xl.parse("Fields")
            self.fields = _rename_df(raw, FIELDS_MAP)
            bool_cols = ["Active", "IsRequired", "IsHidden", "IsDerived",
                         "CriticalRole", "CriticalSafety", "CriticalConsent",
                         "CriticalEligibility", "CriticalEndpoint", "QueryFutureDate"]
            for c in bool_cols:
                if c in self.fields.columns:
                    self.fields[c] = _to_bool(self.fields[c])
            logger.info("  Fields: %d rows", len(self.fields))

        if "Checks" in sheets:
            raw = xl.parse("Checks")
            self.checks = _rename_df(raw, CHECKS_MAP)
            if "Active" in self.checks.columns:
                self.checks["Active"] = _to_bool(self.checks["Active"])
            # Drop bypass-during-migration rows for QC purposes
            if "BypassMigration" in self.checks.columns:
                pass  # keep all; flag them in catalog
            logger.info("  Checks: %d rows", len(self.checks))

        if "DataDictionaryEntries" in sheets:
            raw = xl.parse("DataDictionaryEntries")
            dd = _rename_df(raw, DICT_MAP)
            self.dictionaries = self._build_lookup(dd, "DictionaryName", "CodedValue")
            logger.info("  Dictionaries: %d codelists", len(self.dictionaries))

        if "UnitDictionaryEntries" in sheets:
            raw = xl.parse("UnitDictionaryEntries")
            ud = _rename_df(raw, UNIT_MAP)
            self.unit_dicts = self._build_lookup(ud, "UnitDictionaryName", "CodedUnit")
            logger.info("  Unit dicts: %d", len(self.unit_dicts))

        if "CustomFunctions" in sheets:
            raw = xl.parse("CustomFunctions")
            self.custom_functions = _rename_df(raw, CF_MAP)
            logger.info("  Custom functions: %d", len(self.custom_functions))

        return self

    def summary(self) -> dict:
        return {
            "forms_rows":            len(self.forms),
            "fields_rows":           len(self.fields),
            "checks_rows":           len(self.checks),
            "custom_functions_rows": len(self.custom_functions),
            "dictionaries":          len(self.dictionaries),
            "unit_dicts":            len(self.unit_dicts),
            "parse_errors":          self._parse_errors,
        }

    def get_valid_values(self, dict_name: str) -> list[str]:
        """Return valid coded values for a dictionary name."""
        return self.dictionaries.get(dict_name, [])

    # ── private ───────────────────────────────────────────────────────────────

    @staticmethod
    def _build_lookup(df: pd.DataFrame, key_col: str, val_col: str) -> dict:
        if key_col not in df.columns or val_col not in df.columns:
            return {}
        result: dict[str, list[str]] = {}
        for _, row in df.iterrows():
            k = str(row[key_col]).strip() if pd.notna(row[key_col]) else ""
            v = str(row[val_col]).strip() if pd.notna(row[val_col]) else ""
            if k and v:
                result.setdefault(k, []).append(v)
        return result

    @staticmethod
    def _derive_form_criticality(forms: pd.DataFrame) -> pd.DataFrame:
        """Derive criticality flags from form OID when not in workbook."""
        if "FormOID" not in forms.columns:
            return forms
        safety_kw      = {"ae", "sae", "death", "adverse", "serious"}
        consent_kw     = {"consent", "consents", "icf"}
        eligibility_kw = {"enroll", "ie", "eligib", "inclusion", "exclusion"}

        def _flag(name: str, kws: set) -> bool:
            n = str(name).lower()
            return any(k in n for k in kws)

        for col, kws in [("CriticalSafety", safety_kw),
                         ("CriticalConsent", consent_kw),
                         ("CriticalEligibility", eligibility_kw)]:
            if col not in forms.columns:
                forms[col] = forms["FormOID"].map(lambda n: _flag(n, kws))
        return forms
