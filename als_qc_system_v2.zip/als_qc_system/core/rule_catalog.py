"""
core/rule_catalog.py
====================
Unified Rule Catalog Builder.

Derives checks from:
  1. Forms sheet      → FRM rules (form presence, criticality)
  2. Fields sheet     → FLD (required), CTL (dictionary), RNG (ranges)
                        VLM rules from DataDictionaryEntries
  3. Checks sheet     → XFR / TMP / DEP rules parsed from logic descriptions
                        + CF-driven cross-form checks
  4. Custom Functions → DER / DEP consistency (never execute CF source)
  5. Built-ins        → USUBJID, RFSTDTC, future-date, date-unk-month checks

All rules follow DOMAIN_CLASS_NNN taxonomy.
Free text (CF source code, ExpectedCondition) is NEVER executed.
"""

from __future__ import annotations
import itertools
import logging
import re
from pathlib import Path
from typing import Optional
import pandas as pd

from models.rule import (
    QCRule, RuleClass, Severity, SourceSheet, RuleTrigger, RuleExpectation
)
from core.als_parser import ALSParser

logger = logging.getLogger(__name__)


# Patterns used to extract fields from Checks logic text
_FIELD_PAT  = re.compile(r'\(([A-Z][A-Z0-9_]{1,30})\)')   # (FIELDOID) inside parens
_FORM_PAT   = re.compile(r'\b([A-Z][A-Z0-9_]{1,20})\.[A-Z]')  # FORM.FIELD
_DATE_KWS   = {"date", "dtc", "dat", "day", "month", "year", "time"}
_RANGE_PAT  = re.compile(r'(\d+\.?\d*)\s*(?:to|-)\s*(\d+\.?\d*)')


# ──────────────────────────────────────────────────────────────────────────────
# Severity inference from check name / logic text
# ──────────────────────────────────────────────────────────────────────────────

def _infer_severity(check_id: str, logic: str) -> Severity:
    text = (str(check_id) + " " + str(logic)).lower()
    critical_kws = {"death", "deathdat", "serious", "sae", "aeser", "consent",
                    "eligib", "enroll", "compreas", "sdrgreas", "aeacn"}
    if any(k in text for k in critical_kws):
        return Severity.CRITICAL
    major_kws = {"required", "must", "missing", "date", "dtc", "start",
                 "end", "range", "outside", "before", "after"}
    if any(k in text for k in major_kws):
        return Severity.MAJOR
    return Severity.MINOR


def _classify_check(check_id: str, logic: str,
                    target_form: str, target_field: str) -> RuleClass:
    """Classify a Checks-sheet row into a RuleClass."""
    logic_l  = str(logic).lower()
    field_l  = str(target_field).lower()
    form_l   = str(target_form).lower()

    # Cross-form: two distinct forms referenced
    cross_form_match = _FORM_PAT.findall(logic)
    unique_forms = {m.upper() for m in cross_form_match}
    if len(unique_forms) >= 2 or ".CF." in str(check_id).upper():
        return RuleClass.XFR

    # Temporal: date/time field or keywords
    if any(kw in field_l for kw in _DATE_KWS) or \
       any(kw in logic_l for kw in {"date", " dtc", "before", "after", "precede",
                                     "month", "'unk'", "'0000'", "year"}):
        return RuleClass.TMP

    # Dependency: "if X then Y" / conditional
    if re.search(r'\bif\b.*\bthen\b', logic_l) or \
       re.search(r'\bwhen\b.*\bthen\b', logic_l) or \
       re.search(r'isempty|is empty|not empty|is not empty', logic_l):
        return RuleClass.DEP

    return RuleClass.DEP   # default for any remaining checks


# ──────────────────────────────────────────────────────────────────────────────
# Rule Catalog
# ──────────────────────────────────────────────────────────────────────────────

class RuleCatalog:
    """
    Builds and holds the complete set of QC rules for a study.

    The catalog is immutable once built(); re-instantiate to rebuild.
    """

    def __init__(self):
        self._rules: list[QCRule] = []
        self._counter: dict[str, itertools.count] = {}

    # ── public ────────────────────────────────────────────────────────────────

    def build(self, als: Optional[ALSParser] = None) -> "RuleCatalog":
        self._rules.clear()

        if als is not None:
            self._build_form_rules(als)
            self._build_field_rules(als)
            self._build_check_rules(als)
            self._build_cf_rules(als)
        else:
            logger.info("No ALS — only built-in rules active.")

        self._build_builtin_rules()
        logger.info("Catalog built: %d active rules", len(self.active_rules))
        return self

    @property
    def active_rules(self) -> list[QCRule]:
        return [r for r in self._rules if r.active]

    @property
    def all_rules(self) -> list[QCRule]:
        return list(self._rules)

    def rules_for_domain(self, domain: str) -> list[QCRule]:
        return [r for r in self.active_rules if r.domain.upper() == domain.upper()]

    def to_dataframe(self) -> pd.DataFrame:
        rows = []
        for r in self.active_rules:
            rows.append({
                "rule_id":       r.rule_id,
                "source_sheet":  r.source_sheet.value,
                "rule_class":    r.rule_class.value,
                "domain":        r.domain,
                "form":          r.trigger.form,
                "field":         r.trigger.field,
                "severity":      r.severity.value,
                "message":       r.message,
                "als_reference": r.als_reference,
            })
        return pd.DataFrame(rows)

    # ── Step 2 — Form rules ───────────────────────────────────────────────────

    def _build_form_rules(self, als: ALSParser) -> None:
        forms = als.forms
        if forms.empty:
            return
        active = forms[forms.get("Active", pd.Series(True, index=forms.index)) == True] \
            if "Active" in forms.columns else forms

        for _, row in active.iterrows():
            form_oid = str(row.get("FormOID", "")).strip()
            if not form_oid:
                continue
            domain = form_oid.upper()

            is_safety      = bool(row.get("CriticalSafety", False))
            is_consent     = bool(row.get("CriticalConsent", False))
            is_eligibility = bool(row.get("CriticalEligibility", False))
            sev = Severity.CRITICAL if (is_safety or is_consent or is_eligibility) \
                else Severity.MAJOR

            msg = f"Required form '{form_oid}' is absent for subject."
            if is_safety:   msg += " This is a Critical Safety form."
            if is_consent:  msg += " Missing consent data may constitute a protocol deviation."
            if is_eligibility: msg += " Missing eligibility data may affect subject qualification."

            self._add(QCRule(
                rule_id=self._next_id(domain, RuleClass.FRM),
                source_sheet=SourceSheet.FORMS,
                rule_class=RuleClass.FRM,
                domain=domain,
                trigger=RuleTrigger(form=form_oid, operator="absent"),
                expectation=RuleExpectation(form=form_oid, condition="form must have at least one record"),
                severity=sev,
                message=msg,
                als_reference=f"Forms sheet: FormOID={form_oid}",
            ))

    # ── Step 3 — Field rules (FLD / CTL / RNG / VLM) ─────────────────────────

    def _build_field_rules(self, als: ALSParser) -> None:
        fields = als.fields
        if fields.empty:
            return

        active = fields[fields.get("Active", pd.Series(True, index=fields.index)) == True] \
            if "Active" in fields.columns else fields

        for _, row in active.iterrows():
            form_oid  = str(row.get("FormOID",  "")).strip()
            field_oid = str(row.get("FieldOID", "")).strip()
            if not field_oid:
                continue

            domain = form_oid.upper() if form_oid else "ALL"

            # Skip derived / hidden fields to suppress false positives
            if row.get("IsDerived") or row.get("IsHidden"):
                logger.debug("Skipping derived/hidden field: %s.%s", form_oid, field_oid)
                continue

            is_required = bool(row.get("IsRequired", False))
            dictionary  = str(row.get("Dictionary", "")).strip() if pd.notna(row.get("Dictionary")) else ""
            lower_r     = row.get("LowerRange")
            upper_r     = row.get("UpperRange")
            nc_lower    = row.get("NCLowerRange")
            nc_upper    = row.get("NCUpperRange")
            default_val = row.get("DefaultValue")

            is_critical = bool(row.get("CriticalRole", False))
            is_safety   = bool(row.get("CriticalSafety", False))
            is_consent  = bool(row.get("CriticalConsent", False))
            is_elig     = bool(row.get("CriticalEligibility", False))
            is_ep       = bool(row.get("CriticalEndpoint", False))

            sev_fld = Severity.CRITICAL if (is_safety or is_consent or is_elig) \
                else (Severity.MAJOR if (is_critical or is_ep) else Severity.MAJOR)

            # ── FLD: required field missing ──────────────────────────────────
            if is_required:
                criticality_note = ""
                if is_safety:   criticality_note = " This is a critical safety field."
                if is_consent:  criticality_note = " Required for consent documentation."
                if is_elig:     criticality_note = " Required for eligibility determination."
                if is_ep:       criticality_note = " This is a primary/key endpoint field."

                self._add(QCRule(
                    rule_id=self._next_id(domain, RuleClass.FLD),
                    source_sheet=SourceSheet.FIELDS,
                    rule_class=RuleClass.FLD,
                    domain=domain,
                    trigger=RuleTrigger(form=form_oid, field=field_oid, operator="missing"),
                    expectation=RuleExpectation(form=form_oid, field=field_oid,
                                                condition="field must be populated"),
                    severity=sev_fld,
                    message=f"Required field '{field_oid}' on form '{form_oid}' is missing or blank."
                            + criticality_note,
                    als_reference=f"Fields sheet: {form_oid}.{field_oid} | IsRequired=TRUE",
                ))

            # ── CTL: controlled terminology (dictionary) ─────────────────────
            if dictionary and dictionary not in ("", "nan"):
                valid_values = als.get_valid_values(dictionary)
                self._add(QCRule(
                    rule_id=self._next_id(domain, RuleClass.CTL),
                    source_sheet=SourceSheet.FIELDS,
                    rule_class=RuleClass.CTL,
                    domain=domain,
                    trigger=RuleTrigger(form=form_oid, field=field_oid, operator="not_in_codelist"),
                    expectation=RuleExpectation(
                        form=form_oid, field=field_oid,
                        condition=f"value must be in dictionary '{dictionary}'"
                                  + (f" — valid: {valid_values[:8]}" if valid_values else "")
                    ),
                    severity=Severity.MAJOR,
                    message=f"Field '{field_oid}' on form '{form_oid}' contains a value not in "
                            f"dictionary '{dictionary}'. Invalid terms compromise data standardisation "
                            f"and will cause downstream mapping failures.",
                    als_reference=f"Fields: {form_oid}.{field_oid} | Dictionary={dictionary}",
                    context={"dictionary": dictionary, "valid_values": valid_values},
                ))

            # ── RNG: hard numeric range ──────────────────────────────────────
            has_lower = pd.notna(lower_r) and str(lower_r).strip() not in ("", "nan")
            has_upper = pd.notna(upper_r) and str(upper_r).strip() not in ("", "nan")
            if has_lower or has_upper:
                range_parts = []
                if has_lower: range_parts.append(f"≥ {lower_r}")
                if has_upper: range_parts.append(f"≤ {upper_r}")
                range_str = " and ".join(range_parts)
                self._add(QCRule(
                    rule_id=self._next_id(domain, RuleClass.RNG),
                    source_sheet=SourceSheet.FIELDS,
                    rule_class=RuleClass.RNG,
                    domain=domain,
                    trigger=RuleTrigger(form=form_oid, field=field_oid, operator="out_of_range"),
                    expectation=RuleExpectation(form=form_oid, field=field_oid,
                                                condition=f"value must be {range_str}"),
                    severity=Severity.MAJOR,
                    message=f"Field '{field_oid}' value is outside the defined range ({range_str}). "
                            f"Out-of-range values require clinical review as they may indicate "
                            f"data entry error or a clinically significant finding.",
                    als_reference=f"Fields: {form_oid}.{field_oid} | Range={lower_r}–{upper_r}",
                    context={"lower": lower_r, "upper": upper_r},
                ))

            # ── RNG: NC (normal-context) range warning ────────────────────────
            has_nc_lower = pd.notna(nc_lower) and str(nc_lower).strip() not in ("", "nan")
            has_nc_upper = pd.notna(nc_upper) and str(nc_upper).strip() not in ("", "nan")
            if (has_nc_lower or has_nc_upper) and not (has_lower or has_upper):
                nc_parts = []
                if has_nc_lower: nc_parts.append(f"≥ {nc_lower}")
                if has_nc_upper: nc_parts.append(f"≤ {nc_upper}")
                nc_str = " and ".join(nc_parts)
                self._add(QCRule(
                    rule_id=self._next_id(domain, RuleClass.RNG),
                    source_sheet=SourceSheet.FIELDS,
                    rule_class=RuleClass.RNG,
                    domain=domain,
                    trigger=RuleTrigger(form=form_oid, field=field_oid, operator="out_of_nc_range"),
                    expectation=RuleExpectation(form=form_oid, field=field_oid,
                                                condition=f"value expected within normal context {nc_str}"),
                    severity=Severity.MINOR,
                    message=f"Field '{field_oid}' is outside the non-conformance range ({nc_str}). "
                            f"Value may warrant clinical review.",
                    als_reference=f"Fields: {form_oid}.{field_oid} | NCRange={nc_lower}–{nc_upper}",
                    context={"lower": nc_lower, "upper": nc_upper, "nc_range": True},
                ))

            # ── QueryFutureDate ───────────────────────────────────────────────
            if bool(row.get("QueryFutureDate", False)):
                self._add(QCRule(
                    rule_id=self._next_id(domain, RuleClass.TMP),
                    source_sheet=SourceSheet.FIELDS,
                    rule_class=RuleClass.TMP,
                    domain=domain,
                    trigger=RuleTrigger(form=form_oid, field=field_oid, operator="future_date"),
                    expectation=RuleExpectation(form=form_oid, field=field_oid,
                                                condition="date must not be in the future"),
                    severity=Severity.MAJOR,
                    message=f"Date field '{field_oid}' on form '{form_oid}' contains a future date. "
                            f"Future dates are flagged per ALS QueryFutureDate setting.",
                    als_reference=f"Fields: {form_oid}.{field_oid} | QueryFutureDate=TRUE",
                ))

    # ── Step 4 — Checks sheet rules ──────────────────────────────────────────

    def _build_check_rules(self, als: ALSParser) -> None:
        checks = als.checks
        if checks.empty:
            return

        active = checks[checks.get("Active", pd.Series(True, index=checks.index)) == True] \
            if "Active" in checks.columns else checks

        seen_check_ids: set[str] = set()

        for _, row in active.iterrows():
            check_id  = str(row.get("CheckID", "")).strip()
            if not check_id or check_id in seen_check_ids:
                continue
            seen_check_ids.add(check_id)

            logic      = str(row.get("Logic", "")).replace("_x000D_", "\n").strip()
            query_msg  = str(row.get("QueryMessage", "")).strip()
            tgt_form   = str(row.get("TargetForm",  "")).strip()
            tgt_field  = str(row.get("TargetField", "")).strip()
            bypass     = bool(row.get("BypassMigration", False))

            if not logic or logic in ("", "nan"):
                continue

            # Derive domain from check_id pattern or target form
            domain = self._extract_domain_from_check(check_id, tgt_form)

            rule_class = _classify_check(check_id, logic, tgt_form, tgt_field)
            severity   = _infer_severity(check_id, logic)

            # Build a human-readable expected behaviour from logic + query message
            expected = query_msg if query_msg and query_msg not in ("", "nan", "N/A", "NA") \
                       else f"When: {logic[:200]}"

            msg = self._build_check_message(check_id, logic, query_msg, tgt_form, tgt_field)

            ctx: dict = {
                "als_check_id":    check_id,
                "bypass_migration": bypass,
                "target_form":     tgt_form,
                "target_field":    tgt_field,
            }

            # Extract cross-form pairs from logic if XFR
            if rule_class == RuleClass.XFR:
                ctx["xfr_pairs"] = self._extract_xfr_pairs(logic)

            self._add(QCRule(
                rule_id=self._next_id(domain, rule_class),
                source_sheet=SourceSheet.CHECKS,
                rule_class=rule_class,
                domain=domain,
                trigger=RuleTrigger(form=tgt_form or None, field=tgt_field or None,
                                    operator="logic_check"),
                expectation=RuleExpectation(
                    form=tgt_form or None, field=tgt_field or None,
                    condition=expected[:500]
                ),
                severity=severity,
                message=msg,
                als_reference=f"Checks sheet: CheckID={check_id}",
                context=ctx,
            ))

    # ── Step 5 — Custom Function rules ───────────────────────────────────────

    def _build_cf_rules(self, als: ALSParser) -> None:
        """
        Custom Functions define expected behaviour.
        Python MUST NOT execute CF source code.
        We parse the embedded logic comments to generate consistency checks.
        """
        cfs = als.custom_functions
        if cfs.empty:
            return

        for _, row in cfs.iterrows():
            cf_id  = str(row.get("CF_ID", "")).strip()
            source = str(row.get("SourceCode", "")).replace("_x000D_", "\n")
            if not cf_id:
                continue

            # Extract domain from CF_ID (e.g. "0036.AE.AEACN..." → AE)
            domain = self._extract_domain_from_check(cf_id, "")

            # Extract query message from source comments
            qmsg_match = re.search(r'setQueryMessage\("([^"]+)"', source)
            query_msg  = qmsg_match.group(1).replace('\\"', '"') if qmsg_match else ""

            # Extract key field names from source
            field_refs = re.findall(r'"([A-Z][A-Z0-9]{1,20})"', source)
            field_refs = [f for f in field_refs if len(f) >= 2 and not f.startswith("GL")]

            severity = _infer_severity(cf_id, source[:500])

            self._add(QCRule(
                rule_id=self._next_id(domain, RuleClass.XFR),
                source_sheet=SourceSheet.CUSTOM_FUNCTIONS,
                rule_class=RuleClass.XFR,
                domain=domain,
                trigger=RuleTrigger(form=None, field=field_refs[0] if field_refs else None,
                                    operator="cf_logic"),
                expectation=RuleExpectation(
                    condition=query_msg[:400] if query_msg else
                              f"Custom function {cf_id} consistency check"
                ),
                severity=severity,
                message=f"Custom function '{cf_id}': {query_msg[:300] if query_msg else 'Consistency check derived from CF logic.'}",
                als_reference=f"CustomFunctions: CF_ID={cf_id}",
                context={
                    "cf_id": cf_id,
                    "query_message": query_msg,
                    "field_refs": field_refs[:10],
                },
            ))

    # ── Step 6 — Built-in rules ───────────────────────────────────────────────

    def _build_builtin_rules(self) -> None:
        builtins = [
            # USUBJID present on all records
            QCRule(
                rule_id="ALL_FLD_001",
                source_sheet=SourceSheet.BUILTIN,
                rule_class=RuleClass.FLD,
                domain="ALL",
                trigger=RuleTrigger(field="USUBJID", operator="missing"),
                expectation=RuleExpectation(field="USUBJID",
                                            condition="must be present on all records"),
                severity=Severity.CRITICAL,
                message="USUBJID is missing. Every clinical record must have a unique subject "
                        "identifier for traceability and data linkage across domains.",
                als_reference=None,
            ),
            # Event dates must not precede RFSTDTC
            QCRule(
                rule_id="ALL_TMP_001",
                source_sheet=SourceSheet.BUILTIN,
                rule_class=RuleClass.TMP,
                domain="ALL",
                trigger=RuleTrigger(field="RFSTDTC", operator="present"),
                expectation=RuleExpectation(
                    condition="event dates must not precede subject reference start date (RFSTDTC)"
                ),
                severity=Severity.MAJOR,
                message="An event date precedes the subject's reference start date (RFSTDTC). "
                        "This may indicate a data entry error or protocol eligibility violation.",
                als_reference=None,
            ),
            # Future date on any DTC column
            QCRule(
                rule_id="ALL_TMP_002",
                source_sheet=SourceSheet.BUILTIN,
                rule_class=RuleClass.TMP,
                domain="ALL",
                trigger=RuleTrigger(operator="future_date"),
                expectation=RuleExpectation(condition="DTC columns must not contain future dates"),
                severity=Severity.MAJOR,
                message="A date/time value in a *DTC column is in the future. "
                        "Future dates are generally not expected in clinical raw data.",
                als_reference=None,
            ),
            # Duplicate USUBJID within same domain
            QCRule(
                rule_id="ALL_FLD_002",
                source_sheet=SourceSheet.BUILTIN,
                rule_class=RuleClass.FLD,
                domain="ALL",
                trigger=RuleTrigger(field="USUBJID", operator="duplicate_key"),
                expectation=RuleExpectation(
                    condition="USUBJID + record key must be unique within domain"
                ),
                severity=Severity.MAJOR,
                message="Duplicate key detected: multiple records share the same USUBJID and "
                        "VISITNUM/VISIT combination. Review for accidental duplication.",
                als_reference=None,
            ),
        ]
        for r in builtins:
            self._add(r)

    # ── helpers ───────────────────────────────────────────────────────────────

    def _add(self, rule: QCRule) -> None:
        self._rules.append(rule)

    def _next_id(self, domain: str, rule_class: RuleClass) -> str:
        domain = (domain or "STUDY").upper()
        key = f"{domain}_{rule_class.value}"
        if key not in self._counter:
            self._counter[key] = itertools.count(1)
        return f"{domain}_{rule_class.value}_{next(self._counter[key]):03d}"

    @staticmethod
    def _extract_domain_from_check(check_id: str, tgt_form: str) -> str:
        """
        Try to extract domain from check_id like '0036.AE.AEACN.Core.CF.GL'
        or fall back to tgt_form.
        """
        # Pattern: number.DOMAIN.FIELD...
        m = re.match(r'^\d+[._]([A-Z]{2,6})[._]', check_id)
        if m:
            return m.group(1).upper()
        if tgt_form:
            return tgt_form.upper()
        return "STUDY"

    @staticmethod
    def _build_check_message(check_id: str, logic: str,
                              query_msg: str, tgt_form: str, tgt_field: str) -> str:
        qm = query_msg.strip() if query_msg and query_msg not in ("", "nan", "N/A", "NA") else ""
        lg = logic.replace("\n", " ").strip()[:300]
        if qm:
            return f"[{check_id}] {qm}"
        return f"[{check_id}] {tgt_form}.{tgt_field}: {lg}"

    @staticmethod
    def _extract_xfr_pairs(logic: str) -> list[dict]:
        """Extract cross-form field references from logic text."""
        pairs = []
        # Pattern: FORM.FIELD
        for m in re.finditer(r'\b([A-Z][A-Z0-9_]{1,20})\.([A-Z][A-Z0-9_]{1,30})\b', logic):
            pairs.append({"form": m.group(1), "field": m.group(2)})
        return pairs[:20]
