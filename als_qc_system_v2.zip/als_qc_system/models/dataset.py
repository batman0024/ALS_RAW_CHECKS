"""
models/dataset.py
=================
Clinical Dataset Model wrapping a pandas DataFrame with domain metadata.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
import pandas as pd


@dataclass
class ClinicalDataset:
    """
    Wraps a clinical trial domain dataset (e.g. AE, LB, DM) with metadata.

    Supports both SAS (.sas7bdat / .xpt) and CSV/Excel sources.
    """
    domain:    str
    data:      pd.DataFrame
    source_path: Optional[str] = None
    row_count: int = field(init=False)
    columns:   list = field(init=False)

    def __post_init__(self):
        self.row_count = len(self.data)
        self.columns   = list(self.data.columns)

    def get_subject_ids(self) -> list:
        """Return unique subject identifiers from USUBJID or SUBJID."""
        for col in ["USUBJID", "SUBJID", "SUBJECTID"]:
            if col in self.data.columns:
                return self.data[col].dropna().unique().tolist()
        return []

    def get_column(self, name: str) -> Optional[pd.Series]:
        """Case-insensitive column retrieval."""
        mapping = {c.upper(): c for c in self.data.columns}
        actual  = mapping.get(name.upper())
        return self.data[actual] if actual else None

    def has_column(self, name: str) -> bool:
        return name.upper() in {c.upper() for c in self.data.columns}

    def __repr__(self) -> str:
        return f"ClinicalDataset(domain={self.domain!r}, rows={self.row_count}, cols={len(self.columns)})"
