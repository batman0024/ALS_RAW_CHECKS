"""
qc/engine.py
============
QC Execution Engine.

Phase 1: Trigger evaluation   (is this rule applicable to this row?)
Phase 2: Expectation check    (does the row violate the expectation?)

The engine:
 - Never evaluates free text or CF source code.
 - Uses the ALS dictionary lookup for CTL checks (VLM).
 - Handles SAS7BDAT date types (float epoch, datetime.date, string).
 - Is deterministic: same inputs → same outputs.
"""

from __future__ import annotations
import logging
import uuid
from datetime import datetime, date as date_type
from typing import Optional
import pandas as pd
import numpy as np

from models.rule import QCRule, RuleClass
from models.issue import QCIssue
from models.dataset import ClinicalDataset
from core.rule_catalog import RuleCatalog

logger = logging.getLogger(__name__)

# SAS epoch = 1960-01-01
_SAS_EPOCH = datetime(1960, 1, 1)


def _to_datetime(series: pd.Series) -> pd.Series:
    """
    Convert various SAS/string date representations to pandas datetime.
    SAS stores dates as days since 1960-01-01; datetimes as seconds since same.
    """
    if pd.api.types.is_datetime64_any_dtype(series):
        return series
    # Try numeric SAS date (days since 1960)
    numeric = pd.to_numeric(series, errors="coerce")
    if numeric.notna().sum() > 0:
        converted = pd.to_datetime(
            numeric.apply(lambda x: _SAS_EPOCH + pd.Timedelta(days=float(x))
                         if pd.notna(x) else pd.NaT), errors="coerce"
        )
        if converted.notna().sum() > 0:
            return converted
    # Try string parse (ISO 8601 and common formats)
    return pd.to_datetime(series, errors="coerce")


def _is_blank(val) -> bool:
    if val is None:
        return True
    if isinstance(val, float) and np.isnan(val):
        return True
    return str(val).strip() in ("", ".", "nan", "NaN", "NaT", "None")


class QCEngine:
    """
    Executes QC rules against clinical datasets.
    Trigger and expectation phases are strictly separated.
    """

    def __init__(self, catalog: RuleCatalog,
                 als_parser=None):   # type: Optional[ALSParser]
        self.catalog    = catalog
        self._als       = als_parser
        self._issues:   list[QCIssue] = []
        self._today     = pd.Timestamp.today().normalize()

    # ── public ────────────────────────────────────────────────────────────────

    def run(self, datasets: dict[str, ClinicalDataset]) -> list[QCIssue]:
        self._issues.clear()
        rules = self.catalog.active_rules
        logger.info("Running %d rules against %d datasets", len(rules), len(datasets))

        for rule in rules:
            target_datasets = self._resolve_datasets(rule, datasets)
            for ds in target_datasets:
                try:
                    self._execute_rule(rule, ds, datasets)
                except Exception as exc:
                    logger.warning("Rule %s failed on %s: %s", rule.rule_id, ds.domain, exc)

        logger.info("Execution complete: %d issues", len(self._issues))
        return list(self._issues)

    def to_dataframe(self) -> pd.DataFrame:
        if not self._issues:
            return pd.DataFrame(columns=QCIssue.columns())
        return pd.DataFrame([i.to_row() for i in self._issues])

    # ── dispatch ──────────────────────────────────────────────────────────────

    def _execute_rule(self, rule: QCRule, ds: ClinicalDataset,
                      all_datasets: dict) -> None:
        dispatch = {
            RuleClass.FRM: self._check_frm,
            RuleClass.FLD: self._check_fld,
            RuleClass.CTL: self._check_ctl,
            RuleClass.RNG: self._check_rng,
            RuleClass.TMP: self._check_tmp,
            RuleClass.XFR: self._check_xfr,
            RuleClass.DER: self._check_der,
            RuleClass.DEP: self._check_dep,
        }
        fn = dispatch.get(rule.rule_class)
        if fn:
            fn(rule, ds, all_datasets)

    # ── FRM: form-level presence ──────────────────────────────────────────────

    def _check_frm(self, rule: QCRule, ds: ClinicalDataset, _all: dict) -> None:
        if ds.row_count == 0:
            self._emit_single(rule, ds, subject_id="ALL",
                              observed_value="Form/dataset has no records",
                              record_index=None)

    # ── FLD: required field + duplicate key ──────────────────────────────────

    def _check_fld(self, rule: QCRule, ds: ClinicalDataset, _all: dict) -> None:
        field    = rule.trigger.field
        operator = rule.trigger.operator

        if operator == "duplicate_key":
            self._check_duplicate_key(rule, ds)
            return

        if not field:
            return

        # USUBJID special case — check across all datasets
        if field.upper() == "USUBJID" and operator == "missing":
            col = ds.get_column("USUBJID")
            if col is None:
                col = ds.get_column("SUBJID")
            if col is None:
                self._emit_single(rule, ds, subject_id="N/A",
                                  observed_value="USUBJID column absent",
                                  record_index=None)
                return
            missing_mask = col.apply(_is_blank)
            for idx, row in ds.data[missing_mask].iterrows():
                self._emit(rule, ds, row, idx, observed_value=None)
            return

        if not ds.has_column(field):
            return

        if operator == "missing":
            col = ds.get_column(field)
            missing_mask = col.apply(_is_blank)
            for idx, row in ds.data[missing_mask].iterrows():
                self._emit(rule, ds, row, idx, observed_value=None)

    def _check_duplicate_key(self, rule: QCRule, ds: ClinicalDataset) -> None:
        """Flag duplicate USUBJID + VISITNUM/VISIT combinations."""
        key_cols = [c for c in ["USUBJID", "VISITNUM", "VISIT", "AETERM", "LBTESTCD"]
                    if ds.has_column(c)]
        if len(key_cols) < 2:
            return
        dupes = ds.data[ds.data.duplicated(subset=key_cols, keep=False)]
        for idx, row in dupes.iterrows():
            self._emit(rule, ds, row, idx,
                       observed_value=f"Duplicate key: {[str(row.get(k,'')) for k in key_cols]}")

    # ── CTL: controlled terminology / dictionary VLM ─────────────────────────

    def _check_ctl(self, rule: QCRule, ds: ClinicalDataset, _all: dict) -> None:
        field    = rule.trigger.field
        if not field or not ds.has_column(field):
            return

        valid_values = rule.context.get("valid_values", [])
        dictionary   = rule.context.get("dictionary", "")

        if not valid_values:
            # No dictionary loaded — skip (don't generate phantom issues)
            return

        col = ds.get_column(field)
        # Phase 1: non-blank values
        non_blank = ds.data[col.apply(lambda x: not _is_blank(x))].copy()

        # Phase 2: value not in codelist
        valid_set = {str(v).strip() for v in valid_values}
        for idx, row in non_blank.iterrows():
            val = str(col[idx]).strip()
            if val not in valid_set:
                self._emit(rule, ds, row, idx, observed_value=val)

    # ── RNG: numeric range ────────────────────────────────────────────────────

    def _check_rng(self, rule: QCRule, ds: ClinicalDataset, _all: dict) -> None:
        field    = rule.trigger.field
        if not field or not ds.has_column(field):
            return

        lower    = rule.context.get("lower")
        upper    = rule.context.get("upper")
        nc_range = rule.context.get("nc_range", False)
        col      = ds.get_column(field)

        numeric  = pd.to_numeric(col, errors="coerce")
        valid    = numeric.dropna()

        for idx in valid.index:
            val = float(valid[idx])
            violation = False
            if lower is not None and val < float(lower):
                violation = True
            if upper is not None and val > float(upper):
                violation = True
            if violation:
                self._emit(rule, ds, ds.data.loc[idx], idx, observed_value=val)

    # ── TMP: temporal / date checks ───────────────────────────────────────────

    def _check_tmp(self, rule: QCRule, ds: ClinicalDataset, _all: dict) -> None:
        operator = rule.trigger.operator

        if rule.rule_id == "ALL_TMP_001":
            self._check_rfstdtc(rule, ds)
            return

        if rule.rule_id == "ALL_TMP_002" or operator == "future_date":
            self._check_future_dates(rule, ds)
            return

        # ALS field-level future-date check
        if operator == "future_date":
            field = rule.trigger.field
            if not field or not ds.has_column(field):
                return
            col = _to_datetime(ds.get_column(field))
            violations = ds.data[col.notna() & (col > self._today)]
            for idx, row in violations.iterrows():
                self._emit(rule, ds, row, idx, observed_value=str(col[idx].date()))
            return

        # ALS temporal: two date fields
        trig_field = rule.trigger.field
        exp_field  = rule.expectation.field
        if trig_field and exp_field and ds.has_column(trig_field) and ds.has_column(exp_field):
            col_a = _to_datetime(ds.get_column(trig_field))
            col_b = _to_datetime(ds.get_column(exp_field))
            both_valid = col_a.notna() & col_b.notna()
            violations = ds.data[both_valid & (col_a > col_b)]
            for idx, row in violations.iterrows():
                self._emit(rule, ds, row, idx,
                           observed_value=f"{trig_field}={col_a[idx]}, {exp_field}={col_b[idx]}")

    def _check_rfstdtc(self, rule: QCRule, ds: ClinicalDataset) -> None:
        if not ds.has_column("RFSTDTC"):
            return
        rfstdtc = _to_datetime(ds.get_column("RFSTDTC"))
        dtc_cols = [c for c in ds.columns
                    if "DTC" in c.upper() and c.upper() != "RFSTDTC"]
        for dcol in dtc_cols:
            ev_dates  = _to_datetime(ds.get_column(dcol))
            both_valid = rfstdtc.notna() & ev_dates.notna()
            violations = ds.data[both_valid & (ev_dates < rfstdtc)]
            for idx, row in violations.iterrows():
                self._emit(rule, ds, row, idx,
                           observed_value=f"{dcol}={ev_dates[idx]!s} < RFSTDTC={rfstdtc[idx]!s}")

    def _check_future_dates(self, rule: QCRule, ds: ClinicalDataset) -> None:
        dtc_cols = [c for c in ds.columns
                    if ("DTC" in c.upper() or "DAT" in c.upper() or "DATE" in c.upper())]
        for dcol in dtc_cols:
            col       = _to_datetime(ds.get_column(dcol))
            violations = ds.data[col.notna() & (col > self._today)]
            for idx, row in violations.iterrows():
                self._emit(rule, ds, row, idx,
                           observed_value=f"{dcol}={col[idx]!s}")

    # ── XFR: cross-form dependency ────────────────────────────────────────────

    def _check_xfr(self, rule: QCRule, ds: ClinicalDataset,
                   all_datasets: dict) -> None:
        """
        Cross-form checks based on ALS Checks-sheet logic.
        We translate the natural-language logic into structural checks where possible.
        CF-driven XFR rules: verify field presence consistency.
        """
        ctx      = rule.context
        tgt_form = ctx.get("target_form", "")
        tgt_fld  = ctx.get("target_field", "")

        if not tgt_form:
            return

        tgt_ds = all_datasets.get(tgt_form.upper())
        if tgt_ds is None:
            return

        # Get subjects in current dataset
        src_subj = set(ds.data.get("USUBJID", pd.Series()).dropna().unique()) \
            if "USUBJID" in ds.data.columns else set()
        tgt_subj = set(tgt_ds.data.get("USUBJID", pd.Series()).dropna().unique()) \
            if "USUBJID" in tgt_ds.data.columns else set()

        if not src_subj:
            return

        # Subjects in source but missing from target
        missing = src_subj - tgt_subj
        for subj in sorted(missing)[:100]:   # cap at 100 per rule
            self._emit_single(rule, ds, subject_id=str(subj),
                              observed_value=f"Subject in {ds.domain} but absent from {tgt_form}",
                              record_index=None)

        # If target field specified, check it is populated for linked subjects
        if tgt_fld and tgt_ds.has_column(tgt_fld):
            linked_rows = tgt_ds.data[tgt_ds.data.get("USUBJID", pd.Series()).isin(src_subj)]
            col = tgt_ds.get_column(tgt_fld)
            if col is not None:
                blank_rows = linked_rows[linked_rows.index.map(
                    lambda i: _is_blank(col.get(i))
                )]
                for idx, row in blank_rows.iterrows():
                    self._emit(rule, tgt_ds, row, idx,
                               observed_value=f"{tgt_form}.{tgt_fld} is blank for linked subject")

    # ── DER: derived field consistency ────────────────────────────────────────

    def _check_der(self, rule: QCRule, ds: ClinicalDataset, _all: dict) -> None:
        field = rule.trigger.field
        if not field or not ds.has_column(field):
            return
        col = ds.get_column(field)
        for idx, row in ds.data[col.apply(_is_blank)].iterrows():
            self._emit(rule, ds, row, idx, observed_value=None)

    # ── DEP: dependency check ─────────────────────────────────────────────────

    def _check_dep(self, rule: QCRule, ds: ClinicalDataset, _all: dict) -> None:
        ctx = rule.context
        tgt_form  = ctx.get("target_form", "")
        tgt_field = ctx.get("target_field", "")

        if not tgt_field or not ds.has_column(tgt_field):
            return

        tgt_col = ds.get_column(tgt_field)
        if tgt_col is None:
            return

        # Look at records where the target field is blank
        blank_mask = tgt_col.apply(_is_blank)

        # Check if there's evidence from another "trigger" field that it should be filled
        # DEP logic: if a source/conditional field is present → target should be present
        xfr_pairs = ctx.get("xfr_pairs", [])
        trigger_fields = list({p.get("field") for p in xfr_pairs if p.get("field")})[:5]

        for tf in trigger_fields:
            if not ds.has_column(tf):
                continue
            src_col = ds.get_column(tf)
            src_filled = ~src_col.apply(_is_blank)
            violations = ds.data[src_filled & blank_mask]
            for idx, row in violations.iterrows():
                self._emit(rule, ds, row, idx,
                           observed_value=f"{tgt_field} is blank but {tf}='{src_col[idx]}'")
            break  # one trigger field per rule invocation

    # ── helpers ───────────────────────────────────────────────────────────────

    def _resolve_datasets(self, rule: QCRule,
                          datasets: dict[str, ClinicalDataset]
                          ) -> list[ClinicalDataset]:
        domain = rule.domain.upper()
        if domain == "ALL":
            return list(datasets.values())
        if domain in datasets:
            return [datasets[domain]]
        form = (rule.trigger.form or "").upper()
        if form and form in datasets:
            return [datasets[form]]
        return []

    def _emit(self, rule: QCRule, ds: ClinicalDataset,
              row: pd.Series, idx, observed_value) -> None:
        subj  = str(row.get("USUBJID", row.get("SUBJID", "UNKNOWN")))
        visit = str(row.get("VISIT",   row.get("VISITNUM", ""))) or None
        self._issues.append(QCIssue(
            issue_id=f"ISS-{uuid.uuid4().hex[:8].upper()}",
            rule_id=rule.rule_id,
            severity=rule.severity.value,
            subject_id=subj,
            dataset=ds.domain,
            domain=rule.domain,
            form=rule.trigger.form,
            field=rule.trigger.field,
            observed_value=observed_value,
            expected_behavior=rule.expectation.condition or "",
            clinical_explanation=rule.message,
            als_reference=rule.als_reference,
            visit=visit,
            record_index=int(idx) if idx is not None else None,
        ))

    def _emit_single(self, rule: QCRule, ds: ClinicalDataset,
                     subject_id: str, observed_value, record_index) -> None:
        self._issues.append(QCIssue(
            issue_id=f"ISS-{uuid.uuid4().hex[:8].upper()}",
            rule_id=rule.rule_id,
            severity=rule.severity.value,
            subject_id=subject_id,
            dataset=ds.domain,
            domain=rule.domain,
            form=rule.trigger.form,
            field=rule.trigger.field,
            observed_value=observed_value,
            expected_behavior=rule.expectation.condition or "",
            clinical_explanation=rule.message,
            als_reference=rule.als_reference,
            visit=None,
            record_index=record_index,
        ))
