"""
qc/exporter.py
==============
Issue Exporter — Excel (audit-ready) / CSV / JSON.

Excel output:
  - Summary sheet with counts, run metadata
  - All Issues sheet
  - Per-severity sheets (Critical / Major / Minor / Info)
  - Rule Catalog sheet
"""

from __future__ import annotations
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional
import pandas as pd

from models.issue import QCIssue

logger = logging.getLogger(__name__)

# Severity → RGB fill colours for Excel
_SEV_COLOURS = {
    "Critical": "FFCCCC",
    "Major":    "FFE5CC",
    "Minor":    "FFFFCC",
    "Info":     "CCE5FF",
}


class IssueExporter:
    def __init__(self, issues: list[QCIssue],
                 catalog_df: Optional[pd.DataFrame] = None):
        self._issues    = issues
        self._catalog   = catalog_df
        self._df: Optional[pd.DataFrame] = None

    @property
    def dataframe(self) -> pd.DataFrame:
        if self._df is None:
            if self._issues:
                self._df = pd.DataFrame([i.to_row() for i in self._issues])
            else:
                self._df = pd.DataFrame(columns=QCIssue.columns())
        return self._df

    # ── Excel ─────────────────────────────────────────────────────────────────

    def to_excel(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)

        try:
            from openpyxl import Workbook
            from openpyxl.styles import PatternFill, Font, Alignment, Border, Side
            from openpyxl.utils import get_column_letter
        except ImportError:
            logger.warning("openpyxl not available — writing CSV instead")
            self.to_csv(str(path).replace(".xlsx", ".csv"))
            return

        wb = Workbook()

        # ── Summary sheet ────────────────────────────────────────────────────
        ws_sum = wb.active
        ws_sum.title = "Summary"
        df = self.dataframe

        sev_counts = df["severity"].value_counts().to_dict() if not df.empty else {}
        summary_rows = [
            ["ALS-Driven Clinical Data QC Report"],
            ["Generated at:", datetime.utcnow().isoformat() + "Z"],
            ["Total Issues:", len(df)],
            [],
            ["Severity", "Count"],
        ]
        for sev in ["Critical", "Major", "Minor", "Info"]:
            summary_rows.append([sev, sev_counts.get(sev, 0)])

        for r_idx, row in enumerate(summary_rows, 1):
            for c_idx, val in enumerate(row, 1):
                ws_sum.cell(r_idx, c_idx, val)

        # Title styling
        ws_sum.cell(1, 1).font = Font(bold=True, size=14)
        for col_idx in range(1, 3):
            ws_sum.column_dimensions[get_column_letter(col_idx)].width = 30

        # ── All Issues sheet ─────────────────────────────────────────────────
        self._write_issues_sheet(wb, df, "All Issues")

        # ── Per-severity sheets ───────────────────────────────────────────────
        for sev in ["Critical", "Major", "Minor", "Info"]:
            sev_df = df[df["severity"] == sev] if not df.empty else pd.DataFrame()
            if not sev_df.empty:
                self._write_issues_sheet(wb, sev_df, sev)

        # ── Rule Catalog sheet ────────────────────────────────────────────────
        if self._catalog is not None and not self._catalog.empty:
            ws_cat = wb.create_sheet("Rule Catalog")
            self._write_df_to_sheet(ws_cat, self._catalog)

        wb.save(str(path))
        logger.info("Exported Excel: %s", path)

    def _write_issues_sheet(self, wb, df: pd.DataFrame, title: str) -> None:
        from openpyxl.styles import PatternFill, Font, Alignment
        from openpyxl.utils import get_column_letter

        ws = wb.create_sheet(title)
        if df.empty:
            ws.append(["No issues"])
            return

        cols = list(df.columns)
        ws.append(cols)

        # Header styling
        for cell in ws[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="2C3E50")
            cell.alignment = Alignment(wrap_text=True)

        for r_idx, (_, row) in enumerate(df.iterrows(), 2):
            sev   = str(row.get("severity", ""))
            color = _SEV_COLOURS.get(sev, "FFFFFF")
            fill  = PatternFill("solid", fgColor=color)
            for c_idx, col in enumerate(cols, 1):
                cell = ws.cell(r_idx, c_idx, str(row[col]) if pd.notna(row[col]) else "")
                cell.fill = fill
                cell.alignment = Alignment(wrap_text=False)

        # Auto-width (cap at 60)
        for c_idx, col in enumerate(cols, 1):
            max_len = max(len(str(col)),
                         *[len(str(ws.cell(r, c_idx).value or ""))
                           for r in range(1, min(ws.max_row + 1, 50))])
            ws.column_dimensions[get_column_letter(c_idx)].width = min(max_len + 2, 60)

        ws.freeze_panes = "A2"

    def _write_df_to_sheet(self, ws, df: pd.DataFrame) -> None:
        from openpyxl.styles import PatternFill, Font
        from openpyxl.utils import get_column_letter

        ws.append(list(df.columns))
        for cell in ws[1]:
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill("solid", fgColor="2C3E50")

        for _, row in df.iterrows():
            ws.append([str(v) if pd.notna(v) else "" for v in row])

        for c_idx, col in enumerate(df.columns, 1):
            max_len = max(len(str(col)),
                         *[len(str(ws.cell(r, c_idx).value or ""))
                           for r in range(1, min(ws.max_row + 1, 30))])
            ws.column_dimensions[get_column_letter(c_idx)].width = min(max_len + 2, 55)

    # ── CSV ───────────────────────────────────────────────────────────────────

    def to_csv(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.dataframe.to_csv(str(path), index=False, encoding="utf-8-sig")
        logger.info("Exported CSV: %s", path)

    # ── JSON ──────────────────────────────────────────────────────────────────

    def to_json(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        records = [i.to_dict() for i in self._issues]
        # Make datetime-safe
        for r in records:
            for k, v in r.items():
                if isinstance(v, (datetime,)):
                    r[k] = v.isoformat()
        with open(str(path), "w", encoding="utf-8") as f:
            json.dump(records, f, indent=2, default=str)
        logger.info("Exported JSON: %s", path)
