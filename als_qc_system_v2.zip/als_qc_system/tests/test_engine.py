"""
tests/test_engine.py
====================
Unit tests for QCEngine — verifies correct issue emission per rule class.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import unittest
import pandas as pd

from core.rule_catalog import RuleCatalog
from core.als_parser import ALSParser
from models.dataset import ClinicalDataset
from models.rule import QCRule, RuleClass, Severity, SourceSheet, RuleTrigger, RuleExpectation
from qc.engine import QCEngine


def _make_catalog_with_rules(*rules):
    cat = RuleCatalog()
    for r in rules:
        cat._add(r)
    return cat


def _make_rule(rule_id, rule_class, field=None, form=None,
               operator="missing", severity=Severity.MAJOR, context=None):
    return QCRule(
        rule_id=rule_id,
        source_sheet=SourceSheet.BUILTIN,
        rule_class=rule_class,
        domain="TEST",
        trigger=RuleTrigger(form=form, field=field, operator=operator),
        expectation=RuleExpectation(condition="test expectation"),
        severity=severity,
        message="Test rule message",
        context=context or {},
    )


def _ds(data: dict, domain="TEST") -> ClinicalDataset:
    return ClinicalDataset(domain=domain, data=pd.DataFrame(data))


class TestFLDCheck(unittest.TestCase):
    def test_missing_required_field_emits_issue(self):
        rule = _make_rule("TEST_FLD_001", RuleClass.FLD, field="AETERM", operator="missing")
        cat = _make_catalog_with_rules(rule)
        ds = _ds({"USUBJID": ["S001"], "AETERM": [None]}, "TEST")
        engine = QCEngine(cat)
        issues = engine.run({"TEST": ds})
        self.assertEqual(len(issues), 1)
        self.assertEqual(issues[0].field, "AETERM")

    def test_populated_field_no_issue(self):
        rule = _make_rule("TEST_FLD_001", RuleClass.FLD, field="AETERM", operator="missing")
        cat = _make_catalog_with_rules(rule)
        ds = _ds({"USUBJID": ["S001"], "AETERM": ["Headache"]}, "TEST")
        engine = QCEngine(cat)
        issues = engine.run({"TEST": ds})
        self.assertEqual(len(issues), 0)

    def test_blank_string_is_missing(self):
        rule = _make_rule("TEST_FLD_001", RuleClass.FLD, field="AETERM", operator="missing")
        cat = _make_catalog_with_rules(rule)
        ds = _ds({"USUBJID": ["S001"], "AETERM": ["   "]}, "TEST")
        engine = QCEngine(cat)
        issues = engine.run({"TEST": ds})
        self.assertEqual(len(issues), 1)

    def test_usubjid_missing_emits_critical(self):
        cat = RuleCatalog().build(als=None)
        ds = _ds({"USUBJID": [None, "S002"], "AETERM": ["Pain", "Nausea"]}, "ALL")
        engine = QCEngine(cat)
        issues = engine.run({"ALL": ds})
        usubjid_issues = [i for i in issues if i.rule_id == "ALL_FLD_001"]
        self.assertEqual(len(usubjid_issues), 1)
        self.assertEqual(usubjid_issues[0].severity, "Critical")

    def test_duplicate_key_emits_issue(self):
        cat = RuleCatalog().build(als=None)
        ds = _ds({
            "USUBJID":  ["S001", "S001"],
            "VISITNUM": [1, 1],
            "AETERM":   ["Pain", "Pain"],
        }, "ALL")
        engine = QCEngine(cat)
        issues = engine.run({"ALL": ds})
        dup_issues = [i for i in issues if i.rule_id == "ALL_FLD_002"]
        self.assertGreater(len(dup_issues), 0)


class TestCTLCheck(unittest.TestCase):
    def test_invalid_coded_value_emits_issue(self):
        rule = _make_rule("TEST_CTL_001", RuleClass.CTL, field="AESER",
                          operator="not_in_codelist",
                          context={"dictionary": "YesNo", "valid_values": ["Y", "N"]})
        cat = _make_catalog_with_rules(rule)
        ds = _ds({"USUBJID": ["S001", "S002"], "AESER": ["Y", "MAYBE"]}, "TEST")
        engine = QCEngine(cat)
        issues = engine.run({"TEST": ds})
        self.assertEqual(len(issues), 1)
        self.assertEqual(issues[0].observed_value, "MAYBE")

    def test_valid_coded_value_no_issue(self):
        rule = _make_rule("TEST_CTL_001", RuleClass.CTL, field="AESER",
                          operator="not_in_codelist",
                          context={"dictionary": "YesNo", "valid_values": ["Y", "N"]})
        cat = _make_catalog_with_rules(rule)
        ds = _ds({"USUBJID": ["S001"], "AESER": ["Y"]}, "TEST")
        engine = QCEngine(cat)
        issues = engine.run({"TEST": ds})
        self.assertEqual(len(issues), 0)

    def test_empty_valid_values_no_phantom_issues(self):
        rule = _make_rule("TEST_CTL_001", RuleClass.CTL, field="AESER",
                          operator="not_in_codelist",
                          context={"dictionary": "YesNo", "valid_values": []})
        cat = _make_catalog_with_rules(rule)
        ds = _ds({"USUBJID": ["S001"], "AESER": ["ANYTHING"]}, "TEST")
        engine = QCEngine(cat)
        issues = engine.run({"TEST": ds})
        self.assertEqual(len(issues), 0)


class TestRNGCheck(unittest.TestCase):
    def test_out_of_range_emits_issue(self):
        rule = _make_rule("TEST_RNG_001", RuleClass.RNG, field="AGE",
                          operator="out_of_range",
                          context={"lower": 18, "upper": 120})
        cat = _make_catalog_with_rules(rule)
        ds = _ds({"USUBJID": ["S001", "S002", "S003"],
                  "AGE":     ["25",   "150",   "16"]}, "TEST")
        engine = QCEngine(cat)
        issues = engine.run({"TEST": ds})
        self.assertEqual(len(issues), 2)

    def test_in_range_no_issue(self):
        rule = _make_rule("TEST_RNG_001", RuleClass.RNG, field="AGE",
                          operator="out_of_range",
                          context={"lower": 18, "upper": 120})
        cat = _make_catalog_with_rules(rule)
        ds = _ds({"USUBJID": ["S001"], "AGE": ["45"]}, "TEST")
        engine = QCEngine(cat)
        issues = engine.run({"TEST": ds})
        self.assertEqual(len(issues), 0)


class TestTMPCheck(unittest.TestCase):
    def test_future_date_emits_issue(self):
        cat = RuleCatalog().build(als=None)
        ds = _ds({
            "USUBJID": ["S001"],
            "AESTDAT": ["2099-01-01"],
        }, "ALL")
        engine = QCEngine(cat)
        issues = engine.run({"ALL": ds})
        future_issues = [i for i in issues if i.rule_id == "ALL_TMP_002"]
        self.assertGreater(len(future_issues), 0)

    def test_rfstdtc_violation(self):
        cat = RuleCatalog().build(als=None)
        ds = _ds({
            "USUBJID": ["S001"],
            "RFSTDTC": ["2025-06-01"],
            "AESTDTC": ["2025-01-01"],   # before RFSTDTC
        }, "ALL")
        engine = QCEngine(cat)
        issues = engine.run({"ALL": ds})
        rfst_issues = [i for i in issues if i.rule_id == "ALL_TMP_001"]
        self.assertGreater(len(rfst_issues), 0)


class TestFRMCheck(unittest.TestCase):
    def test_empty_dataset_emits_issue(self):
        rule = _make_rule("TEST_FRM_001", RuleClass.FRM, form="AE",
                          operator="absent")
        cat = _make_catalog_with_rules(rule)
        ds = _ds({}, "TEST")
        engine = QCEngine(cat)
        issues = engine.run({"TEST": ds})
        self.assertGreater(len(issues), 0)

    def test_non_empty_dataset_no_frm_issue(self):
        rule = _make_rule("TEST_FRM_001", RuleClass.FRM, form="AE",
                          operator="absent")
        cat = _make_catalog_with_rules(rule)
        ds = _ds({"USUBJID": ["S001"]}, "TEST")
        engine = QCEngine(cat)
        issues = engine.run({"TEST": ds})
        self.assertEqual(len(issues), 0)


class TestIssueCompleteness(unittest.TestCase):
    def test_issue_has_all_required_fields(self):
        cat = RuleCatalog().build(als=None)
        ds = _ds({"USUBJID": [None]}, "ALL")
        engine = QCEngine(cat)
        issues = engine.run({"ALL": ds})
        if issues:
            iss = issues[0]
            self.assertIsNotNone(iss.issue_id)
            self.assertIsNotNone(iss.rule_id)
            self.assertIsNotNone(iss.severity)
            self.assertIsNotNone(iss.emitted_at)
            self.assertIsNotNone(iss.clinical_explanation)

    def test_issue_id_is_unique(self):
        cat = RuleCatalog().build(als=None)
        ds = _ds({"USUBJID": [None, None, None]}, "ALL")
        engine = QCEngine(cat)
        issues = engine.run({"ALL": ds})
        ids = [i.issue_id for i in issues]
        self.assertEqual(len(ids), len(set(ids)))


if __name__ == "__main__":
    unittest.main()
