"""
app/main.py  (V3)
=================
ALS-Driven Clinical Data QC System — Streamlit UI
Full integration with corrected ALSParser, RuleCatalog V3, and QCEngine.
"""

import sys, io, json, logging, tempfile
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pandas as pd
import streamlit as st

from core.als_parser   import ALSParser
from core.dataset_loader import DatasetLoader
from core.rule_catalog import RuleCatalog
from qc.engine         import QCEngine
from qc.exporter       import IssueExporter

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="ALS QC Engine V3",
    page_icon="🧬",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
  .main .block-container{padding-top:1.5rem;max-width:1400px}
  .kpi{background:#1e2633;border:1px solid #2d3748;border-radius:10px;padding:18px 12px;text-align:center}
  .kpi h2{margin:0;font-size:2.1rem;font-weight:800}
  .kpi p{margin:4px 0 0;color:#8b9ab1;font-size:.85rem}
  .rule-badge{font-family:monospace;background:#1a3a5c;color:#58a6ff;
              padding:2px 8px;border-radius:12px;font-size:.82rem}
  .sev-critical{color:#ff6b6b;font-weight:700}
  .sev-major{color:#ffa94d;font-weight:700}
  .sev-minor{color:#ffd43b;font-weight:700}
  .sev-info{color:#74c0fc;font-weight:700}
</style>
""", unsafe_allow_html=True)

# ── Session defaults ──────────────────────────────────────────────────────────
for k, v in {
    "issues": [], "rule_catalog": None, "datasets": {},
    "als_summary": None, "run_complete": False, "als_obj": None,
}.items():
    if k not in st.session_state:
        st.session_state[k] = v

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### 🧬 ALS QC Engine V3")
    st.caption("Clinical Trial Data Quality Control")
    st.divider()

    st.subheader("① ALS Contract")
    als_file = st.file_uploader(
        "Upload ALS Excel (.xlsx)",
        type=["xlsx"],
        help="Upload raw_details.xlsx or equivalent ALS workbook.",
    )
    if als_file:
        st.success(f"✓ {als_file.name}")

    st.subheader("② Clinical Datasets")
    dataset_files = st.file_uploader(
        "Upload datasets",
        type=["sas7bdat","xpt","csv","xlsx"],
        accept_multiple_files=True,
    )
    if dataset_files:
        st.success(f"✓ {len(dataset_files)} file(s)")

    st.divider()
    run_btn = st.button(
        "▶  Run QC",
        type="primary",
        disabled=not bool(dataset_files),
        use_container_width=True,
    )
    if st.button("🔄 Clear Results", use_container_width=True):
        for k in ["issues","rule_catalog","datasets","als_summary","run_complete","als_obj"]:
            st.session_state[k] = [] if k == "issues" else (None if k != "datasets" else {})
        st.session_state["run_complete"] = False
        st.rerun()

    st.divider()
    st.caption(f"V3.0  ·  {datetime.now().strftime('%Y-%m-%d')}")

# ── Run QC ────────────────────────────────────────────────────────────────────
if run_btn and dataset_files:
    with st.spinner("Parsing ALS, building rules, executing QC…"):
        tmpdir = tempfile.mkdtemp()
        loader = DatasetLoader()
        for uf in dataset_files:
            fpath = Path(tmpdir) / uf.name
            fpath.write_bytes(uf.read())
            try:
                loader.load_file(fpath)
            except Exception as exc:
                st.warning(f"Could not load {uf.name}: {exc}")

        datasets = dict(loader._loaded)

        als, als_summary = None, {}
        if als_file:
            als_path = Path(tmpdir) / als_file.name
            als_path.write_bytes(als_file.read())
            try:
                als = ALSParser(als_path).parse()
                als_summary = als.summary()
                st.session_state["als_obj"]     = als
                st.session_state["als_summary"] = als_summary
            except Exception as exc:
                st.warning(f"ALS parsing failed: {exc}. Using built-in rules only.")

        catalog = RuleCatalog().build(als=als)
        engine  = QCEngine(catalog)
        issues  = engine.run(datasets)

        st.session_state.update({
            "issues": issues, "rule_catalog": catalog,
            "datasets": datasets, "run_complete": True,
        })

    st.success(
        f"✅ QC complete — **{len(issues)} issues** · "
        f"**{len(datasets)} datasets** · "
        f"**{len(catalog.active_rules)} rules**"
    )

# ── Results ───────────────────────────────────────────────────────────────────
if st.session_state["run_complete"]:
    issues   = st.session_state["issues"]
    catalog  = st.session_state["rule_catalog"]
    datasets = st.session_state["datasets"]
    _df = pd.DataFrame([i.to_row() for i in issues]) if issues else pd.DataFrame()

    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📊 Dashboard", "🚨 Issues", "📋 Rules", "🗂 ALS Explorer", "📤 Export"
    ])

    # ── Dashboard ─────────────────────────────────────────────────────────────
    with tab1:
        st.subheader("QC Summary")
        total    = len(issues)
        critical = int((_df["severity"] == "Critical").sum()) if not _df.empty else 0
        major    = int((_df["severity"] == "Major").sum())    if not _df.empty else 0
        minor    = int((_df["severity"] == "Minor").sum())    if not _df.empty else 0
        subjects = int(_df["subject_id"].nunique())           if not _df.empty else 0

        c1,c2,c3,c4,c5 = st.columns(5)
        for col, label, val, color in [
            (c1,"Total Issues",total,"#e6edf3"),
            (c2,"Critical",critical,"#ff6b6b"),
            (c3,"Major",major,"#ffa94d"),
            (c4,"Minor",minor,"#ffd43b"),
            (c5,"Subjects Affected",subjects,"#74c0fc"),
        ]:
            col.markdown(
                f'<div class="kpi"><h2 style="color:{color}">{val}</h2><p>{label}</p></div>',
                unsafe_allow_html=True
            )
        st.divider()

        if not _df.empty:
            ch1, ch2 = st.columns(2)
            with ch1:
                st.subheader("Issues by Severity")
                st.bar_chart(_df["severity"].value_counts())
            with ch2:
                st.subheader("Issues by Domain")
                st.bar_chart(_df["domain"].value_counts().head(15))

            ch3, ch4 = st.columns(2)
            with ch3:
                st.subheader("Issues by Rule Class")
                class_counts = _df["rule_id"].str.extract(r'_([A-Z]+)_\d+')[0].value_counts()
                st.bar_chart(class_counts)
            with ch4:
                st.subheader("Top 10 Failing Rules")
                top_rules = _df["rule_id"].value_counts().head(10).reset_index()
                top_rules.columns = ["Rule ID","Count"]
                st.dataframe(top_rules, use_container_width=True, hide_index=True)

        st.subheader("Loaded Datasets")
        ds_rows = [{"Domain":d,"Rows":ds.row_count,"Columns":len(ds.columns)}
                   for d, ds in datasets.items()]
        st.dataframe(pd.DataFrame(ds_rows), use_container_width=True, hide_index=True)

        als_summary = st.session_state.get("als_summary")
        if als_summary:
            st.subheader("ALS Contract Statistics")
            c = st.columns(4)
            c[0].metric("Forms",  als_summary.get("forms_rows",0))
            c[1].metric("Fields", als_summary.get("fields_rows",0))
            c[2].metric("Checks", als_summary.get("checks_rows",0))
            c[3].metric("Codelists", als_summary.get("codelist_dictionaries",0))

    # ── Issues ────────────────────────────────────────────────────────────────
    with tab2:
        if _df.empty:
            st.info("No issues found.")
        else:
            st.subheader(f"Quality Control Issues ({len(_df)})")
            fc1, fc2, fc3, fc4 = st.columns(4)
            sev_opts   = sorted(_df["severity"].unique().tolist())
            dom_opts   = sorted(_df["domain"].unique().tolist())
            sev_sel    = fc1.multiselect("Severity",  sev_opts, default=sev_opts)
            dom_sel    = fc2.multiselect("Domain",    dom_opts, default=dom_opts)
            rule_filt  = fc3.text_input("Rule ID contains", "")
            subj_filt  = fc4.text_input("Subject ID contains","")

            filtered = _df[_df["severity"].isin(sev_sel) & _df["domain"].isin(dom_sel)]
            if rule_filt:
                filtered = filtered[filtered["rule_id"].str.contains(rule_filt,case=False,na=False)]
            if subj_filt:
                filtered = filtered[filtered["subject_id"].str.contains(subj_filt,case=False,na=False)]

            st.caption(f"Showing {len(filtered):,} of {len(_df):,} issues")
            display_cols = ["issue_id","rule_id","severity","subject_id","domain",
                            "field","observed_value","expected_behavior",
                            "clinical_explanation","als_reference"]
            display_cols = [c for c in display_cols if c in filtered.columns]
            st.dataframe(
                filtered[display_cols],
                use_container_width=True,
                height=520,
                column_config={
                    "severity":           st.column_config.TextColumn("Sev", width="small"),
                    "clinical_explanation":st.column_config.TextColumn("Clinical Explanation", width="large"),
                },
            )

    # ── Rule catalog ──────────────────────────────────────────────────────────
    with tab3:
        rdf = catalog.to_dataframe() if catalog else pd.DataFrame()
        st.subheader(f"Rule Catalog ({len(rdf)} active rules)")
        if not rdf.empty:
            rc1, rc2, rc3 = st.columns(3)
            cls_opts = sorted(rdf["rule_class"].unique().tolist())
            src_opts = sorted(rdf["source_sheet"].unique().tolist())
            dom_opts2= sorted(rdf["domain"].unique().tolist())
            cls_sel  = rc1.multiselect("Rule Class",   cls_opts, default=cls_opts)
            src_sel  = rc2.multiselect("Source Sheet", src_opts, default=src_opts)
            dom_sel2 = rc3.multiselect("Domain",       dom_opts2[:20], default=dom_opts2[:20])

            fr = rdf[rdf["rule_class"].isin(cls_sel) &
                     rdf["source_sheet"].isin(src_sel) &
                     rdf["domain"].isin(dom_sel2)]
            disp = ["rule_id","rule_class","source_sheet","domain","severity","message","als_reference"]
            st.dataframe(fr[[c for c in disp if c in fr.columns]],
                         use_container_width=True, height=520, hide_index=True)

    # ── ALS Explorer ──────────────────────────────────────────────────────────
    with tab4:
        als_obj = st.session_state.get("als_obj")
        if als_obj is None:
            st.info("Upload and run with an ALS file to explore it here.")
        else:
            als_tab = st.radio("Explore", ["Checks","Fields","Forms","Folders","Codelists"],
                               horizontal=True)
            if als_tab == "Checks":
                df_show = als_obj.checks.copy()
                if not df_show.empty:
                    rt_opts = sorted(df_show["RuleType"].unique().tolist())
                    rt_sel  = st.multiselect("Rule Type", rt_opts, default=rt_opts)
                    df_show = df_show[df_show["RuleType"].isin(rt_sel)]
                    cols = ["CheckID","Domain","TargetFormOID","TargetFieldOID",
                            "RuleType","Severity","Description","QueryMessage"]
                    st.dataframe(df_show[[c for c in cols if c in df_show.columns]],
                                 use_container_width=True, height=480, hide_index=True)
            elif als_tab == "Fields":
                df_show = als_obj.fields.copy()
                cols = ["FormOID","FieldOID","Domain","IsRequired","Dictionary",
                        "IsDerived","IsHidden","CriticalRole","DataFormat"]
                st.dataframe(df_show[[c for c in cols if c in df_show.columns]],
                             use_container_width=True, height=480, hide_index=True)
            elif als_tab == "Forms":
                st.dataframe(als_obj.forms, use_container_width=True, hide_index=True)
            elif als_tab == "Folders":
                st.dataframe(als_obj.folders, use_container_width=True, hide_index=True)
            elif als_tab == "Codelists":
                cl_name = st.selectbox("Dictionary", sorted(als_obj.codelists.keys()))
                if cl_name:
                    terms = sorted(als_obj.codelists[cl_name])
                    st.write(f"**{cl_name}** — {len(terms)} coded values")
                    st.dataframe(pd.DataFrame({"CodedValue": terms}),
                                 use_container_width=True, hide_index=True)

    # ── Export ────────────────────────────────────────────────────────────────
    with tab5:
        st.subheader("Export Results")
        exporter = IssueExporter(issues)
        ec1, ec2, ec3 = st.columns(3)

        with ec1:
            st.markdown("#### Excel (Audit-Ready)")
            if st.button("Generate Excel", use_container_width=True):
                with tempfile.TemporaryDirectory() as td:
                    out = Path(td) / "qc_issues.xlsx"
                    exporter.to_excel(out)
                    st.download_button(
                        "⬇ Download Excel",
                        data=out.read_bytes(),
                        file_name=f"qc_issues_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        use_container_width=True,
                    )
        with ec2:
            st.markdown("#### CSV")
            st.download_button(
                "⬇ Download CSV",
                data=exporter.dataframe.to_csv(index=False),
                file_name=f"qc_issues_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv", use_container_width=True,
            )
        with ec3:
            st.markdown("#### JSON")
            st.download_button(
                "⬇ Download JSON",
                data=json.dumps([i.to_dict() for i in issues], indent=2, default=str),
                file_name=f"qc_issues_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                mime="application/json", use_container_width=True,
            )
        st.divider()
        st.subheader("Rule Catalog Export")
        if catalog:
            st.download_button(
                "⬇ Download Rule Catalog (CSV)",
                data=catalog.to_dataframe().to_csv(index=False),
                file_name="rule_catalog_v3.csv", mime="text/csv",
            )

else:
    st.title("🧬 ALS-Driven Clinical Data QC System V3")
    st.markdown(
        "Upload datasets (and optionally an ALS Excel workbook) in the sidebar, "
        "then click **▶ Run QC**."
    )
    with st.expander("ℹ️ What's new in V3", expanded=True):
        st.markdown("""
**V3 Fixes and Enhancements:**
- ✅ **Parser column mapping corrected** — Forms `OID`→`FormOID`, Fields `DraftFieldActive`, `DataDictionaryName`, `Defaulted / Derived?`, `Field Hidden?`, `Critical Data` columns all now correctly mapped
- ✅ **Checks columns fixed** — `CheckName`→`CheckID`, `CheckActive`→`Active`, `Target FormOID`/`Target FieldOID` now correctly extracted
- ✅ **Real codelists loaded** — 97 `DataDictionaryEntries` codelists with 1,205 coded values now power actual CTL validation
- ✅ **Folders sheet parsed** — visit window days and target visit schedules available for temporal checks
- ✅ **Pattern classification** — all 988 checks classified into DATE_COMPARISON, VISIT_WINDOW, CONDITIONAL_REQUIRED, CROSS_FORM, FORM_COMPLETENESS, APPEARANCE, TEXT_LENGTH, CONFLICTING_RECORD
- ✅ **Severity inferred** — from Query Message and Description text patterns
- ✅ **CF source parsing** — C# source code comments parsed for input/output field references
- ✅ **ALS Explorer tab** — browse Checks, Fields, Folders, Codelists directly
        """)
