"""
qc/engine.py  (V3 clean)
========================
Two-phase QC Execution Engine.
Phase 1: Trigger evaluation. Phase 2: Expectation validation.
Deterministic, no free-text evaluation.
"""
from __future__ import annotations
import logging, uuid
from datetime import datetime
import numpy as np
import pandas as pd
from models.rule import QCRule, RuleClass
from models.issue import QCIssue
from models.dataset import ClinicalDataset
from core.rule_catalog import RuleCatalog

logger = logging.getLogger(__name__)
_SAS_EPOCH = datetime(1960, 1, 1)

def _to_datetime(s):
    if pd.api.types.is_datetime64_any_dtype(s):
        return s
    num = pd.to_numeric(s, errors="coerce")
    if num.notna().any():
        c = num.apply(lambda x: _SAS_EPOCH + pd.Timedelta(days=float(x)) if pd.notna(x) else pd.NaT)
        r = pd.to_datetime(c, errors="coerce")
        if r.notna().any():
            return r
    return pd.to_datetime(s, errors="coerce")

def _is_blank(val):
    if val is None: return True
    if isinstance(val, float) and np.isnan(val): return True
    return str(val).strip() in ("",".", "nan","NaN","NaT","None")

class QCEngine:
    def __init__(self, catalog: RuleCatalog, als_parser=None):
        self.catalog  = catalog
        self._als     = als_parser
        self._issues  = []
        self._today   = pd.Timestamp.today().normalize()

    def run(self, datasets):
        self._issues.clear()
        rules = self.catalog.active_rules
        logger.info("Running %d rules against %d datasets", len(rules), len(datasets))
        for rule in rules:
            for ds in self._resolve_datasets(rule, datasets):
                try:
                    self._execute_rule(rule, ds, datasets)
                except Exception as exc:
                    logger.warning("Rule %s on %s: %s", rule.rule_id, ds.domain, exc)
        logger.info("Done: %d issues", len(self._issues))
        return list(self._issues)

    def to_dataframe(self):
        if not self._issues:
            return pd.DataFrame(columns=QCIssue.columns())
        return pd.DataFrame([i.to_row() for i in self._issues])

    def _execute_rule(self, rule, ds, all_datasets):
        # Built-in special-ID rules dispatched first
        if rule.rule_id == "ALL_FLD_002":
            self._check_duplicate_records(rule, ds); return
        if rule.rule_id == "ALL_TMP_002":
            self._check_future_dates(rule, ds); return
        dispatch = {
            RuleClass.FRM: self._check_frm,
            RuleClass.FLD: self._check_fld,
            RuleClass.CTL: self._check_ctl,
            RuleClass.RNG: self._check_rng,
            RuleClass.TMP: self._check_tmp,
            RuleClass.XFR: self._check_xfr,
            RuleClass.DER: self._check_der,
            RuleClass.DEP: self._check_dep,
        }
        h = dispatch.get(rule.rule_class)
        if h: h(rule, ds, all_datasets)

    def _check_frm(self, rule, ds, _all):
        if ds.row_count == 0:
            self._emit_single(rule, ds, "ALL", "Form/dataset absent or empty", None)

    def _check_fld(self, rule, ds, _all):
        field    = rule.trigger.field
        operator = rule.trigger.operator or "missing"
        if not field: return
        if field.upper() == "USUBJID" and operator == "missing":
            col = ds.get_column("USUBJID")
            if col is None:
                col = ds.get_column("SUBJID")
            if col is None:
                self._emit_single(rule, ds, "N/A", "USUBJID column absent", None); return
            for idx, row in ds.data[col.apply(_is_blank)].iterrows():
                self._emit(rule, ds, row, idx, None)
            return
        if not ds.has_column(field): return
        if operator == "missing":
            col = ds.get_column(field)
            for idx, row in ds.data[col.apply(_is_blank)].iterrows():
                self._emit(rule, ds, row, idx, None)

    def _check_duplicate_records(self, rule, ds):
        """ALL_FLD_002 — duplicate record detection."""
        candidates = ["USUBJID","VISITNUM","VISIT","AETERM","LBTESTCD","MHTERM","CMTRT"]
        key_cols   = [c for c in candidates if ds.has_column(c)]
        if len(key_cols) < 2: return
        actual = [ds.get_column(c).name for c in key_cols]
        dupes  = ds.data[ds.data.duplicated(subset=actual, keep=False)]
        for idx, row in dupes.iterrows():
            self._emit(rule, ds, row, idx,
                       " | ".join(f"{c}={row.get(c,'')}" for c in actual))

    def _check_ctl(self, rule, ds, _all):
        field = rule.trigger.field
        if not field or not ds.has_column(field): return
        vv    = rule.context.get("valid_values") or rule.context.get("valid_terms") or []
        if not vv: return
        valid_set = {str(v).strip() for v in vv}
        col       = ds.get_column(field)
        for idx, row in ds.data[~col.apply(_is_blank)].iterrows():
            val = str(col[idx]).strip()
            if val not in valid_set:
                self._emit(rule, ds, row, idx, val)

    def _check_rng(self, rule, ds, _all):
        field = rule.trigger.field
        if not field or not ds.has_column(field): return
        lower = rule.context.get("lower")
        upper = rule.context.get("upper")
        num   = pd.to_numeric(ds.get_column(field), errors="coerce").dropna()
        for idx in num.index:
            v = float(num[idx])
            if (lower is not None and v < float(lower)) or \
               (upper is not None and v > float(upper)):
                self._emit(rule, ds, ds.data.loc[idx], idx, v)

    def _check_tmp(self, rule, ds, _all):
        if rule.rule_id == "ALL_TMP_001":
            self._check_rfstdtc(rule, ds); return
        tf = rule.trigger.field
        ef = rule.expectation.field
        if tf and ef and ds.has_column(tf) and ds.has_column(ef):
            ca = _to_datetime(ds.get_column(tf))
            cb = _to_datetime(ds.get_column(ef))
            both = ca.notna() & cb.notna()
            for idx, row in ds.data[both & (ca > cb)].iterrows():
                self._emit(rule, ds, row, idx, f"{tf}={ca[idx]}, {ef}={cb[idx]}")

    def _check_rfstdtc(self, rule, ds):
        if not ds.has_column("RFSTDTC"): return
        rfst = _to_datetime(ds.get_column("RFSTDTC"))
        for cn in [c for c in ds.columns if "DTC" in c.upper() and c.upper() != "RFSTDTC"]:
            ev   = _to_datetime(ds.get_column(cn))
            both = rfst.notna() & ev.notna()
            for idx, row in ds.data[both & (ev < rfst)].iterrows():
                self._emit(rule, ds, row, idx, f"{cn}={ev[idx]!s} < RFSTDTC={rfst[idx]!s}")

    def _check_future_dates(self, rule, ds):
        """ALL_TMP_002 — future date detection."""
        for cn in [c for c in ds.columns if "DTC" in c.upper() or "DAT" in c.upper()]:
            col  = _to_datetime(ds.get_column(cn))
            futs = ds.data[col.notna() & (col > self._today)]
            for idx, row in futs.iterrows():
                self._emit(rule, ds, row, idx, f"{cn}={col[idx]!s}")

    def _check_xfr(self, rule, ds, all_datasets):
        tgt_form = (rule.expectation.form or rule.trigger.form or "").upper()
        if not tgt_form: return
        tgt_ds = all_datasets.get(tgt_form)
        if tgt_ds is None: return
        src = set(ds.data["USUBJID"].dropna()) if "USUBJID" in ds.data.columns else set()
        tgt = set(tgt_ds.data["USUBJID"].dropna()) if "USUBJID" in tgt_ds.data.columns else set()
        if not src: return
        for subj in sorted(src - tgt)[:50]:
            self._emit_single(rule, ds, str(subj),
                              f"Present in {ds.domain} but absent from {tgt_form}", None)

    def _check_der(self, rule, ds, _all):
        field = rule.trigger.field
        if not field or not ds.has_column(field): return
        col = ds.get_column(field)
        for idx, row in ds.data[col.apply(_is_blank)].iterrows():
            self._emit(rule, ds, row, idx, None)

    def _check_dep(self, rule, ds, _all):
        field = rule.trigger.field
        if not field or not ds.has_column(field): return
        col = ds.get_column(field)
        for idx, row in ds.data[col.apply(_is_blank)].iterrows():
            self._emit(rule, ds, row, idx, None)

    def _resolve_datasets(self, rule, datasets):
        dom = rule.domain.upper()
        if dom == "ALL": return list(datasets.values())
        if dom in datasets: return [datasets[dom]]
        form = (rule.trigger.form or "").upper()
        if form and form in datasets: return [datasets[form]]
        return []

    def _emit(self, rule, ds, row, idx, observed_value):
        subj  = str(row.get("USUBJID", row.get("SUBJID", "UNKNOWN")))
        visit = str(row.get("VISIT",   row.get("VISITNUM", ""))) or None
        self._issues.append(QCIssue(
            issue_id=f"ISS-{uuid.uuid4().hex[:8].upper()}",
            rule_id=rule.rule_id, severity=rule.severity.value,
            subject_id=subj, dataset=ds.domain, domain=rule.domain,
            form=rule.trigger.form, field=rule.trigger.field,
            observed_value=observed_value,
            expected_behavior=rule.expectation.condition or "",
            clinical_explanation=rule.message, als_reference=rule.als_reference,
            visit=visit, record_index=int(idx) if idx is not None else None,
        ))

    def _emit_single(self, rule, ds, subject_id, observed_value, record_index):
        self._issues.append(QCIssue(
            issue_id=f"ISS-{uuid.uuid4().hex[:8].upper()}",
            rule_id=rule.rule_id, severity=rule.severity.value,
            subject_id=subject_id, dataset=ds.domain, domain=rule.domain,
            form=rule.trigger.form, field=rule.trigger.field,
            observed_value=observed_value,
            expected_behavior=rule.expectation.condition or "",
            clinical_explanation=rule.message, als_reference=rule.als_reference,
            visit=None, record_index=record_index,
        ))
