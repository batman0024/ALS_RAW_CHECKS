# ALS QC Engine V3

Production-ready, metadata-driven clinical trial data quality control system.
Transforms the EDC Annotated Layout Sheet (ALS) into 1,604 deterministic QC rules.

## Quick Start

```bash
pip install -r requirements.txt
streamlit run app/main.py
```

## V3 Key Fixes

| Issue | V2 | V3 |
|---|---|---|
| Forms sheet | `FormOID` (wrong) | `OID` ✓ |
| Fields active flag | `Active` (wrong) | `DraftFieldActive` ✓ |
| Fields codelist | `Dictionary` (wrong) | `DataDictionaryName` ✓ |
| Fields derived flag | `IsDerived` (wrong) | `Defaulted / Derived?` ✓ |
| Checks identifier | `CheckID` (wrong) | `CheckName` ✓ |
| Checks active | `Active` (wrong) | `CheckActive` ✓ |
| Codelists | Not loaded | 97 dicts / 1,205 terms ✓ |
| CF identifier | `CF_ID` (wrong) | `FunctionName` ✓ |

## Rule Statistics

| Source | Rules |
|---|---|
| Checks | 988 |
| CustomFunctions | 328 |
| Fields | 241 |
| Forms | 45 |
| BuiltIn | 2 |
| **Total** | **1,604** |

## Run Tests

```bash
python -m unittest tests.test_models tests.test_rule_catalog tests.test_engine -v
```

See `docs/index.html` for full documentation.
