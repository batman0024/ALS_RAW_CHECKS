"""
app/main.py  —  V3 Fixed
=========================
Fixes:
  - loader._loaded → loader.datasets  (AttributeError fix)
  - SAS timedelta date handling
  - Multiple rerun safety (session_state guards)
  - Plain-English issue narratives
  - Rich dashboard with charts
  - ALS Explorer tab
  - Download buttons always visible (no Generate button needed)
"""
import sys
import io
import json
import logging
import tempfile
import time
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pandas as pd
import streamlit as st

from core.als_parser    import ALSParser
from core.dataset_loader import DatasetLoader
from core.rule_catalog  import RuleCatalog
from qc.engine          import QCEngine
from qc.exporter        import IssueExporter

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)

# ── Page config ───────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="ALS QC Engine V3",
    page_icon="🧬",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
  .main .block-container{padding-top:1.2rem;max-width:1500px}
  .kpi{background:#1e2633;border:1px solid #2d3748;border-radius:10px;
       padding:18px 12px;text-align:center;margin-bottom:4px}
  .kpi h2{margin:0;font-size:2rem;font-weight:800}
  .kpi p{margin:4px 0 0;color:#8b9ab1;font-size:.82rem}
  div[data-testid="stMetricValue"]{font-size:1.7rem}
</style>
""", unsafe_allow_html=True)

# ── Session state defaults ─────────────────────────────────────────────────────
_DEFAULTS = {
    "issues": [],
    "rule_catalog": None,
    "datasets": {},
    "als_summary": None,
    "als_obj": None,
    "run_complete": False,
    "run_count": 0,
    "elapsed": 0.0,
}
for k, v in _DEFAULTS.items():
    if k not in st.session_state:
        st.session_state[k] = v

# ── Sidebar ───────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### 🧬 ALS QC Engine V3")
    st.caption("Clinical Trial Raw Data QC")
    st.divider()

    st.subheader("① ALS Contract")
    als_file = st.file_uploader(
        "ALS Excel (.xlsx)",
        type=["xlsx"],
        help="Upload raw_details.xlsx or any study ALS workbook.",
        key="als_upload",
    )
    if als_file:
        st.success(f"✓ {als_file.name}")

    st.subheader("② Raw Datasets")
    dataset_files = st.file_uploader(
        "SAS7BDAT / XPT / CSV / Excel",
        type=["sas7bdat", "xpt", "csv", "xlsx"],
        accept_multiple_files=True,
        key="data_upload",
    )
    if dataset_files:
        st.success(f"✓ {len(dataset_files)} file(s) selected")

    st.divider()
    workers = st.slider("⚡ Parallel workers", 1, 12, 6,
                        help="More workers = faster on large studies")

    run_btn = st.button(
        "▶  Run QC",
        type="primary",
        disabled=not bool(dataset_files),
        use_container_width=True,
        key="run_button",
    )
    if st.button("🔄 Clear & Reset", use_container_width=True):
        for k, v in _DEFAULTS.items():
            st.session_state[k] = v
        st.rerun()

    st.divider()
    if st.session_state["run_complete"]:
        m = st.session_state
        st.caption(
            f"Run #{m['run_count']} · "
            f"{m['elapsed']:.1f}s · "
            f"{len(m['issues'])} issues · "
            f"{len(m['datasets'])} datasets"
        )
    st.caption(f"V3 · {datetime.now().strftime('%Y-%m-%d')}")

# ── Run QC ────────────────────────────────────────────────────────────────────
if run_btn and dataset_files:
    t0 = time.time()
    progress = st.progress(0, "Setting up…")

    tmpdir = tempfile.mkdtemp()

    # Load datasets
    progress.progress(15, "Loading datasets…")
    loader = DatasetLoader()
    for uf in dataset_files:
        fpath = Path(tmpdir) / uf.name
        fpath.write_bytes(uf.read())
        try:
            loader.load_file(fpath)
        except Exception as exc:
            st.warning(f"Could not load {uf.name}: {exc}")

    # FIX: use .datasets property, not ._loaded
    datasets = loader.datasets

    # Parse ALS
    progress.progress(30, "Parsing ALS…")
    als, als_summary = None, {}
    if als_file:
        als_path = Path(tmpdir) / als_file.name
        als_path.write_bytes(als_file.read())
        try:
            als = ALSParser(als_path).parse()
            als_summary = als.summary()
        except Exception as exc:
            st.warning(f"ALS parse error: {exc} — using built-in rules only.")

    # Build catalog
    progress.progress(50, f"Building rule catalog…")
    catalog = RuleCatalog().build(als=als)

    # Execute QC
    progress.progress(65, f"Running {len(catalog.active_rules):,} rules (parallel)…")
    engine = QCEngine(catalog, als_parser=als, max_workers=workers)
    issues = engine.run(datasets)

    elapsed = time.time() - t0
    progress.progress(100, f"Done — {len(issues):,} issues in {elapsed:.1f}s")

    # Store in session state — safe for reruns
    st.session_state.update({
        "issues":       issues,
        "rule_catalog": catalog,
        "datasets":     datasets,
        "als_summary":  als_summary,
        "als_obj":      als,
        "run_complete": True,
        "run_count":    st.session_state["run_count"] + 1,
        "elapsed":      elapsed,
    })

    st.success(
        f"✅ QC complete — **{len(issues):,} issues** · "
        f"**{len(datasets):,} datasets** · "
        f"**{len(catalog.active_rules):,} rules** · "
        f"**{elapsed:.1f}s**"
    )

# ── Landing page if no results yet ───────────────────────────────────────────
if not st.session_state["run_complete"]:
    st.title("🧬 ALS-Driven Clinical Data QC System V3")
    st.markdown(
        "Upload SAS datasets (and optionally an ALS workbook) in the sidebar, "
        "then click **▶ Run QC**."
    )
    with st.expander("ℹ️ What does this system check?", expanded=True):
        col1, col2 = st.columns(2)
        with col1:
            st.markdown("""
**Field-level checks**
- Missing required fields
- Controlled terminology (VLM codelist)
- Numeric range violations
- Future date detection
- SAS timedelta/epoch date handling

**Cross-dataset checks**
- Subject exists in DM
- Duplicate records
- Cross-form dependencies
""")
        with col2:
            st.markdown("""
**Temporal checks**
- Event dates before RFSTDTC
- Start date after end date
- ALS QueryFutureDate fields

**Study-level checks**
- Form completeness
- Visit order consistency
- CF-driven cross-form logic

**Output**
- Plain-English narrative per issue
- SAS PROC SQL filter per issue
- 7-sheet audit-ready Excel
""")
    st.stop()

# ── Main tabs ─────────────────────────────────────────────────────────────────
issues   = st.session_state["issues"]
catalog  = st.session_state["rule_catalog"]
datasets = st.session_state["datasets"]
als_obj  = st.session_state["als_obj"]
als_sum  = st.session_state.get("als_summary") or {}

_df = pd.DataFrame([i.to_row() for i in issues]) if issues else pd.DataFrame()

tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "📊 Dashboard", "🚨 Issues", "📋 Rules", "🔭 ALS Explorer", "📤 Export"
])

# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 — DASHBOARD
# ══════════════════════════════════════════════════════════════════════════════
with tab1:
    st.subheader("QC Summary")

    total    = len(issues)
    critical = int((_df["severity"] == "Critical").sum()) if not _df.empty else 0
    major    = int((_df["severity"] == "Major").sum())    if not _df.empty else 0
    minor    = int((_df["severity"] == "Minor").sum())    if not _df.empty else 0
    subjects = int(_df["subject_id"].nunique())           if not _df.empty else 0
    n_rules  = len(catalog.active_rules) if catalog else 0
    elapsed  = st.session_state["elapsed"]

    # KPI row
    c1, c2, c3, c4, c5, c6 = st.columns(6)
    for col_w, label, val, color in [
        (c1, "Total Issues",       total,    "#e6edf3"),
        (c2, "🔴 Critical",        critical, "#ff6b6b"),
        (c3, "🟠 Major",           major,    "#ffa94d"),
        (c4, "🟡 Minor",           minor,    "#ffd43b"),
        (c5, "Subjects Affected",  subjects, "#74c0fc"),
        (c6, f"⏱ {elapsed:.1f}s", n_rules,  "#a8d8a8"),
    ]:
        col_w.markdown(
            f'<div class="kpi"><h2 style="color:{color}">{val:,}</h2>'
            f'<p>{label}</p></div>',
            unsafe_allow_html=True,
        )

    st.divider()

    if not _df.empty:
        # Row 1: Severity + Domain
        g1, g2 = st.columns(2)
        with g1:
            st.subheader("Issues by Severity")
            sev_data = _df["severity"].value_counts().reset_index()
            sev_data.columns = ["Severity", "Count"]
            st.bar_chart(sev_data.set_index("Severity")["Count"])

        with g2:
            st.subheader("Issues by Domain (top 20)")
            dom_data = _df["domain"].value_counts().head(20).reset_index()
            dom_data.columns = ["Domain", "Count"]
            st.bar_chart(dom_data.set_index("Domain")["Count"])

        # Row 2: Rule class + Subject heatmap
        g3, g4 = st.columns(2)
        with g3:
            st.subheader("Issues by Rule Class")
            cls_data = _df["rule_id"].str.extract(r'_([A-Z]+)_\d+')[0].value_counts().reset_index()
            cls_data.columns = ["Rule Class", "Count"]
            st.bar_chart(cls_data.set_index("Rule Class")["Count"])

        with g4:
            st.subheader("Top 15 Subjects by Issue Count")
            subj_data = _df["subject_id"].value_counts().head(15).reset_index()
            subj_data.columns = ["Subject", "Count"]
            st.bar_chart(subj_data.set_index("Subject")["Count"])

        # Row 3: Domain × Severity heatmap
        st.subheader("Domain × Severity Heatmap")
        pivot = _df.groupby(["domain", "severity"]).size().unstack(fill_value=0)
        for s in ["Critical", "Major", "Minor", "Info"]:
            if s not in pivot.columns:
                pivot[s] = 0
        pivot["Total"] = pivot.sum(axis=1)
        pivot = pivot.sort_values("Total", ascending=False)
        st.dataframe(
            pivot.style
                .background_gradient(subset=["Critical"], cmap="Reds")
                .background_gradient(subset=["Major"],    cmap="Oranges")
                .background_gradient(subset=["Total"],    cmap="Blues"),
            use_container_width=True,
        )

        # Row 4: Top failing rules
        st.subheader("Top 10 Failing Rules")
        top_rules = _df["rule_id"].value_counts().head(10).reset_index()
        top_rules.columns = ["Rule ID", "Count"]
        st.dataframe(top_rules, use_container_width=True, hide_index=True)

    # Datasets inventory
    st.divider()
    st.subheader("Loaded Datasets")
    ds_rows = [{"Domain": d, "Rows": ds.row_count, "Columns": len(ds.columns)}
               for d, ds in sorted(datasets.items())]
    st.dataframe(pd.DataFrame(ds_rows), use_container_width=True, hide_index=True)

    if als_sum:
        st.subheader("ALS Contract")
        ac1, ac2, ac3, ac4, ac5 = st.columns(5)
        ac1.metric("Forms",       als_sum.get("forms_rows", 0))
        ac2.metric("Fields",      als_sum.get("fields_rows", 0))
        ac3.metric("Checks",      als_sum.get("checks_rows", 0))
        ac4.metric("Codelists",   als_sum.get("codelist_dictionaries",
                                  als_sum.get("dictionaries", 0)))
        ac5.metric("Custom Fns",  als_sum.get("custom_functions_rows", 0))

# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 — ISSUES
# ══════════════════════════════════════════════════════════════════════════════
with tab2:
    if _df.empty:
        st.info("No issues found.")
    else:
        st.subheader(f"Quality Control Issues ({len(_df):,})")

        # Filters
        f1, f2, f3, f4 = st.columns(4)
        sev_opts = sorted(_df["severity"].unique().tolist())
        dom_opts = sorted(_df["domain"].unique().tolist())
        sev_sel  = f1.multiselect("Severity",  sev_opts, default=sev_opts, key="issues_tab_sev")
        dom_sel  = f2.multiselect("Domain",    dom_opts, default=[], key="issues_tab_dom")
        fld_flt  = f3.text_input("Field contains", "", key="issues_tab_field")
        subj_flt = f4.text_input("Subject contains", "", key="issues_tab_subj")

        filtered = _df[_df["severity"].isin(sev_sel)]
        if dom_sel:
            filtered = filtered[filtered["domain"].isin(dom_sel)]
        if fld_flt:
            filtered = filtered[filtered["field"].fillna("").str.contains(fld_flt, case=False)]
        if subj_flt:
            filtered = filtered[filtered["subject_id"].fillna("").str.contains(subj_flt, case=False)]

        st.caption(f"Showing {len(filtered):,} of {len(_df):,} issues")

        # Show clinical_explanation (plain-English narrative) prominently
        display_cols = [
            "severity", "subject_id", "dataset", "domain", "field",
            "observed_value", "expected_behavior",
            "clinical_explanation",   # ← plain English narrative
            "rule_id", "visit", "als_reference", "issue_id",
        ]
        display_cols = [c for c in display_cols if c in filtered.columns]

        st.dataframe(
            filtered[display_cols],
            use_container_width=True,
            height=550,
            column_config={
                "severity":            st.column_config.TextColumn("Sev", width="small"),
                "subject_id":          st.column_config.TextColumn("Subject", width="small"),
                "clinical_explanation":st.column_config.TextColumn(
                    "Plain-English Narrative", width="large"),
                "observed_value":      st.column_config.TextColumn("Observed", width="medium"),
                "expected_behavior":   st.column_config.TextColumn("Expected", width="medium"),
            },
        )

# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 — RULE CATALOG
# ══════════════════════════════════════════════════════════════════════════════
with tab3:
    rdf = catalog.to_dataframe() if catalog else pd.DataFrame()
    st.subheader(f"Rule Catalog ({len(rdf):,} active rules)")

    if not rdf.empty:
        rc1, rc2 = st.columns(2)
        cls_opts = sorted(rdf["rule_class"].unique().tolist())
        src_opts = sorted(rdf["source_sheet"].unique().tolist())
        cls_sel  = rc1.multiselect("Rule Class",   cls_opts, default=cls_opts, key="rules_tab_class")
        src_sel  = rc2.multiselect("Source Sheet", src_opts, default=src_opts, key="rules_tab_source")

        fr = rdf[rdf["rule_class"].isin(cls_sel) & rdf["source_sheet"].isin(src_sel)]
        disp = ["rule_id", "rule_class", "source_sheet", "domain",
                "severity", "message", "als_reference"]
        st.dataframe(fr[[c for c in disp if c in fr.columns]],
                     use_container_width=True, height=520, hide_index=True)

# ══════════════════════════════════════════════════════════════════════════════
# TAB 4 — ALS EXPLORER
# ══════════════════════════════════════════════════════════════════════════════
with tab4:
    if als_obj is None:
        st.info("Upload an ALS workbook and run QC to explore it here.")
    else:
        als_tab = st.radio(
            "Explore ALS sheet",
            ["Checks", "Fields", "Forms", "Codelists"],
            horizontal=True,
        )

        if als_tab == "Checks":
            df_c = als_obj.checks.copy() if not als_obj.checks.empty else pd.DataFrame()
            if df_c.empty:
                st.warning("No checks loaded.")
            else:
                rt_col = "RuleType" if "RuleType" in df_c.columns else None
                if rt_col:
                    rt_opts = sorted(df_c[rt_col].dropna().unique().tolist())
                    rt_sel  = st.multiselect("Rule Type", rt_opts, default=rt_opts, key="als_explorer_rt")
                    df_c    = df_c[df_c[rt_col].isin(rt_sel)]
                st.caption(f"{len(df_c):,} checks")
                cols = ["CheckID", "Domain", "TargetFormOID", "TargetFieldOID",
                        "RuleType", "Severity", "Description", "QueryMessage"]
                st.dataframe(df_c[[c for c in cols if c in df_c.columns]],
                             use_container_width=True, height=500, hide_index=True)

        elif als_tab == "Fields":
            df_f = als_obj.fields.copy() if not als_obj.fields.empty else pd.DataFrame()
            if df_f.empty:
                st.warning("No fields loaded.")
            else:
                cols = ["FormOID", "FieldOID", "Domain", "IsRequired",
                        "Dictionary", "IsDerived", "IsHidden", "CriticalRole", "DataFormat"]
                st.caption(f"{len(df_f):,} fields")
                st.dataframe(df_f[[c for c in cols if c in df_f.columns]],
                             use_container_width=True, height=500, hide_index=True)

        elif als_tab == "Forms":
            df_frm = als_obj.forms.copy() if not als_obj.forms.empty else pd.DataFrame()
            st.caption(f"{len(df_frm):,} forms")
            st.dataframe(df_frm, use_container_width=True, height=400, hide_index=True)

        elif als_tab == "Codelists":
            codelists = als_obj.codelists if hasattr(als_obj, "codelists") else \
                        als_obj.dictionaries if hasattr(als_obj, "dictionaries") else {}
            if not codelists:
                st.warning("No codelists loaded.")
            else:
                cl_name = st.selectbox("Dictionary", sorted(codelists.keys()))
                if cl_name:
                    entries = codelists[cl_name]
                    if isinstance(entries, dict):
                        rows = [{"CodedValue": k, "DisplayLabel": v}
                                for k, v in entries.items()]
                    else:
                        rows = [{"CodedValue": v} for v in sorted(entries)]
                    st.write(f"**{cl_name}** — {len(rows)} entries")
                    st.dataframe(pd.DataFrame(rows),
                                 use_container_width=True, hide_index=True)

# ══════════════════════════════════════════════════════════════════════════════
# TAB 5 — EXPORT
# ══════════════════════════════════════════════════════════════════════════════
with tab5:
    st.subheader("Export Results")

    exporter = IssueExporter(issues, catalog_df=catalog.to_dataframe() if catalog else None)

    ec1, ec2, ec3 = st.columns(3)

    with ec1:
        st.markdown("#### 📊 Excel (7 sheets, audit-ready)")
        st.caption("Summary · All Issues · Critical · Major · Minor/Info · "
                   "Form Heatmap · Rule Catalog — plain-English narrative included")
        try:
            with tempfile.TemporaryDirectory() as td:
                out = Path(td) / "qc_report.xlsx"
                exporter.to_excel(out)
                st.download_button(
                    "⬇ Download Excel",
                    data=out.read_bytes(),
                    file_name=f"qc_issues_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    use_container_width=True,
                )
        except Exception as e:
            st.error(f"Excel error: {e}")

    with ec2:
        st.markdown("#### 📄 CSV")
        st.download_button(
            "⬇ Download CSV",
            data=exporter.dataframe.to_csv(index=False).encode("utf-8-sig"),
            file_name=f"qc_issues_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv",
            use_container_width=True,
        )

    with ec3:
        st.markdown("#### 📋 Rule Catalog CSV")
        if catalog:
            st.download_button(
                "⬇ Download Rule Catalog",
                data=catalog.to_dataframe().to_csv(index=False).encode("utf-8-sig"),
                file_name="rule_catalog_v3.csv",
                mime="text/csv",
                use_container_width=True,
            )
