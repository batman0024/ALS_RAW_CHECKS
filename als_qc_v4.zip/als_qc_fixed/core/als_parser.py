"""
core/als_parser.py  (V3 — corrected for actual ALS column names)
================================================================
Parses the real raw_details.xlsx ALS workbook.

Key fixes vs V2:
  - Forms:  OID -> FormOID, DraftFormActive -> Active (V2 used wrong names -> 0 rows matched)
  - Fields: DraftFieldActive -> Active, DataDictionaryName -> Dictionary,
            'Defaulted / Derived?' -> IsDerived, 'Field Hidden?' -> IsHidden,
            'Critical Data' / 'Critical - Safety' etc. -> CriticalRole
  - Checks: CheckName -> CheckID, CheckActive -> Active,
            'Target FormOID'/'Target FieldOID' preserved,
            Infix + Description parsed for pattern recognition
  - CustomFunctions: FunctionName -> CF_ID; SourceCode parsed for metadata
  - DataDictionaryEntries: loaded as lookup dict keyed by dictionary name
  - Folders: loaded for visit window context
"""

from __future__ import annotations
import json
import logging
import re
from pathlib import Path
from typing import Optional

import pandas as pd

logger = logging.getLogger(__name__)

FORMS_COLS = [
    "OID", "DraftFormName", "DraftFormActive", "LinkFolderOID",
]

FIELDS_COLS = [
    "FormOID", "FieldOID", "DraftFieldActive", "DataFormat",
    "ControlType", "DataDictionaryName", "LowerRange", "UpperRange",
    "IsRequired", "Defaulted / Derived?", "Field Hidden?",
    "Critical Data", "Critical - Safety", "Critical - Eligibility",
    "Critical - Consent", "Critical - Endpoint", "IsLog",
]

CHECKS_COLS = [
    "CheckName", "CheckActive", "Target FormOID", "Target FieldOID",
    "Infix", "Description of Logic", "Query Message",
    "Core/TA", "Associated Custom Function(s)", "Dynamic",
]

FOLDERS_COLS = [
    "OID", "FolderName", "Ordinal", "Target Days GSI",
    "Start Window GSI", "End Window GSI", "Overdue Days GSI",
    "Time Zero GSI", "IsReusable",
]

DD_COLS = ["DataDictionaryName", "CodedData", "UserDataString"]
CF_COLS = ["FunctionName", "SourceCode", "Lang"]


class ALSParser:
    """
    Parses the ALS Excel workbook into structured DataFrames using
    ACTUAL column names from raw_details.xlsx.
    """

    def __init__(self, path):
        self.path = Path(path)
        self.forms            = pd.DataFrame()
        self.fields           = pd.DataFrame()
        self.checks           = pd.DataFrame()
        self.folders          = pd.DataFrame()
        self.codelists        = {}   # dict_name -> set of coded values
        self.custom_functions = pd.DataFrame()
        self._errors          = []

    def parse(self):
        if not self.path.exists():
            raise FileNotFoundError(f"ALS not found: {self.path}")
        logger.info("Parsing ALS: %s", self.path.name)
        try:
            xl = pd.ExcelFile(self.path, engine="openpyxl")
        except Exception as exc:
            raise RuntimeError(f"Cannot open ALS workbook: {exc}") from exc

        self.forms            = self._parse_forms(xl)
        self.fields           = self._parse_fields(xl)
        self.checks           = self._parse_checks(xl)
        self.folders          = self._parse_folders(xl)
        self.codelists        = self._parse_codelists(xl)
        self.custom_functions = self._parse_custom_functions(xl)

        logger.info(
            "ALS parsed — forms:%d fields:%d checks:%d folders:%d codelists:%d CFs:%d",
            len(self.forms), len(self.fields), len(self.checks),
            len(self.folders), len(self.codelists), len(self.custom_functions),
        )
        return self

    def summary(self):
        active_checks = 0
        if not self.checks.empty and "Active" in self.checks.columns:
            active_checks = int(self.checks["Active"].sum())
        return {
            "forms_rows":             len(self.forms),
            "fields_rows":            len(self.fields),
            "checks_rows":            len(self.checks),
            "active_checks":          active_checks,
            "folders_rows":           len(self.folders),
            "codelist_dictionaries":  len(self.codelists),
            "codelist_total_entries": sum(len(v) for v in self.codelists.values()),
            "custom_functions_rows":  len(self.custom_functions),
            "parse_errors":           self._errors,
        }

    def _parse_forms(self, xl):
        if "Forms" not in xl.sheet_names:
            self._errors.append("Forms sheet not found")
            return pd.DataFrame()
        df = xl.parse("Forms")
        df = self._keep_cols(df, FORMS_COLS, "Forms")
        df = df.rename(columns={
            "OID":             "FormOID",
            "DraftFormName":   "FormName",
            "DraftFormActive": "Active",
        })
        df["Active"] = self._to_bool(df.get("Active"))
        return df[df["Active"] == True].reset_index(drop=True)

    def _parse_fields(self, xl):
        if "Fields" not in xl.sheet_names:
            self._errors.append("Fields sheet not found")
            return pd.DataFrame()
        df = xl.parse("Fields")
        df = self._keep_cols(df, FIELDS_COLS, "Fields")
        df = df.rename(columns={
            "DraftFieldActive":     "Active",
            "DataDictionaryName":   "Dictionary",
            "Defaulted / Derived?": "IsDerived",
            "Field Hidden?":        "IsHidden",
            "Critical Data":        "CriticalRole",
            "Critical - Safety":    "CriticalSafety",
            "Critical - Eligibility": "CriticalEligibility",
            "Critical - Consent":   "CriticalConsent",
            "Critical - Endpoint":  "CriticalEndpoint",
        })
        for col in ["Active", "IsRequired", "IsLog"]:
            if col in df.columns:
                df[col] = self._to_bool(df[col])
        for col in ["IsDerived", "IsHidden"]:
            if col in df.columns:
                df[col] = df[col].apply(
                    lambda v: bool(v) and str(v).strip().lower() not in ("", "no", "false", "0", "nan")
                )
        crit_cols = [c for c in ["CriticalRole","CriticalSafety","CriticalEligibility",
                                  "CriticalConsent","CriticalEndpoint"] if c in df.columns]
        if crit_cols:
            df["CriticalRole"] = df[crit_cols].apply(
                lambda row: any(
                    str(v).strip().lower() not in ("", "no", "false", "0", "nan", "none")
                    for v in row
                ), axis=1,
            )
        if "FormOID" in df.columns:
            df["Domain"] = df["FormOID"].apply(
                lambda v: str(v).split("_")[0].upper() if pd.notna(v) else "STUDY"
            )
        active = df[df.get("Active", pd.Series(True, index=df.index)) == True]
        return active.reset_index(drop=True)

    def _parse_checks(self, xl):
        if "Checks" not in xl.sheet_names:
            self._errors.append("Checks sheet not found")
            return pd.DataFrame()
        df = xl.parse("Checks")
        df = self._keep_cols(df, CHECKS_COLS, "Checks")
        df = df.rename(columns={
            "CheckName":        "CheckID",
            "CheckActive":      "Active",
            "Target FormOID":   "TargetFormOID",
            "Target FieldOID":  "TargetFieldOID",
            "Description of Logic": "Description",
            "Query Message":    "QueryMessage",
            "Core/TA":          "CoreTA",
            "Associated Custom Function(s)": "AssociatedCF",
        })
        df["Active"] = self._to_bool(df.get("Active"))
        df["Domain"]       = df["CheckID"].apply(self._extract_domain_from_check_id)
        df["RuleType"]     = df.apply(self._classify_check_rule_type, axis=1)
        df["ParsedTrigger"]= df.apply(self._parse_trigger_from_infix, axis=1)
        df["Severity"]     = df.apply(self._infer_severity, axis=1)
        return df[df["Active"] == True].reset_index(drop=True)

    def _parse_folders(self, xl):
        if "Folders" not in xl.sheet_names:
            return pd.DataFrame()
        df = xl.parse("Folders")
        df = self._keep_cols(df, FOLDERS_COLS, "Folders")
        df = df.rename(columns={
            "OID":              "FolderOID",
            "Target Days GSI":  "TargetDays",
            "Start Window GSI": "StartWindow",
            "End Window GSI":   "EndWindow",
            "Overdue Days GSI": "OverdueDays",
            "Time Zero GSI":    "TimeZero",
        })
        for col in ["TargetDays","StartWindow","EndWindow","OverdueDays"]:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce")
        return df.reset_index(drop=True)

    def _parse_codelists(self, xl):
        if "DataDictionaryEntries" not in xl.sheet_names:
            return {}
        df = xl.parse("DataDictionaryEntries")
        df = self._keep_cols(df, DD_COLS, "DataDictionaryEntries")
        codelists = {}
        for _, row in df.iterrows():
            name  = str(row.get("DataDictionaryName","") or "").strip()
            coded = str(row.get("CodedData","")          or "").strip()
            if name and coded:
                codelists.setdefault(name, set()).add(coded)
        return codelists

    def _parse_custom_functions(self, xl):
        if "CustomFunctions" not in xl.sheet_names:
            return pd.DataFrame()
        df = xl.parse("CustomFunctions")
        df = self._keep_cols(df, CF_COLS, "CustomFunctions")
        df = df.rename(columns={"FunctionName": "CF_ID"})
        df["InputFields"]   = df["SourceCode"].apply(self._extract_cf_inputs)
        df["OutputFields"]  = df["SourceCode"].apply(self._extract_cf_outputs)
        df["CFDescription"] = df["SourceCode"].apply(self._extract_cf_description)
        df["Domain"]        = df["CF_ID"].apply(self._extract_domain_from_check_id)
        return df.reset_index(drop=True)

    # ── classification helpers ────────────────────────────────────────────────

    @staticmethod
    def _classify_check_rule_type(row):
        desc  = str(row.get("Description","") or "").lower()
        infix = str(row.get("Infix","")       or "").lower()
        cid   = str(row.get("CheckID","")     or "").lower()
        if "postdose" in desc or ("hours" in desc and "after" in desc):
            return "VISIT_WINDOW"
        if re.search(r'\w+dat\b.{0,20}[<>]|\bstart\b.{0,20}\bdate\b.{0,30}\bbefore\b', desc):
            return "DATE_COMPARISON"
        if re.search(r'[<>]\s*\w+dat', desc):
            return "DATE_COMPARISON"
        if "appears when" in desc or "appears when" in infix:
            return "APPEARANCE"
        if "_cross" in cid:
            return "CROSS_FORM"
        if "form" in desc and ("present" in desc or "absent" in desc or "add" in desc):
            return "FORM_COMPLETENESS"
        if re.search(r'is not empty.{0,60}is empty|is empty.{0,60}is not empty|'
                     r'required.{0,30}empty|empty.{0,30}required', desc):
            return "CONDITIONAL_REQUIRED"
        if "lengthis" in infix:
            return "TEXT_LENGTH"
        if re.search(r'(conflict|inconsistent|cannot.*both|mutually)', desc):
            return "CONFLICTING_RECORD"
        return "OTHER"

    @staticmethod
    def _parse_trigger_from_infix(row):
        infix = str(row.get("Infix","") or "")
        trigger = {"form": None, "field": None, "operator": None, "value": None}
        m = re.search(
            r'If\s+(\w+)\s+in\s+([\w\s]+?)\s+'
            r'(IsEqualTo|IsNotEqualTo|IsNotEmpty|IsEmpty|IsGreaterThan|IsLessThan|LengthIsGreaterThan)\s*([^\s]+)?',
            infix, re.IGNORECASE,
        )
        if m:
            trigger["field"]    = m.group(1)
            trigger["operator"] = m.group(3).lower()
            trigger["value"]    = m.group(4).strip("\"' ") if m.group(4) else None
            trigger["form"]     = str(row.get("TargetFormOID","") or "").strip() or None
        return trigger

    @staticmethod
    def _infer_severity(row):
        desc  = str(row.get("Description","")  or "").lower()
        query = str(row.get("QueryMessage","") or "").lower()
        text  = desc + " " + query
        if any(k in text for k in ["cannot","must be","eligib","consent","enroll","critical"]):
            return "Critical"
        if any(k in text for k in ["reconcile","before","after","mismatch","inconsistent"]):
            return "Major"
        if any(k in text for k in ["verify","expected","unusual","codelist"]):
            return "Minor"
        if any(k in text for k in ["reminder","informational","n/a","appears when"]):
            return "Info"
        return "Major"

    @staticmethod
    def _extract_domain_from_check_id(check_id):
        parts = str(check_id or "").split(".")
        if len(parts) >= 2:
            candidate = parts[1].upper()
            if candidate not in ("D","D_AF","EP","CORE","GL","CF","RSG"):
                return candidate
            if len(parts) >= 3:
                return parts[2].split("_")[0].upper()
        return "STUDY"

    @staticmethod
    def _keep_cols(df, wanted, sheet):
        col_map = {c.strip().lower(): c for c in df.columns}
        keep = []
        for w in wanted:
            actual = col_map.get(w.strip().lower())
            if actual:
                keep.append(actual)
            else:
                logger.debug("[%s] Column not found (skipped): %s", sheet, w)
        return df[keep].copy() if keep else pd.DataFrame()

    @staticmethod
    def _to_bool(series):
        if series is None:
            return pd.Series(dtype=bool)
        return series.map(
            lambda v: str(v).strip().lower() in ("true","yes","1","y")
            if pd.notna(v) else False
        )

    @staticmethod
    def _extract_cf_description(src):
        if not src:
            return ""
        m = re.search(r'logic:\s*["\']?(.+?)(?:["\']?\n|_x000D_)', str(src), re.IGNORECASE)
        return m.group(1).strip() if m else ""

    @staticmethod
    def _extract_cf_inputs(src):
        if not src:
            return []
        return list(set(re.findall(r'\b([A-Z][A-Z0-9_]+\.[A-Z][A-Z0-9_]+)\b', str(src))))

    @staticmethod
    def _extract_cf_outputs(src):
        if not src:
            return []
        m = re.search(r'CF:\s*([\w.]+)', str(src))
        return [m.group(1)] if m else []
