"""
core/dataset_loader.py
======================
Clinical Dataset Loader — SAS7BDAT / XPT / CSV / Excel.

Domain name is inferred from the file stem (uppercased).
All columns are preserved as-is; case-insensitive access is handled
by ClinicalDataset.get_column().
"""

from __future__ import annotations
import logging
from pathlib import Path
from typing import Optional
import pandas as pd

from models.dataset import ClinicalDataset

logger = logging.getLogger(__name__)

SUPPORTED_EXTENSIONS = {".sas7bdat", ".xpt", ".csv", ".xlsx", ".xls"}


class DatasetLoader:
    """Load one or more clinical datasets into ClinicalDataset objects."""

    def __init__(self):
        self._datasets: dict[str, ClinicalDataset] = {}

    def load_file(self, path: str | Path) -> Optional[ClinicalDataset]:
        path = Path(path)
        ext = path.suffix.lower()
        if ext not in SUPPORTED_EXTENSIONS:
            logger.warning("Unsupported file type: %s", path)
            return None

        domain = path.stem.upper()
        try:
            df = self._read(path, ext)
            df.columns = [str(c).strip() for c in df.columns]
            ds = ClinicalDataset(domain=domain, data=df, source_path=str(path))
            self._datasets[domain] = ds
            logger.info("Loaded %s: %d rows × %d cols", domain, ds.row_count, len(ds.columns))
            return ds
        except Exception as exc:
            logger.error("Failed to load %s: %s", path, exc)
            return None

    def load_directory(self, directory: str | Path) -> dict[str, ClinicalDataset]:
        d = Path(directory)
        for f in sorted(d.iterdir()):
            if f.suffix.lower() in SUPPORTED_EXTENSIONS:
                self.load_file(f)
        return dict(self._datasets)

    def get(self, domain: str) -> Optional[ClinicalDataset]:
        return self._datasets.get(domain.upper())

    @property
    def loaded_domains(self) -> list[str]:
        return list(self._datasets.keys())

    @property
    def datasets(self) -> dict[str, ClinicalDataset]:
        return dict(self._datasets)

    # ── readers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _read(path: Path, ext: str) -> pd.DataFrame:
        if ext == ".sas7bdat":
            return DatasetLoader._read_sas7bdat(path)
        if ext == ".xpt":
            return pd.read_sas(str(path), format="xport", encoding="utf-8")
        if ext == ".csv":
            return pd.read_csv(str(path), dtype=str, encoding="utf-8-sig")
        if ext in {".xlsx", ".xls"}:
            engine = "openpyxl" if ext == ".xlsx" else "xlrd"
            return pd.read_excel(str(path), engine=engine, dtype=str)
        raise ValueError(f"No reader for extension: {ext}")

    @staticmethod
    def _read_sas7bdat(path: Path) -> pd.DataFrame:
        """Try pyreadstat first, fall back to pandas read_sas."""
        try:
            import pyreadstat
            df, meta = pyreadstat.read_sas7bdat(str(path))
            # Decode bytes columns
            for col in df.select_dtypes(include=["object"]).columns:
                df[col] = df[col].apply(
                    lambda x: x.decode("utf-8", errors="replace") if isinstance(x, bytes) else x
                )
            return df
        except ImportError:
            pass
        except Exception as exc:
            logger.warning("pyreadstat failed for %s: %s — trying pandas", path.name, exc)

        try:
            df = pd.read_sas(str(path), format="sas7bdat", encoding="utf-8")
            return df
        except Exception as exc:
            logger.warning("pandas read_sas failed for %s: %s — loading empty frame", path.name, exc)
            return pd.DataFrame()
