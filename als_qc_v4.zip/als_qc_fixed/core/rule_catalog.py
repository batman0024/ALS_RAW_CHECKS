"""
core/rule_catalog.py  (V3 — rebuilt for real ALS structure)
============================================================
Unified Rule Catalog Builder.

Fixes vs V2:
  - All column references now use the normalised names produced by the
    corrected ALSParser (e.g. CheckID not 'CheckName', Dictionary not
    'DataDictionaryName', etc.)
  - Codelists from DataDictionaryEntries are now injected and used for
    real CTL rule context
  - Severity is read from the parser-inferred Severity column (not guessed)
  - Rule classification uses the RuleType column from ALSParser
  - Checks rules are properly separated into date / conditional / cross-form etc.
  - CF rules leverage parsed InputFields / OutputFields from source code
  - Domain derivation uses the Domain column set by the parser
"""

from __future__ import annotations
import itertools
import json
import logging
from pathlib import Path
from typing import Optional

import pandas as pd

from models.rule import (
    QCRule, RuleClass, Severity, SourceSheet, RuleTrigger, RuleExpectation
)
from core.als_parser import ALSParser

logger = logging.getLogger(__name__)

_SCHEMA_PATH = Path(__file__).parent.parent / "schema" / "rule_schema.json"

try:
    import jsonschema as _js
    _JSONSCHEMA_OK = True
except ImportError:
    _JSONSCHEMA_OK = False


class RuleCatalog:
    def __init__(self):
        self._rules   = []
        self._counter = {}
        self._schema  = self._load_schema()
        self._codelists = {}

    # ── public ────────────────────────────────────────────────────────────────

    def build(self, als=None):
        self._rules.clear()
        self._counter.clear()

        if als is not None:
            self._codelists = getattr(als, "codelists", None) or getattr(als, "dictionaries", {}) or {}
            self._build_form_rules(als.forms)
            self._build_field_rules(als.fields)
            self._build_checks_rules(als.checks)
            self._build_cf_rules(als.custom_functions)
        else:
            logger.info("No ALS provided — built-in rules only.")

        self._build_builtin_rules()
        logger.info("Catalog built: %d active rules", len(self.active_rules))
        return self

    @property
    def all_rules(self):
        return list(self._rules)

    @property
    def active_rules(self):
        return [r for r in self._rules if r.active]

    def rules_for_domain(self, domain):
        return [r for r in self.active_rules if r.domain.upper() == domain.upper()]

    def to_dataframe(self):
        return pd.DataFrame([r.to_dict() for r in self.active_rules])

    def validate_rule(self, rule):
        if not _JSONSCHEMA_OK or self._schema is None:
            return []
        try:
            _js.validate(rule.to_dict(), self._schema)
            return []
        except _js.ValidationError as exc:
            return [exc.message]

    # ── Forms ─────────────────────────────────────────────────────────────────

    def _build_form_rules(self, forms):
        if forms is None or forms.empty:
            return
        for _, row in forms.iterrows():
            form_oid  = str(row.get("FormOID", "") or "")
            form_name = str(row.get("FormName", form_oid) or form_oid)
            domain    = form_oid.split("_")[0].upper() if form_oid else "STUDY"
            if not form_oid:
                continue
            rule_id = self._next_id(domain, RuleClass.FRM)
            self._add(QCRule(
                rule_id=rule_id,
                source_sheet=SourceSheet.FORMS,
                rule_class=RuleClass.FRM,
                domain=domain,
                trigger=RuleTrigger(form=form_oid, operator="absent"),
                expectation=RuleExpectation(form=form_oid, condition="form must be present"),
                severity=Severity.MAJOR,
                message=f"Form '{form_name}' ({form_oid}) is absent for this subject.",
                als_reference=f"Forms sheet: OID={form_oid}",
            ))

    # ── Fields ────────────────────────────────────────────────────────────────

    def _build_field_rules(self, fields):
        if fields is None or fields.empty:
            return
        for _, row in fields.iterrows():
            form_oid  = str(row.get("FormOID","")  or "")
            field_oid = str(row.get("FieldOID","") or "")
            domain    = str(row.get("Domain", form_oid.split("_")[0]).upper() or "STUDY")
            if not field_oid:
                continue

            # Skip derived / hidden / defaulted — no false positives
            if row.get("IsDerived") or row.get("IsHidden"):
                continue

            is_crit = bool(row.get("CriticalRole"))
            sev = Severity.CRITICAL if is_crit else Severity.MAJOR

            # 1. Requiredness
            if row.get("IsRequired"):
                rule_id = self._next_id(domain, RuleClass.FLD)
                self._add(QCRule(
                    rule_id=rule_id,
                    source_sheet=SourceSheet.FIELDS,
                    rule_class=RuleClass.FLD,
                    domain=domain,
                    trigger=RuleTrigger(form=form_oid, field=field_oid, operator="missing"),
                    expectation=RuleExpectation(form=form_oid, field=field_oid,
                                                condition="field must be populated"),
                    severity=sev,
                    message=(
                        f"Required field '{field_oid}' on form '{form_oid}' is missing. "
                        f"{'(Critical field)' if is_crit else ''} Missing required data "
                        f"violates data collection requirements."
                    ),
                    als_reference=f"Fields sheet: FormOID={form_oid}, FieldOID={field_oid}",
                ))

            # 2. Controlled terminology — use real codelist from DataDictionaryEntries
            dict_name = str(row.get("Dictionary","") or "").strip()
            if dict_name and dict_name.lower() not in ("nan","none",""):
                valid_terms = set(self._codelists.get(dict_name, set()) or [])
                rule_id = self._next_id(domain, RuleClass.CTL)
                self._add(QCRule(
                    rule_id=rule_id,
                    source_sheet=SourceSheet.FIELDS,
                    rule_class=RuleClass.CTL,
                    domain=domain,
                    trigger=RuleTrigger(form=form_oid, field=field_oid, operator="not_in_codelist"),
                    expectation=RuleExpectation(
                        form=form_oid, field=field_oid,
                        condition=f"value must be in dictionary '{dict_name}'"
                    ),
                    severity=Severity.MAJOR,
                    message=(
                        f"Field '{field_oid}' value is not in codelist '{dict_name}'. "
                        f"Invalid terminology compromises data standardisation. "
                        f"Valid values: {sorted(valid_terms)[:10]}"
                    ),
                    als_reference=f"Fields sheet: FormOID={form_oid}, FieldOID={field_oid}, Dict={dict_name}",
                    context={"dictionary": dict_name, "valid_terms": list(valid_terms), "valid_values": list(self._codelists.get(dict_name, []) or [])},
                ))

            # 3. Numeric range
            lower = row.get("LowerRange")
            upper = row.get("UpperRange")
            try:
                lower_f = float(lower) if pd.notna(lower) and str(lower).strip() else None
                upper_f = float(upper) if pd.notna(upper) and str(upper).strip() else None
            except (ValueError, TypeError):
                lower_f = upper_f = None

            if lower_f is not None or upper_f is not None:
                parts = []
                if lower_f is not None: parts.append(f">= {lower_f}")
                if upper_f is not None: parts.append(f"<= {upper_f}")
                range_str = " and ".join(parts)
                rule_id = self._next_id(domain, RuleClass.RNG)
                self._add(QCRule(
                    rule_id=rule_id,
                    source_sheet=SourceSheet.FIELDS,
                    rule_class=RuleClass.RNG,
                    domain=domain,
                    trigger=RuleTrigger(form=form_oid, field=field_oid, operator="out_of_range"),
                    expectation=RuleExpectation(form=form_oid, field=field_oid,
                                                condition=f"value must be {range_str}"),
                    severity=Severity.MAJOR,
                    message=f"Field '{field_oid}' is outside the defined range ({range_str}).",
                    als_reference=f"Fields sheet: FormOID={form_oid}, FieldOID={field_oid}",
                    context={"lower": lower_f, "upper": upper_f},
                ))

    # ── Checks ────────────────────────────────────────────────────────────────

    def _build_checks_rules(self, checks):
        if checks is None or checks.empty:
            return

        rule_type_to_class = {
            "DATE_COMPARISON":     RuleClass.TMP,
            "VISIT_WINDOW":        RuleClass.TMP,
            "CONDITIONAL_REQUIRED":RuleClass.DEP,
            "CROSS_FORM":          RuleClass.XFR,
            "FORM_COMPLETENESS":   RuleClass.XFR,
            "CONFLICTING_RECORD":  RuleClass.XFR,
            "APPEARANCE":          RuleClass.FLD,
            "TEXT_LENGTH":         RuleClass.FLD,
            "OTHER":               RuleClass.DEP,
        }

        for _, row in checks.iterrows():
            check_id   = str(row.get("CheckID","")         or "")
            domain     = str(row.get("Domain","STUDY")     or "STUDY").upper()
            tgt_form   = str(row.get("TargetFormOID","")   or "").strip()
            tgt_field  = str(row.get("TargetFieldOID","")  or "").strip() or None
            description= str(row.get("Description","")     or "")
            query_msg  = str(row.get("QueryMessage","")    or "")
            rule_type  = str(row.get("RuleType","OTHER")   or "OTHER")
            severity_s = str(row.get("Severity","Major")   or "Major")
            parsed_trig= row.get("ParsedTrigger") or {}
            if not isinstance(parsed_trig, dict):
                parsed_trig = {}

            rule_class = rule_type_to_class.get(rule_type, RuleClass.DEP)
            severity   = self._map_severity(severity_s)

            trigger_field = parsed_trig.get("field") or tgt_field
            trigger_form  = parsed_trig.get("form")  or tgt_form
            operator      = self._normalise_operator(str(parsed_trig.get("operator","") or ""))
            value         = parsed_trig.get("value")

            rule_id = self._next_id(domain, rule_class)
            msg = query_msg.strip() if query_msg.strip() and query_msg.strip().lower() not in ("n/a","na","none") else description
            if not msg:
                msg = f"Check '{check_id}' failed."

            self._add(QCRule(
                rule_id=rule_id,
                source_sheet=SourceSheet.CHECKS,
                rule_class=rule_class,
                domain=domain,
                trigger=RuleTrigger(
                    form=trigger_form or None,
                    field=trigger_field or None,
                    operator=operator or "present",
                    value=value,
                ),
                expectation=RuleExpectation(
                    form=tgt_form or None,
                    field=tgt_field or None,
                    condition=description[:200] if description else "See ALS check logic",
                ),
                severity=severity,
                message=msg[:400],
                als_reference=f"Checks sheet: CheckID={check_id}",
                context={"als_check_id": check_id, "rule_type": rule_type},
            ))

    # ── Custom Functions ──────────────────────────────────────────────────────

    def _build_cf_rules(self, cfs):
        if cfs is None or cfs.empty:
            return
        for _, row in cfs.iterrows():
            cf_id       = str(row.get("CF_ID","")       or "")
            domain      = str(row.get("Domain","STUDY") or "STUDY").upper()
            description = str(row.get("CFDescription","") or "")
            inputs      = row.get("InputFields") or []
            outputs     = row.get("OutputFields") or []

            if not cf_id:
                continue

            # Generate a DER rule: output field must be consistent when inputs exist
            output_ref = outputs[0] if outputs else ""
            out_parts  = output_ref.split(".") if "." in output_ref else [None, output_ref]
            out_form   = out_parts[0] if len(out_parts) > 1 else None
            out_field  = out_parts[-1] if out_parts else None

            rule_id = self._next_id(domain, RuleClass.DER)
            msg = (
                f"Custom Function '{cf_id}': {description[:200]}"
                if description
                else f"Custom Function '{cf_id}' — derived output consistency check."
            )
            self._add(QCRule(
                rule_id=rule_id,
                source_sheet=SourceSheet.CUSTOM_FUNCTIONS,
                rule_class=RuleClass.DER,
                domain=domain,
                trigger=RuleTrigger(form=out_form, field=out_field, operator="present"),
                expectation=RuleExpectation(
                    condition=f"CF '{cf_id}' output must be consistent with inputs: {inputs[:3]}"
                ),
                severity=Severity.MAJOR,
                message=msg,
                als_reference=f"CustomFunctions sheet: CF_ID={cf_id}",
                context={"cf_id": cf_id, "input_fields": inputs, "output_fields": outputs},
            ))

    # ── Built-ins ─────────────────────────────────────────────────────────────

    def _build_builtin_rules(self):
        builtins = [
            QCRule(
                rule_id="ALL_FLD_001",
                source_sheet=SourceSheet.BUILTIN,
                rule_class=RuleClass.FLD,
                domain="ALL",
                trigger=RuleTrigger(field="SUBJID", operator="missing"),
                expectation=RuleExpectation(field="SUBJID", condition="Subject ID (SUBJID/X_SUBJID) must be present on every record"),
                severity=Severity.CRITICAL,
                message="Subject ID (SUBJID) is missing. Every raw data record must have a subject identifier for traceability.",
                als_reference=None,
            ),
            QCRule(
                rule_id="ALL_FLD_002",
                source_sheet=SourceSheet.BUILTIN,
                rule_class=RuleClass.FLD,
                domain="ALL",
                trigger=RuleTrigger(field="SUBJID", operator="duplicate"),
                expectation=RuleExpectation(condition="each SUBJID+VISITNUM+record combination must be unique in raw data"),
                severity=Severity.MAJOR,
                message="Duplicate record detected: same SUBJID and VISITNUM appear more than once in raw data. Review for duplicate data entry.",
                als_reference=None,
            ),
            QCRule(
                rule_id="ALL_TMP_001",
                source_sheet=SourceSheet.BUILTIN,
                rule_class=RuleClass.TMP,
                domain="ALL",
                trigger=RuleTrigger(operator="present"),
                expectation=RuleExpectation(condition="event dates must not precede RFSTDTC"),
                severity=Severity.MAJOR,
                message="An event date precedes the reference start date (RFSTDTC). Possible data entry error.",
                als_reference=None,
            ),
            QCRule(
                rule_id="ALL_TMP_002",
                source_sheet=SourceSheet.BUILTIN,
                rule_class=RuleClass.TMP,
                domain="ALL",
                trigger=RuleTrigger(operator="present"),
                expectation=RuleExpectation(condition="date fields must not contain future dates beyond today"),
                severity=Severity.MAJOR,
                message="A date field contains a future date. Verify this is not a data entry error.",
                als_reference=None,
            ),
        ]
        for r in builtins:
            self._add(r)

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _add(self, rule):
        errs = self.validate_rule(rule)
        if errs:
            logger.debug("Rule %s schema warnings: %s", rule.rule_id, errs)
        self._rules.append(rule)

    def _next_id(self, domain, rule_class):
        key = f"{domain}_{rule_class.value}"
        if key not in self._counter:
            self._counter[key] = itertools.count(1)
        n = next(self._counter[key])
        return f"{domain}_{rule_class.value}_{n:03d}"

    @staticmethod
    def _normalise_operator(op):
        m = {
            "=":"equals","eq":"equals","isequaltoto":"equals","isequalto":"equals",
            "!=":"not_equals","ne":"not_equals","isnotequaltoto":"not_equals","isnotequalto":"not_equals",
            ">":"greater_than","gt":"greater_than","isgreaterthan":"greater_than",
            "<":"less_than","lt":"less_than","islessthan":"less_than",
            ">=":"gte","<=":"lte",
            "in":"in_list","not in":"not_in_list",
            "isnull":"missing","isblank":"missing","isempty":"missing",
            "notnull":"present","notblank":"present","isnotempty":"present",
        }
        return m.get(op.strip().lower(), op.lower() or "present")

    @staticmethod
    def _map_severity(s):
        m = {"critical":Severity.CRITICAL,"major":Severity.MAJOR,
             "minor":Severity.MINOR,"info":Severity.INFO}
        return m.get(str(s).strip().lower(), Severity.MAJOR)

    @staticmethod
    def _load_schema():
        try:
            with open(_SCHEMA_PATH) as f:
                return json.load(f)
        except Exception:
            return None


# ── Module-level helper functions (for testability) ───────────────────────────

def _classify_check(check_id: str, description: str, form: str, field: str) -> "RuleClass":
    """
    Classify a single ALS check into a RuleClass.
    Exposed at module level for unit testing.
    """
    import re
    from models.rule import RuleClass
    desc = description.lower()
    cid  = check_id.lower()
    if "_cross" in cid:
        return RuleClass.XFR
    # FORM.FIELD reference in description with AND/OR logic = cross-form
    import re as _r
    if _r.search(r'[A-Z]{2,}\.[A-Z]{2,}', description) and (' AND ' in description or ' OR ' in description):
        return RuleClass.XFR
    if re.search(r'\bdat\b|\bdate\b|\bdtc\b', field.lower()):
        return RuleClass.TMP
    if "before" in desc or "after" in desc or re.search(r'\w+dat\b', desc):
        return RuleClass.TMP
    if "if " in desc and ("then" in desc or "is not empty" in desc or "is empty" in desc):
        return RuleClass.DEP
    if "form" in desc and ("present" in desc or "absent" in desc):
        return RuleClass.XFR
    return RuleClass.DEP


def _infer_severity(check_id: str, description: str) -> "Severity":
    """
    Infer severity from check text. Exposed at module level for unit testing.
    """
    from models.rule import Severity
    text = (description or "").lower()
    if any(k in text for k in ["death","cannot","must be","eligib","consent","enroll","critical"]):
        return Severity.CRITICAL
    if any(k in text for k in ["reconcile","before","after","mismatch","inconsistent"]):
        return Severity.MAJOR
    if any(k in text for k in ["verify","expected","unusual"]):
        return Severity.MINOR
    return Severity.MAJOR
