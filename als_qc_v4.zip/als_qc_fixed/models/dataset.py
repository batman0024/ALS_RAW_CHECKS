"""
models/dataset.py
=================
Clinical Dataset Model wrapping a pandas DataFrame with domain metadata.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
import pandas as pd


@dataclass
class ClinicalDataset:
    """
    Wraps a raw clinical trial dataset with metadata.

    Subject ID note: raw EDC data uses SUBJID / X_SUBJID / PATID.
    USUBJID is a CDISC SDTM variable and will NOT be present in raw data.
    """
    domain:      str
    data:        pd.DataFrame
    source_path: Optional[str] = None
    row_count:   int = field(init=False)
    columns:     list = field(init=False)

    def __post_init__(self):
        self.row_count = len(self.data)
        self.columns   = list(self.data.columns)

    def get_subject_ids(self) -> list:
        """
        Return unique subject identifiers.
        Raw EDC data uses SUBJID/X_SUBJID — NOT USUBJID (which is SDTM/ADaM only).
        """
        _RAW_SUBJ = ["SUBJID", "X_SUBJID", "SUBJECTID", "PATID",
                     "SUBNO", "SUBJECT", "SUBJECTNO", "Z_SUBID",
                     "SCRNID", "USUBJID"]   # USUBJID last (SDTM fallback)
        for col in _RAW_SUBJ:
            if col in self.data.columns:
                return self.data[col].dropna().unique().tolist()
        return []

    def get_column(self, name: str) -> Optional[pd.Series]:
        """Case-insensitive column retrieval."""
        mapping = {c.upper(): c for c in self.data.columns}
        actual  = mapping.get(name.upper())
        return self.data[actual] if actual else None

    def has_column(self, name: str) -> bool:
        return name.upper() in {c.upper() for c in self.data.columns}

    def __repr__(self) -> str:
        return f"ClinicalDataset(domain={self.domain!r}, rows={self.row_count}, cols={len(self.columns)})"
