"""
models/issue.py
===============
Audit-Ready Issue Output Model.

Every emitted issue must be fully explainable with clinical context,
ALS provenance, and subject-level traceability.
"""

from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Optional
from datetime import datetime, timezone


@dataclass
class QCIssue:
    """
    Represents a single QC finding emitted by the execution engine.

    Fields are aligned with regulatory audit trail expectations (CDISC / 21 CFR Part 11).
    """
    # Identity
    issue_id:           str
    rule_id:            str
    severity:           str

    # Subject & dataset context
    subject_id:         str
    dataset:            str
    domain:             str

    # Location
    form:               Optional[str]
    field:              Optional[str]

    # Observed vs Expected
    observed_value:     Optional[Any]
    expected_behavior:  str

    # Explanation
    clinical_explanation: str
    als_reference:        Optional[str]

    # Metadata
    emitted_at:         str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    visit:              Optional[str] = None
    record_index:       Optional[int] = None

    # ── helpers ──────────────────────────────────────────────────────────────

    def to_dict(self) -> dict:
        return asdict(self)

    @staticmethod
    def columns() -> list[str]:
        return [
            "issue_id", "rule_id", "severity",
            "subject_id", "dataset", "domain",
            "form", "field",
            "observed_value", "expected_behavior",
            "clinical_explanation", "als_reference",
            "visit", "record_index", "emitted_at",
        ]

    def to_row(self) -> dict:
        """Return ordered dict aligned with columns() for DataFrame construction."""
        return {col: getattr(self, col, None) for col in self.columns()}

    def __repr__(self) -> str:
        return (
            f"QCIssue(id={self.issue_id!r}, rule={self.rule_id!r}, "
            f"subject={self.subject_id!r}, severity={self.severity!r})"
        )
