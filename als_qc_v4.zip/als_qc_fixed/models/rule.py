"""
models/rule.py
==============
Semantic Rule Model for ALS-driven Clinical Data QC System.

Every rule object captures full provenance, clinical intent, trigger, and
expectation — never raw executable logic.
"""

from __future__ import annotations
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Optional


# ──────────────────────────────────────────────────────────────────────────────
# Enumerations
# ──────────────────────────────────────────────────────────────────────────────

class RuleClass(str, Enum):
    FRM = "FRM"   # Form-level structural
    FLD = "FLD"   # Field-level validation
    CTL = "CTL"   # Controlled terminology
    RNG = "RNG"   # Numeric range
    TMP = "TMP"   # Temporal / date logic
    XFR = "XFR"   # Cross-form dependency
    DER = "DER"   # Derived consistency
    DEP = "DEP"   # Dependency


class Severity(str, Enum):
    CRITICAL = "Critical"
    MAJOR    = "Major"
    MINOR    = "Minor"
    INFO     = "Info"


class SourceSheet(str, Enum):
    FORMS            = "Forms"
    FIELDS           = "Fields"
    CHECKS           = "Checks"
    CUSTOM_FUNCTIONS = "CustomFunctions"
    BUILTIN          = "BuiltIn"


# ──────────────────────────────────────────────────────────────────────────────
# Trigger & Expectation sub-models
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class RuleTrigger:
    """Describes the condition that activates a rule."""
    form:     Optional[str] = None
    field:    Optional[str] = None
    operator: Optional[str] = None   # e.g. "equals", "present", "greater_than"
    value:    Optional[Any] = None

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class RuleExpectation:
    """Describes what must be true when the trigger fires."""
    form:      Optional[str] = None
    field:     Optional[str] = None
    condition: Optional[str] = None  # human-readable: "must be present", "must be ≤ 300"

    def to_dict(self) -> dict:
        return asdict(self)


# ──────────────────────────────────────────────────────────────────────────────
# Core Rule Model
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class QCRule:
    """
    Semantic QC rule with full ALS provenance.

    Naming convention: <DOMAIN>_<CLASS>_<NNN>
    Example: AE_DEP_010, LB_RNG_005
    """
    rule_id:       str
    source_sheet:  SourceSheet
    rule_class:    RuleClass
    domain:        str
    trigger:       RuleTrigger
    expectation:   RuleExpectation
    severity:      Severity
    message:       str                      # Clinical explanation
    als_reference: Optional[str]  = None   # e.g. "Fields sheet row 42, AESER"
    active:        bool            = True
    context:       dict            = field(default_factory=dict)  # visit, form scope, etc.

    # ── helpers ──────────────────────────────────────────────────────────────

    def to_dict(self) -> dict:
        d = {
            "rule_id":       self.rule_id,
            "source_sheet":  self.source_sheet.value,
            "rule_class":    self.rule_class.value,
            "domain":        self.domain,
            "trigger":       self.trigger.to_dict(),
            "expectation":   self.expectation.to_dict(),
            "severity":      self.severity.value,
            "message":       self.message,
            "als_reference": self.als_reference,
            "active":        self.active,
            "context":       self.context,
        }
        return d

    def __repr__(self) -> str:
        return (
            f"QCRule(id={self.rule_id!r}, class={self.rule_class.value}, "
            f"severity={self.severity.value})"
        )
