"""
qc/engine.py  —  V3 Fixed (Raw Data Edition)
=============================================
Key changes:
  - Subject ID resolution: raw datasets use SUBJID / X_SUBJID / PATID, NOT USUBJID
    USUBJID is a CDISC SDTM variable. Raw EDC data uses SUBJID or study-specific names.
  - _get_subject_id() tries SUBJID, X_SUBJID, SUBJECTID, PATID, SUBNO in order
  - ALL_FLD_001 checks for SUBJID (raw) not USUBJID
  - Duplicate key detection uses SUBJID-family columns
  - Parallel execution via ThreadPoolExecutor
  - SAS timedelta64 date handling fixed
  - Plain-English narrative in every issue
"""
from __future__ import annotations
import logging
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
import numpy as np
import pandas as pd

from models.rule import QCRule, RuleClass
from models.issue import QCIssue
from models.dataset import ClinicalDataset
from core.rule_catalog import RuleCatalog

logger = logging.getLogger(__name__)
SAS_EPOCH = pd.Timestamp("1960-01-01")

# Raw data subject ID candidates in priority order
# USUBJID is SDTM/ADaM — not used in raw EDC data
_SUBJ_COLS = ["SUBJID", "X_SUBJID", "SUBJECTID", "PATID", "SUBNO",
              "SUBJECT", "SUBJECTNO", "Z_SUBID", "SCRNID"]


def _to_datetime(series: pd.Series) -> pd.Series:
    """Convert SAS dates/datetimes/strings to pd.Timestamp series."""
    if pd.api.types.is_datetime64_any_dtype(series):
        return pd.to_datetime(series, errors="coerce")
    if pd.api.types.is_timedelta64_dtype(series):
        # pandas read_sas returns SAS DATETIME vars as timedelta from 1960 epoch
        return (SAS_EPOCH + series).dt.floor("s")
    numeric = pd.to_numeric(series, errors="coerce")
    if numeric.notna().mean() > 0.3:
        med = float(numeric.dropna().median()) if numeric.notna().any() else 0
        if med > 86400 * 365 * 10:
            # seconds since 1960 (SAS DATETIME)
            return pd.to_datetime(
                SAS_EPOCH + pd.to_timedelta(numeric.fillna(np.nan), unit="s"),
                errors="coerce")
        elif 1000 < med < 86400 * 365 * 100:
            # days since 1960 (SAS DATE)
            return pd.to_datetime(
                SAS_EPOCH + pd.to_timedelta(numeric.fillna(np.nan), unit="D"),
                errors="coerce")
    return pd.to_datetime(series, errors="coerce")


def _is_blank(val) -> bool:
    if val is None:
        return True
    if isinstance(val, float) and (np.isnan(val) or np.isinf(val)):
        return True
    return str(val).strip() in ("", ".", "nan", "NaN", "NaT", "None", "NA", "N/A")


def _blank_mask(col: pd.Series) -> pd.Series:
    return col.isna() | col.astype(str).str.strip().isin(
        ["", ".", "nan", "NaN", "NaT", "None", "NA", "N/A"])


def _find_subj_col(ds: "ClinicalDataset") -> str | None:
    """Return the actual subject-identifier column name for this dataset."""
    cols_upper = {c.upper(): c for c in ds.columns}
    for candidate in _SUBJ_COLS:
        if candidate.upper() in cols_upper:
            return cols_upper[candidate.upper()]
    return None


def _get_subject_id(row: pd.Series, subj_col: str | None) -> str:
    """Extract the subject ID from a row, using the raw-data column name."""
    if subj_col and subj_col in row.index:
        val = row.get(subj_col)
        if not _is_blank(val):
            return str(val).strip()
    # Fallback: try all candidates
    for c in _SUBJ_COLS:
        val = row.get(c)
        if val is not None and not _is_blank(val):
            return str(val).strip()
    return "UNKNOWN"


def _plain_narrative(dataset: str, subject: str, field: str | None,
                     observed, rule_msg: str, visit: str | None) -> str:
    """Plain-English narrative including raw dataset name."""
    parts = [f"Dataset: {dataset}"]
    if subject and subject not in ("UNKNOWN", "N/A", "ALL"):
        parts.append(f"Subject: {subject}")
    if visit:
        parts.append(f"Visit: {visit}")
    if field:
        parts.append(f"Field: {field}")
    if observed is not None and str(observed).strip() not in ("", "None"):
        parts.append(f"Observed: {observed}")
    parts.append(f"Issue: {rule_msg}")
    return " | ".join(parts)


class QCEngine:
    """Parallel, vectorised QC execution engine for raw EDC datasets."""

    def __init__(self, catalog: RuleCatalog,
                 als_parser=None,
                 max_workers: int = 6):
        self.catalog      = catalog
        self._als         = als_parser
        self._max_workers = max_workers
        self._issues:     list[QCIssue] = []
        self._today       = pd.Timestamp.today().normalize()

    def run(self, datasets: dict[str, ClinicalDataset]) -> list[QCIssue]:
        self._issues.clear()
        rules = self.catalog.active_rules
        logger.info("Engine: %d rules × %d datasets (workers=%d)",
                    len(rules), len(datasets), self._max_workers)

        domain_rules: dict[str, list[QCRule]] = {}
        for r in rules:
            domain_rules.setdefault(r.domain.upper(), []).append(r)

        def _run_domain(domain: str, ds: ClinicalDataset) -> list[QCIssue]:
            local: list[QCIssue] = []
            rule_set = domain_rules.get("ALL", []) + domain_rules.get(domain, [])
            for rule in rule_set:
                if rule.rule_id == "ALL_FLD_002":
                    local.extend(self._check_duplicates(rule, ds))
                    continue
                if rule.rule_id == "ALL_TMP_002":
                    local.extend(self._check_future_dates(rule, ds))
                    continue
                try:
                    local.extend(self._execute_rule(rule, ds, datasets))
                except Exception as exc:
                    logger.warning("Rule %s on %s: %s", rule.rule_id, domain, exc)
            return local

        with ThreadPoolExecutor(max_workers=self._max_workers) as pool:
            futs = {pool.submit(_run_domain, dom, ds): dom
                    for dom, ds in datasets.items()}
            for fut in as_completed(futs):
                try:
                    self._issues.extend(fut.result())
                except Exception as exc:
                    logger.error("Domain %s: %s", futs[fut], exc)

        logger.info("Done: %d issues", len(self._issues))
        return list(self._issues)

    def to_dataframe(self) -> pd.DataFrame:
        if not self._issues:
            return pd.DataFrame(columns=QCIssue.columns())
        return pd.DataFrame([i.to_row() for i in self._issues])

    # ── dispatch ──────────────────────────────────────────────────────────────

    def _execute_rule(self, rule: QCRule, ds: ClinicalDataset,
                      all_ds: dict) -> list[QCIssue]:
        dispatch = {
            RuleClass.FRM: self._check_frm,
            RuleClass.FLD: self._check_fld,
            RuleClass.CTL: self._check_ctl,
            RuleClass.RNG: self._check_rng,
            RuleClass.TMP: self._check_tmp,
            RuleClass.XFR: self._check_xfr,
            RuleClass.DER: self._check_der,
            RuleClass.DEP: self._check_dep,
        }
        fn = dispatch.get(rule.rule_class)
        return fn(rule, ds, all_ds) if fn else []

    # ── FRM ───────────────────────────────────────────────────────────────────

    def _check_frm(self, rule, ds, _):
        if ds.row_count == 0:
            return [self._single(rule, ds, "ALL",
                                 f"Form/dataset '{ds.domain}' has 0 records", None)]
        return []

    # ── FLD ───────────────────────────────────────────────────────────────────

    def _check_fld(self, rule, ds, _):
        field = rule.trigger.field
        if not field:
            return []

        # Subject ID check — raw data uses SUBJID family, NOT USUBJID
        if field.upper() in ("SUBJID", "X_SUBJID"):
            subj_col = _find_subj_col(ds)
            if subj_col is None:
                return [self._single(rule, ds, "N/A",
                                     f"{ds.domain}: No subject ID column found "
                                     f"(tried: {', '.join(_SUBJ_COLS[:4])})", None)]
            col = ds.get_column(subj_col)
            return [self._emit(rule, ds, ds.data.loc[i], i, None, subj_col)
                    for i in ds.data[_blank_mask(col)].index]

        if not ds.has_column(field):
            return []
        col = ds.get_column(field)
        return [self._emit(rule, ds, ds.data.loc[i], i, None)
                for i in ds.data[_blank_mask(col)].index]

    def _check_duplicates(self, rule, ds):
        """Duplicate record detection using raw subject ID."""
        subj_col = _find_subj_col(ds)
        candidates = [subj_col] if subj_col else []
        candidates += ["VISITNUM", "VISIT", "AETERM", "LBTESTCD", "MHTERM",
                       "CMTRT", "VISITDAT", "ADTPT"]
        key_cols = [c for c in candidates if c and ds.has_column(c)]
        if len(key_cols) < 2:
            return []
        actual = [ds.get_column(c).name for c in key_cols]
        dupes  = ds.data[ds.data.duplicated(subset=actual, keep=False)]
        return [self._emit(rule, ds, dupes.loc[i], i,
                           " | ".join(f"{c}={dupes.loc[i].get(c,'')}" for c in actual),
                           subj_col)
                for i in dupes.index]

    # ── CTL ───────────────────────────────────────────────────────────────────

    def _check_ctl(self, rule, ds, _):
        field      = rule.trigger.field
        if not field or not ds.has_column(field):
            return []
        vv         = rule.context.get("valid_values") or rule.context.get("valid_terms") or []
        if not vv:
            return []
        valid_set   = {str(v).strip() for v in vv}
        display_map = rule.context.get("display_labels", {})
        col         = ds.get_column(field)
        not_blank   = ~_blank_mask(col)
        col_str     = col.astype(str).str.strip()
        violates    = not_blank & ~col_str.isin(valid_set)
        issues      = []
        for i in ds.data[violates].index:
            obs = str(col.loc[i]).strip()
            label_hint = display_map.get(obs, "")
            obs_display = f"{obs} ('{label_hint}')" if label_hint and label_hint != obs else obs
            valid_sample = ", ".join(
                f"{c}={display_map[c]}" if c in display_map else c
                for c in list(valid_set)[:5]
            ) + ("…" if len(valid_set) > 5 else "")
            issues.append(self._emit(rule, ds, ds.data.loc[i], i,
                                     f"{obs_display} — not in [{valid_sample}]"))
        return issues

    # ── RNG ───────────────────────────────────────────────────────────────────

    def _check_rng(self, rule, ds, _):
        field = rule.trigger.field
        if not field or not ds.has_column(field):
            return []
        lower  = rule.context.get("lower")
        upper  = rule.context.get("upper")
        num    = pd.to_numeric(ds.get_column(field), errors="coerce")
        mask   = pd.Series(False, index=num.index)
        if lower is not None:
            try: mask = mask | (num.notna() & (num < float(lower)))
            except: pass
        if upper is not None:
            try: mask = mask | (num.notna() & (num > float(upper)))
            except: pass
        return [self._emit(rule, ds, ds.data.loc[i], i, float(num.loc[i]))
                for i in ds.data[mask].index]

    # ── TMP ───────────────────────────────────────────────────────────────────

    def _check_tmp(self, rule, ds, _):
        if rule.rule_id == "ALL_TMP_001":
            return self._check_rfstdtc(rule, ds)
        tf = rule.trigger.field
        ef = rule.expectation.field
        if tf and ef and ds.has_column(tf) and ds.has_column(ef):
            ca = _to_datetime(ds.get_column(tf))
            cb = _to_datetime(ds.get_column(ef))
            both = ca.notna() & cb.notna()
            viol = ds.data[both & (ca > cb)]
            return [self._emit(rule, ds, viol.loc[i], i,
                               f"{tf}={ca[i]!s} > {ef}={cb[i]!s}")
                    for i in viol.index]
        return []

    def _check_rfstdtc(self, rule, ds):
        """Check event dates don't precede reference start."""
        # Raw data may use RFSTDAT, VISITDAT, RFSTDTC
        ref_candidates = ["RFSTDTC", "RFSTDAT", "RFSTDATE", "STARTDAT"]
        ref_col = None
        for rc in ref_candidates:
            if ds.has_column(rc):
                ref_col = rc
                break
        if not ref_col:
            return []
        rfst = _to_datetime(ds.get_column(ref_col))
        issues = []
        for cn in [c for c in ds.columns
                   if any(k in c.upper() for k in ["DTC", "STDAT", "STARTDAT", "STDATE"])
                   and c.upper() != ref_col.upper()]:
            try:
                ev   = _to_datetime(ds.get_column(cn))
                both = rfst.notna() & ev.notna()
                viol = ds.data[both & (ev < rfst)]
                for i in viol.index:
                    issues.append(self._emit(rule, ds, viol.loc[i], i,
                                             f"{cn}={ev[i]!s} < {ref_col}={rfst[i]!s}"))
            except Exception as exc:
                logger.debug("RFSTDTC check on %s.%s: %s", ds.domain, cn, exc)
        return issues

    def _check_future_dates(self, rule, ds):
        """ALL_TMP_002 — handles timedelta, float SAS dates, strings."""
        issues = []
        for cn in [c for c in ds.columns
                   if any(k in c.upper() for k in
                          ["DTC", "DAT", "DATE", "STDAT", "ENDAT", "VISITDAT"])]:
            try:
                col  = _to_datetime(ds.get_column(cn))
                viol = ds.data[col.notna() & (col > self._today)]
                for i in viol.index:
                    issues.append(self._emit(rule, ds, viol.loc[i], i, f"{cn}={col[i]!s}"))
            except Exception as exc:
                logger.debug("Future date check %s.%s: %s", ds.domain, cn, exc)
        return issues

    # ── XFR ───────────────────────────────────────────────────────────────────

    def _check_xfr(self, rule, ds, all_ds):
        tgt = (rule.expectation.form or rule.trigger.form or "").upper()
        if not tgt:
            return []
        tgt_ds = all_ds.get(tgt)
        if tgt_ds is None:
            return []
        src_subj_col = _find_subj_col(ds)
        tgt_subj_col = _find_subj_col(tgt_ds)
        if src_subj_col is None or tgt_subj_col is None:
            return []
        src_s = set(ds.data[src_subj_col].dropna().astype(str))
        tgt_s = set(tgt_ds.data[tgt_subj_col].dropna().astype(str))
        return [self._single(rule, ds, subj,
                             f"Subject in {ds.domain} but absent from {tgt}", None)
                for subj in sorted(src_s - tgt_s)[:50]]

    # ── DER / DEP ─────────────────────────────────────────────────────────────

    def _check_der(self, rule, ds, _):
        field = rule.trigger.field
        if not field or not ds.has_column(field):
            return []
        col = ds.get_column(field)
        return [self._emit(rule, ds, ds.data.loc[i], i, None)
                for i in ds.data[_blank_mask(col)].index]

    def _check_dep(self, rule, ds, _):
        field = rule.trigger.field
        if not field or not ds.has_column(field):
            return []
        col = ds.get_column(field)
        return [self._emit(rule, ds, ds.data.loc[i], i, None)
                for i in ds.data[_blank_mask(col)].index]

    # ── emit helpers ──────────────────────────────────────────────────────────

    def _emit(self, rule, ds, row, idx, observed_value,
              subj_col: str | None = None) -> QCIssue:
        sc    = subj_col or _find_subj_col(ds)
        subj  = _get_subject_id(row, sc)
        # Fallback visit column — raw data may use VISITDAT, VISIT, VISITNO
        visit = None
        for vc in ["VISIT", "VISITNO", "VISITNUM", "VISITDAT", "ADTPT"]:
            v = row.get(vc)
            if v is not None and not _is_blank(v):
                visit = str(v).strip()
                break
        narr = _plain_narrative(ds.domain, subj, rule.trigger.field,
                                observed_value, rule.message, visit)
        return QCIssue(
            issue_id=f"ISS-{uuid.uuid4().hex[:8].upper()}",
            rule_id=rule.rule_id, severity=rule.severity.value,
            subject_id=subj, dataset=ds.domain, domain=rule.domain,
            form=rule.trigger.form, field=rule.trigger.field,
            observed_value=str(observed_value) if observed_value is not None else "",
            expected_behavior=rule.expectation.condition or "",
            clinical_explanation=narr,
            als_reference=rule.als_reference,
            visit=visit, record_index=int(idx) if idx is not None else None,
        )

    def _single(self, rule, ds, subject_id, observed_value, record_index) -> QCIssue:
        narr = _plain_narrative(ds.domain, subject_id, rule.trigger.field,
                                observed_value, rule.message, None)
        return QCIssue(
            issue_id=f"ISS-{uuid.uuid4().hex[:8].upper()}",
            rule_id=rule.rule_id, severity=rule.severity.value,
            subject_id=subject_id, dataset=ds.domain, domain=rule.domain,
            form=rule.trigger.form, field=rule.trigger.field,
            observed_value=str(observed_value) if observed_value is not None else "",
            expected_behavior=rule.expectation.condition or "",
            clinical_explanation=narr,
            als_reference=rule.als_reference,
            visit=None, record_index=record_index,
        )
