"""tests/test_engine.py — V3 Fixed: SUBJID raw data, DuplicateWidgetID, SAS dates"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))
import re, unittest, pandas as pd, numpy as np
from core.rule_catalog import RuleCatalog
from core.dataset_loader import DatasetLoader
from models.dataset import ClinicalDataset
from models.rule import QCRule, RuleClass, Severity, SourceSheet, RuleTrigger, RuleExpectation
from qc.engine import QCEngine, _to_datetime, _blank_mask, _find_subj_col, _get_subject_id

def _ds(data, dom="TEST"):
    return ClinicalDataset(domain=dom, data=pd.DataFrame(data))

def _rule(rid, rc, field=None, form=None, op="missing", sev=Severity.MAJOR, ctx=None):
    return QCRule(rid, SourceSheet.BUILTIN, rc, "TEST",
                  RuleTrigger(form=form, field=field, operator=op),
                  RuleExpectation(condition="test"), sev, "test rule", context=ctx or {})

def _cat(*rules):
    c = RuleCatalog(); [c._add(r) for r in rules]; return c


class TestRawSubjectIDResolution(unittest.TestCase):
    """Raw data uses SUBJID/X_SUBJID — NOT USUBJID (which is SDTM)."""

    def test_subjid_detected(self):
        ds = _ds({"SUBJID": ["001"], "AETERM": ["Pain"]})
        self.assertEqual(_find_subj_col(ds), "SUBJID")

    def test_x_subjid_detected(self):
        ds = _ds({"X_SUBJID": ["A01"], "AETERM": ["Pain"]})
        self.assertEqual(_find_subj_col(ds), "X_SUBJID")

    def test_patid_detected(self):
        ds = _ds({"PATID": ["P1"], "AETERM": ["Pain"]})
        self.assertEqual(_find_subj_col(ds), "PATID")

    def test_subjid_takes_priority_over_x_subjid(self):
        # SUBJID is higher priority than X_SUBJID
        ds = _ds({"SUBJID": ["001"], "X_SUBJID": ["A01"], "AETERM": ["Pain"]})
        self.assertEqual(_find_subj_col(ds), "SUBJID")

    def test_no_subj_col_returns_none(self):
        ds = _ds({"AETERM": ["Pain"]})
        self.assertIsNone(_find_subj_col(ds))

    def test_get_subject_id_from_row(self):
        row = pd.Series({"SUBJID": "001", "AETERM": "Pain"})
        self.assertEqual(_get_subject_id(row, "SUBJID"), "001")

    def test_get_subject_id_x_subjid(self):
        row = pd.Series({"X_SUBJID": "A01", "AETERM": "Pain"})
        self.assertEqual(_get_subject_id(row, "X_SUBJID"), "A01")

    def test_dataset_get_subject_ids_uses_subjid(self):
        ds = _ds({"SUBJID": ["001", "002"], "AETERM": ["Pain", "Nausea"]})
        ids = ds.get_subject_ids()
        self.assertIn("001", ids)
        self.assertIn("002", ids)

    def test_dataset_prefers_subjid_over_usubjid(self):
        # USUBJID should be last resort (SDTM only)
        ds = _ds({"SUBJID": ["001"], "USUBJID": ["STUDY-001"]})
        ids = ds.get_subject_ids()
        self.assertIn("001", ids)  # SUBJID wins

    def test_builtin_rule_uses_subjid(self):
        cat = RuleCatalog().build(als=None)
        fld_rules = [r for r in cat.active_rules
                     if r.rule_id == "ALL_FLD_001"]
        self.assertEqual(len(fld_rules), 1)
        self.assertEqual(fld_rules[0].trigger.field, "SUBJID")

    def test_missing_subjid_emits_critical(self):
        cat = RuleCatalog().build(als=None)
        ds = _ds({"SUBJID": [None, "002"], "AETERM": ["Pain", "Nausea"]})
        ds.domain = "ALL"
        issues = QCEngine(cat).run({"ALL": ds})
        subjid_issues = [i for i in issues if i.rule_id == "ALL_FLD_001"]
        self.assertGreater(len(subjid_issues), 0)
        self.assertEqual(subjid_issues[0].severity, "Critical")

    def test_x_subjid_dataset_runs_without_crash(self):
        """X_SUBJID is a real dataset name (Image 3 shows X_SUBJID: 70 rows)."""
        cat = RuleCatalog().build(als=None)
        ds = _ds({"X_SUBJID": ["001", "002"], "SCRNID": ["SCR001", "SCR002"]})
        ds.domain = "X_SUBJID"
        issues = QCEngine(cat).run({"X_SUBJID": ds})
        # No crash
        self.assertIsInstance(issues, list)


class TestDuplicateWidgetIDFix(unittest.TestCase):
    """Image 1 & 2: DuplicateWidgetID on st.multiselect without key=."""

    def test_all_multiselects_have_unique_keys(self):
        main_path = Path(__file__).parent.parent / "app" / "main.py"
        text = main_path.read_text()
        # Extract all key= values from multiselect calls
        key_pattern = re.compile(
            r'st\.multiselect\([^)]+key\s*=\s*["\']([^"\']+)["\']', re.DOTALL)
        keys = key_pattern.findall(text)
        from collections import Counter
        dupes = {k: v for k, v in Counter(keys).items() if v > 1}
        self.assertEqual(dupes, {}, f"Duplicate widget keys: {dupes}")

    def test_issues_tab_has_key(self):
        main_path = Path(__file__).parent.parent / "app" / "main.py"
        text = main_path.read_text()
        self.assertIn("issues_tab_sev", text)
        self.assertIn("issues_tab_dom", text)

    def test_rules_tab_has_key(self):
        main_path = Path(__file__).parent.parent / "app" / "main.py"
        text = main_path.read_text()
        self.assertIn("rules_tab_class", text)
        self.assertIn("rules_tab_source", text)


class TestSASDateFix(unittest.TestCase):
    """ALL_TMP_002 was crashing on timedelta64 values (Image 2 & 3)."""

    def test_timedelta_no_crash(self):
        s = pd.Series([pd.Timedelta(seconds=335880311)])
        result = _to_datetime(s)
        self.assertTrue(result.notna().any())

    def test_timedelta_future_detected(self):
        future_s = int((pd.Timestamp("2099-01-01") -
                        pd.Timestamp("1960-01-01")).total_seconds())
        s = pd.Series([pd.Timedelta(seconds=future_s)])
        result = _to_datetime(s)
        self.assertGreater(result.iloc[0], pd.Timestamp.today())

    def test_future_date_rule_on_timedelta(self):
        cat = RuleCatalog().build(als=None)
        future_td = pd.Timedelta(seconds=int(
            (pd.Timestamp("2099-01-01") - pd.Timestamp("1960-01-01")).total_seconds()))
        ds = _ds({"SUBJID": ["001"], "AESTDTC": [future_td]})
        ds.domain = "ALL"
        issues = QCEngine(cat).run({"ALL": ds})
        self.assertGreater(len([i for i in issues if i.rule_id == "ALL_TMP_002"]), 0)


class TestPlainNarrative(unittest.TestCase):
    def test_narrative_has_dataset_and_subject(self):
        cat = RuleCatalog().build(als=None)
        ds = _ds({"SUBJID": [None, "002"], "AETERM": ["Pain", "Nausea"]})
        ds.domain = "AE"
        ds.domain = "ALL"
        issues = QCEngine(cat).run({"ALL": ds})
        for iss in issues:
            self.assertIn("Dataset:", iss.clinical_explanation)


class TestDatasetLoader(unittest.TestCase):
    def test_datasets_property_not_loaded(self):
        loader = DatasetLoader()
        self.assertTrue(hasattr(loader, "datasets"))
        self.assertFalse(hasattr(loader, "_loaded"),
                         "loader._loaded must not exist (it caused AttributeError)")


class TestCTLCheck(unittest.TestCase):
    def test_invalid_value_with_label(self):
        r = _rule("T_CTL_001", RuleClass.CTL, field="AESER", op="not_in_codelist",
                  ctx={"valid_values": ["Y", "N"],
                       "display_labels": {"Y": "Yes", "N": "No"}})
        issues = QCEngine(_cat(r)).run(
            {"TEST": _ds({"SUBJID": ["001"], "AESER": ["INVALID"]})})
        self.assertEqual(len(issues), 1)
        self.assertIn("INVALID", issues[0].observed_value)

    def test_empty_codelist_no_phantom(self):
        r = _rule("T_CTL_001", RuleClass.CTL, field="AESER", op="not_in_codelist",
                  ctx={"valid_values": [], "display_labels": {}})
        issues = QCEngine(_cat(r)).run(
            {"TEST": _ds({"SUBJID": ["001"], "AESER": ["X"]})})
        self.assertEqual(len(issues), 0)


class TestMultipleReruns(unittest.TestCase):
    def test_engine_run_twice_same_count(self):
        cat = RuleCatalog().build(als=None)
        ds = _ds({"SUBJID": [None, "002"]})
        ds.domain = "ALL"
        e = QCEngine(cat)
        r1 = e.run({"ALL": ds})
        r2 = e.run({"ALL": ds})
        self.assertEqual(len(r1), len(r2))

    def test_issue_ids_unique_per_run(self):
        cat = RuleCatalog().build(als=None)
        ds = _ds({"SUBJID": [None]})
        ds.domain = "ALL"
        e = QCEngine(cat)
        r1 = e.run({"ALL": ds})
        r2 = e.run({"ALL": ds})
        ids1 = {i.issue_id for i in r1}
        ids2 = {i.issue_id for i in r2}
        self.assertEqual(len(ids1 & ids2), 0)


if __name__ == "__main__":
    unittest.main()
