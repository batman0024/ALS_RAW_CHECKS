"""tests/test_models.py — data model serialisation and repr tests."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import unittest
import pandas as pd
from models.rule import QCRule, RuleClass, Severity, SourceSheet, RuleTrigger, RuleExpectation
from models.issue import QCIssue
from models.dataset import ClinicalDataset


class TestQCRule(unittest.TestCase):
    def _rule(self):
        return QCRule(
            rule_id="AE_FLD_001",
            source_sheet=SourceSheet.FIELDS,
            rule_class=RuleClass.FLD,
            domain="AE",
            trigger=RuleTrigger(form="AE", field="AETERM", operator="missing"),
            expectation=RuleExpectation(form="AE", field="AETERM", condition="must be populated"),
            severity=Severity.MAJOR,
            message="Required field AETERM is missing.",
        )

    def test_to_dict_has_required_keys(self):
        d = self._rule().to_dict()
        for k in ["rule_id", "source_sheet", "rule_class", "domain",
                  "trigger", "expectation", "severity", "message"]:
            self.assertIn(k, d)

    def test_repr_contains_rule_id(self):
        self.assertIn("AE_FLD_001", repr(self._rule()))

    def test_active_default_true(self):
        self.assertTrue(self._rule().active)


class TestQCIssue(unittest.TestCase):
    def _issue(self):
        return QCIssue(
            issue_id="ISS-ABCD1234",
            rule_id="AE_FLD_001",
            severity="Major",
            subject_id="SUBJ-001",
            dataset="AE",
            domain="AE",
            form="AE",
            field="AETERM",
            observed_value=None,
            expected_behavior="must be populated",
            clinical_explanation="AETERM is required.",
            als_reference="Fields sheet row 1",
        )

    def test_to_row_aligned_with_columns(self):
        row = self._issue().to_row()
        for col in QCIssue.columns():
            self.assertIn(col, row)

    def test_emitted_at_auto_set(self):
        self.assertIsNotNone(self._issue().emitted_at)

    def test_repr_contains_issue_id(self):
        self.assertIn("ISS-ABCD1234", repr(self._issue()))


class TestClinicalDataset(unittest.TestCase):
    def _ds(self):
        df = pd.DataFrame({"USUBJID": ["S001","S002"], "AETERM": ["Pain","Nausea"]})
        return ClinicalDataset(domain="AE", data=df)

    def test_row_count_auto_set(self):
        self.assertEqual(self._ds().row_count, 2)

    def test_columns_auto_set(self):
        self.assertIn("USUBJID", self._ds().columns)

    def test_get_column_case_insensitive(self):
        col = self._ds().get_column("usubjid")
        self.assertIsNotNone(col)

    def test_has_column_case_insensitive(self):
        self.assertTrue(self._ds().has_column("aeterm"))
        self.assertFalse(self._ds().has_column("NOTHERE"))

    def test_get_subject_ids(self):
        ids = self._ds().get_subject_ids()
        self.assertIn("S001", ids)


if __name__ == "__main__":
    unittest.main()
