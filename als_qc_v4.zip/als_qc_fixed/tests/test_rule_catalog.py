"""
tests/test_rule_catalog.py
===========================
Unit tests for RuleCatalog builder.
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

import re
import unittest
import pandas as pd

from core.rule_catalog import RuleCatalog, _classify_check, _infer_severity
from core.als_parser import ALSParser
from models.rule import RuleClass, Severity, SourceSheet


class TestBuiltinRules(unittest.TestCase):
    def setUp(self):
        self.catalog = RuleCatalog().build(als=None)

    def test_builtin_usubjid_present(self):
        ids = [r.rule_id for r in self.catalog.active_rules]
        self.assertIn("ALL_FLD_001", ids)

    def test_builtin_rfstdtc_present(self):
        ids = [r.rule_id for r in self.catalog.active_rules]
        self.assertIn("ALL_TMP_001", ids)

    def test_builtin_future_date_present(self):
        ids = [r.rule_id for r in self.catalog.active_rules]
        self.assertIn("ALL_TMP_002", ids)

    def test_builtin_duplicate_key_present(self):
        ids = [r.rule_id for r in self.catalog.active_rules]
        self.assertIn("ALL_FLD_002", ids)

    def test_usubjid_is_critical(self):
        r = next(r for r in self.catalog.active_rules if r.rule_id == "ALL_FLD_001")
        self.assertEqual(r.severity, Severity.CRITICAL)

    def test_no_als_still_runs(self):
        c = RuleCatalog().build(als=None)
        self.assertGreater(len(c.active_rules), 0)


class TestRuleIdTaxonomy(unittest.TestCase):
    PATTERN = re.compile(r'^[A-Z0-9]+_(FRM|FLD|CTL|RNG|TMP|XFR|DER|DEP)_\d{3}$')

    def setUp(self):
        self.catalog = RuleCatalog().build(als=None)

    def test_all_builtin_rule_ids_match_pattern(self):
        for r in self.catalog.active_rules:
            self.assertRegex(r.rule_id, self.PATTERN,
                             msg=f"Rule ID {r.rule_id!r} does not match taxonomy pattern")


class TestFieldRuleGeneration(unittest.TestCase):
    def _make_als_with_fields(self, fields_df):
        als = ALSParser.__new__(ALSParser)
        als.forms = pd.DataFrame()
        als.fields = fields_df
        als.checks = pd.DataFrame()
        als.custom_functions = pd.DataFrame()
        als.dictionaries = {}
        als.unit_dicts = {}
        als._parse_errors = []
        return als

    def test_required_field_generates_fld_rule(self):
        fields = pd.DataFrame([{
            "FormOID": "AE", "FieldOID": "AETERM", "Active": True,
            "IsRequired": True, "IsHidden": False, "IsDerived": False,
            "Dictionary": None, "LowerRange": None, "UpperRange": None,
        }])
        als = self._make_als_with_fields(fields)
        catalog = RuleCatalog().build(als=als)
        fld_rules = [r for r in catalog.active_rules if r.rule_class == RuleClass.FLD
                     and r.trigger.field == "AETERM"]
        self.assertTrue(len(fld_rules) >= 1)

    def test_derived_field_skipped(self):
        fields = pd.DataFrame([{
            "FormOID": "AE", "FieldOID": "AEDERIVEDFIELD", "Active": True,
            "IsRequired": True, "IsHidden": False, "IsDerived": True,
            "Dictionary": None, "LowerRange": None, "UpperRange": None,
        }])
        als = self._make_als_with_fields(fields)
        catalog = RuleCatalog().build(als=als)
        derived_rules = [r for r in catalog.active_rules
                         if r.trigger.field == "AEDERIVEDFIELD"]
        self.assertEqual(len(derived_rules), 0)

    def test_hidden_field_skipped(self):
        fields = pd.DataFrame([{
            "FormOID": "AE", "FieldOID": "AEHIDDENFIELD", "Active": True,
            "IsRequired": True, "IsHidden": True, "IsDerived": False,
            "Dictionary": None, "LowerRange": None, "UpperRange": None,
        }])
        als = self._make_als_with_fields(fields)
        catalog = RuleCatalog().build(als=als)
        hidden_rules = [r for r in catalog.active_rules
                        if r.trigger.field == "AEHIDDENFIELD"]
        self.assertEqual(len(hidden_rules), 0)

    def test_dictionary_generates_ctl_rule(self):
        fields = pd.DataFrame([{
            "FormOID": "AE", "FieldOID": "AESER", "Active": True,
            "IsRequired": False, "IsHidden": False, "IsDerived": False,
            "Dictionary": "YesNo", "LowerRange": None, "UpperRange": None,
        }])
        als = self._make_als_with_fields(fields)
        als.dictionaries = {"YesNo": ["Y", "N"]}
        catalog = RuleCatalog().build(als=als)
        ctl_rules = [r for r in catalog.active_rules if r.rule_class == RuleClass.CTL
                     and r.trigger.field == "AESER"]
        self.assertEqual(len(ctl_rules), 1)
        self.assertEqual(ctl_rules[0].context["valid_values"], ["Y", "N"])

    def test_range_generates_rng_rule(self):
        fields = pd.DataFrame([{
            "FormOID": "VS", "FieldOID": "VSTESTCD", "Active": True,
            "IsRequired": False, "IsHidden": False, "IsDerived": False,
            "Dictionary": None, "LowerRange": 0, "UpperRange": 300,
        }])
        als = self._make_als_with_fields(fields)
        catalog = RuleCatalog().build(als=als)
        rng_rules = [r for r in catalog.active_rules if r.rule_class == RuleClass.RNG
                     and r.trigger.field == "VSTESTCD"]
        self.assertEqual(len(rng_rules), 1)
        self.assertEqual(rng_rules[0].context["lower"], 0)
        self.assertEqual(rng_rules[0].context["upper"], 300)


class TestCheckClassification(unittest.TestCase):
    def test_cross_form_is_xfr(self):
        cls = _classify_check("0036.AE.AEACN",
                              "AE.AESER = Y AND STUDCOMP.COMPREAS = DT",
                              "AE", "AEACN")
        self.assertEqual(cls, RuleClass.XFR)

    def test_date_field_is_tmp(self):
        cls = _classify_check("0030.AE.AESTDAT",
                              "AESTDAT before RFSTDTC",
                              "AE", "AESTDAT")
        self.assertEqual(cls, RuleClass.TMP)

    def test_conditional_logic_is_dep(self):
        cls = _classify_check("CHECK001",
                              "If AESER is Y then AESDTH is not empty",
                              "AE", "AESDTH")
        self.assertEqual(cls, RuleClass.DEP)


class TestSeverityInference(unittest.TestCase):
    def test_death_is_critical(self):
        sev = _infer_severity("0039.AE.AESER", "DEATH date present")
        self.assertEqual(sev, Severity.CRITICAL)

    def test_date_check_is_major(self):
        sev = _infer_severity("DATE_CHECK", "start date before end date")
        self.assertEqual(sev, Severity.MAJOR)


if __name__ == "__main__":
    unittest.main()
