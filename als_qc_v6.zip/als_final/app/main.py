"""
app/main.py  —  V5 Final
=========================
Fixes applied:
  1. Local run stability — st.rerun() only called after run, not inside tabs
  2. Performance — spinner wraps only the heavy work; progress bar completes
     before st.rerun(); char scanner runs automatically with QC (no separate button)
  3. pd.to_datetime UserWarning suppressed at module level in engine.py
  4. Dashboard: grouped KPIs, rule-type breakdown, top-issues table, no blank
  5. Codelist: UserDataString used as display label AND as additional valid term
  6. Expected_behavior column: clean text, no extra quotes/brackets
  7. Special char scanner: runs automatically alongside QC, results cached
  8. Excel: new "Collapsed Issues" tab — if same rule fires on >10 unique subjects,
     one row with first 5 subjects collated in a column
"""
import sys
import io
import json
import logging
import tempfile
import time
import warnings
from pathlib import Path
from datetime import datetime

# Suppress openpyxl header/footer warning before any import
warnings.filterwarnings("ignore", message="Cannot parse header or footer")

ROOT = Path(__file__).parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import pandas as pd
import streamlit as st

from core.als_parser     import ALSParser
from core.dataset_loader import DatasetLoader
from core.rule_catalog   import RuleCatalog
from qc.engine           import QCEngine
from qc.exporter         import IssueExporter

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)

# ── Page ──────────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="ALS QC Engine V5",
    page_icon="🧬",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
  .main .block-container{padding-top:1rem;max-width:1500px}
  .kpi{background:#1e2633;border:1px solid #2d3748;border-radius:10px;
       padding:14px 10px;text-align:center}
  .kpi h2{margin:0;font-size:1.7rem;font-weight:800}
  .kpi p{margin:4px 0 0;color:#8b9ab1;font-size:.78rem}
  .section-header{font-size:1.05rem;font-weight:700;color:#4a9eff;
                  border-left:3px solid #4a9eff;padding-left:8px;margin:1rem 0 .4rem}
  div[data-testid="stMetricValue"]{font-size:1.5rem}
</style>
""", unsafe_allow_html=True)

# ── Session defaults ───────────────────────────────────────────────────────────
_DEFAULTS = {
    "issues": [], "rule_catalog": None, "datasets": {},
    "als_summary": None, "als_obj": None,
    "run_complete": False, "run_count": 0, "elapsed": 0.0,
    "char_scan_df": None,   # auto-populated during QC run
    "issue_df": None,       # cached DataFrame
}
for k, v in _DEFAULTS.items():
    if k not in st.session_state:
        st.session_state[k] = v

# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### 🧬 ALS QC Engine V5")
    st.caption("Clinical Trial Raw Data QC")
    st.divider()

    st.subheader("① ALS Contract")
    als_file = st.file_uploader(
        "ALS Excel (.xlsx)", type=["xlsx"],
        help="Upload raw_details.xlsx or any study ALS workbook.",
        key="als_upload",
    )
    if als_file:
        st.success(f"✓ {als_file.name}")

    st.subheader("② Raw Datasets")
    dataset_files = st.file_uploader(
        "SAS7BDAT / XPT / CSV / Excel",
        type=["sas7bdat", "xpt", "csv", "xlsx"],
        accept_multiple_files=True, key="data_upload",
    )
    if dataset_files:
        st.success(f"✓ {len(dataset_files)} file(s)")

    st.divider()
    workers = st.slider("⚡ Parallel workers", 1, 12, 6)

    run_btn = st.button(
        "▶  Run QC",
        type="primary",
        disabled=not bool(dataset_files),
        use_container_width=True,
        key="run_button",
    )
    if st.button("🔄 Clear & Reset", use_container_width=True):
        for k, v in _DEFAULTS.items():
            st.session_state[k] = v
        st.rerun()

    st.divider()
    if st.session_state["run_complete"]:
        m = st.session_state
        st.caption(
            f"Run #{m['run_count']} · {m['elapsed']:.1f}s · "
            f"{len(m['issues']):,} issues · {len(m['datasets'])} datasets"
        )
    st.caption(f"V5 · {datetime.now().strftime('%Y-%m-%d')}")


# ── Special-char scanner (runs as part of QC, not separately) ─────────────────
_SUBJ_PRIORITY = ["SUBJID", "X_SUBJID", "SUBJECTID", "PATID", "SUBNO"]

def _char_description(code: int) -> str:
    _names = {
        0:"NULL",1:"SOH",2:"STX",3:"ETX",4:"EOT",5:"ENQ",6:"ACK",
        7:"BEL",8:"BS (backspace)",9:"HT (tab)",10:"LF (newline)",
        11:"VT",12:"FF",13:"CR (carriage-return)",27:"ESC",127:"DEL",
        160:"NBSP",173:"SHY",8203:"ZWS",8204:"ZWNJ",8205:"ZWJ",
        8206:"LRM",8207:"RLM",65279:"BOM",
    }
    if code in _names: return _names[code]
    if code < 32: return f"Control (ASCII {code})"
    if 128 <= code <= 159: return f"Latin-1 control U+{code:04X}"
    try:
        import unicodedata
        return unicodedata.name(chr(code), f"U+{code:04X}")
    except Exception:
        return f"Non-ASCII U+{code:04X}"

def _scan_special_chars(dsets: dict) -> pd.DataFrame:
    """Scan all string columns for non-printable / non-ASCII characters."""
    rows = []
    for domain, ds in dsets.items():
        subj_col = next(
            (c for cand in _SUBJ_PRIORITY for c in ds.data.columns
             if c.upper() == cand), None
        )
        str_cols = [c for c in ds.data.columns
                    if ds.data[c].dtype == object
                    or str(ds.data[c].dtype).startswith("string")]
        for col_name in str_cols:
            for idx, val in ds.data[col_name].items():
                if val is None:
                    continue
                s = str(val)
                for pos, ch in enumerate(s):
                    code = ord(ch)
                    if code < 32 or code == 127 or code > 127:
                        subj = str(ds.data.loc[idx, subj_col]) \
                               if subj_col and subj_col in ds.data.columns else "N/A"
                        rows.append({
                            "domain": domain, "column": col_name,
                            "subject": subj, "row_index": idx,
                            "observed": repr(s)[:80], "char": repr(ch),
                            "ordinal": code, "hex": f"0x{code:04X}",
                            "utf8_bytes": ch.encode("utf-8").hex().upper(),
                            "position": pos,
                            "description": _char_description(code),
                        })
    cols = ["domain","column","subject","row_index","observed",
            "char","ordinal","hex","utf8_bytes","position","description"]
    return pd.DataFrame(rows, columns=cols) if rows else pd.DataFrame(columns=cols)


# ── Run QC ────────────────────────────────────────────────────────────────────
if run_btn and dataset_files:
    t0 = time.time()
    _progress = st.progress(0, "Setting up…")

    tmpdir = tempfile.mkdtemp()

    _progress.progress(10, "Loading datasets…")
    loader = DatasetLoader()
    _load_warns = []
    for uf in dataset_files:
        fpath = Path(tmpdir) / uf.name
        fpath.write_bytes(uf.read())
        try:
            loader.load_file(fpath)
        except Exception as exc:
            _load_warns.append(f"{uf.name}: {exc}")
    datasets = loader.datasets
    for w in _load_warns:
        st.sidebar.warning(w)

    _progress.progress(25, "Parsing ALS…")
    als, als_summary = None, {}
    if als_file:
        als_path = Path(tmpdir) / als_file.name
        als_path.write_bytes(als_file.read())
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                als = ALSParser(als_path).parse()
            als_summary = als.summary()
        except Exception as exc:
            st.sidebar.warning(f"ALS error: {exc} — built-in rules only.")

    _progress.progress(40, "Building rule catalog…")
    catalog = RuleCatalog().build(als=als)

    _progress.progress(55, f"Running {len(catalog.active_rules):,} rules…")
    engine  = QCEngine(catalog, als_parser=als, max_workers=workers)
    issues  = engine.run(datasets)

    _progress.progress(75, "Scanning for special characters…")
    char_df = _scan_special_chars(datasets)

    elapsed = time.time() - t0
    _progress.progress(100, f"✅ Done — {len(issues):,} issues in {elapsed:.1f}s")

    # Build cached issue DataFrame
    issue_df = pd.DataFrame([i.to_row() for i in issues]) if issues else pd.DataFrame()

    st.session_state.update({
        "issues":       issues,
        "issue_df":     issue_df,
        "rule_catalog": catalog,
        "datasets":     datasets,
        "als_summary":  als_summary,
        "als_obj":      als,
        "run_complete": True,
        "run_count":    st.session_state["run_count"] + 1,
        "elapsed":      elapsed,
        "char_scan_df": char_df,
    })
    st.success(
        f"✅ QC complete — **{len(issues):,} issues** · "
        f"**{len(datasets)} datasets** · "
        f"**{len(catalog.active_rules):,} rules** · "
        f"**{elapsed:.1f}s**"
    )
    # Do NOT call st.rerun() here — just render results below


# ── Landing ────────────────────────────────────────────────────────────────────
if not st.session_state["run_complete"]:
    st.title("🧬 ALS-Driven Clinical Data QC System V5")
    st.markdown("Upload datasets in the sidebar, then click **▶ Run QC**.")
    with st.expander("ℹ️ Checks performed", expanded=True):
        c1, c2 = st.columns(2)
        with c1:
            st.markdown("""
**Field-level** · Required fields · Codelist (UserDataString labels)  
**Range** · LowerRange / UpperRange / NC ranges  
**Temporal** · Future dates · RFSTDTC · Start > End  
**Subject** · SUBJID / X_SUBJID / PATID family  
""")
        with c2:
            st.markdown("""
**Cross-form** · Subject consistency across datasets  
**Duplicates** · Key-field duplicate detection  
**Special chars** · Non-printable / non-ASCII (auto)  
**ALS-driven** · 988 edit checks · 97 codelists  
""")
    st.stop()

# ── Pull from session ─────────────────────────────────────────────────────────
issues   = st.session_state["issues"]
catalog  = st.session_state["rule_catalog"]
datasets = st.session_state["datasets"]
als_obj  = st.session_state["als_obj"]
als_sum  = st.session_state.get("als_summary") or {}
char_df  = st.session_state.get("char_scan_df")
_df      = st.session_state.get("issue_df") or (
    pd.DataFrame([i.to_row() for i in issues]) if issues else pd.DataFrame()
)

# ── Tabs ──────────────────────────────────────────────────────────────────────
tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
    "📊 Dashboard", "🚨 Issues", "📋 Rules",
    "🔍 Char Scanner", "🔭 ALS Explorer", "📤 Export",
])

# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 — DASHBOARD  (no blank: all computed from cached _df)
# ══════════════════════════════════════════════════════════════════════════════
with tab1:
    total    = len(issues)
    critical = int((_df["severity"] == "Critical").sum()) if not _df.empty else 0
    major    = int((_df["severity"] == "Major").sum())    if not _df.empty else 0
    minor    = int((_df["severity"] == "Minor").sum())    if not _df.empty else 0
    info_cnt = int((_df["severity"] == "Info").sum())     if not _df.empty else 0
    subjects = int(_df["subject_id"].nunique())           if not _df.empty else 0
    domains  = int(_df["domain"].nunique())               if not _df.empty else 0
    n_rules  = len(catalog.active_rules) if catalog else 0
    elapsed  = st.session_state["elapsed"]

    # ── KPI row 1 ─────────────────────────────────────────────────────────
    st.markdown('<div class="section-header">Issue Summary</div>', unsafe_allow_html=True)
    k1,k2,k3,k4,k5,k6,k7 = st.columns(7)
    for col_w, lbl, val, color in [
        (k1,"Total",     total,    "#e6edf3"),
        (k2,"🔴 Critical",critical,"#ff6b6b"),
        (k3,"🟠 Major",  major,    "#ffa94d"),
        (k4,"🟡 Minor",  minor,    "#ffd43b"),
        (k5,"🔵 Info",   info_cnt, "#74c0fc"),
        (k6,"Subjects",  subjects, "#a8d8a8"),
        (k7,"Domains",   domains,  "#d4a8f0"),
    ]:
        col_w.markdown(
            f'<div class="kpi"><h2 style="color:{color}">{val:,}</h2>'
            f'<p>{lbl}</p></div>', unsafe_allow_html=True)

    # ── KPI row 2: run metadata ────────────────────────────────────────────
    st.markdown('<div class="section-header">Run Metadata</div>', unsafe_allow_html=True)
    m1,m2,m3,m4 = st.columns(4)
    m1.metric("⏱ Elapsed",      f"{elapsed:.1f}s")
    m2.metric("Rules applied",   f"{n_rules:,}")
    m3.metric("Datasets loaded", len(datasets))
    m4.metric("Run #",           st.session_state["run_count"])

    if not _df.empty:
        st.divider()
        # ── Row 1: Charts ─────────────────────────────────────────────────
        g1, g2, g3 = st.columns(3)
        with g1:
            st.markdown('<div class="section-header">By Severity</div>', unsafe_allow_html=True)
            sev_c = _df["severity"].value_counts().reset_index()
            sev_c.columns = ["Severity","Count"]
            st.bar_chart(sev_c.set_index("Severity")["Count"], height=200)

        with g2:
            st.markdown('<div class="section-header">By Domain (top 15)</div>', unsafe_allow_html=True)
            dom_c = _df["domain"].value_counts().head(15).reset_index()
            dom_c.columns = ["Domain","Count"]
            st.bar_chart(dom_c.set_index("Domain")["Count"], height=200)

        with g3:
            st.markdown('<div class="section-header">By Rule Class</div>', unsafe_allow_html=True)
            cls_c = _df["rule_id"].str.extract(r'_([A-Z]+)_\d+')[0].value_counts().reset_index()
            cls_c.columns = ["Class","Count"]
            st.bar_chart(cls_c.set_index("Class")["Count"], height=200)

        # ── Row 2: Tables ─────────────────────────────────────────────────
        t1, t2 = st.columns(2)
        with t1:
            st.markdown('<div class="section-header">Top 10 Rules by Issue Count</div>', unsafe_allow_html=True)
            top_rules = _df["rule_id"].value_counts().head(10).reset_index()
            top_rules.columns = ["Rule ID","Count"]
            st.dataframe(top_rules, use_container_width=True, hide_index=True, height=220)

        with t2:
            st.markdown('<div class="section-header">Top 10 Subjects by Issue Count</div>', unsafe_allow_html=True)
            top_subj = _df["subject_id"].value_counts().head(10).reset_index()
            top_subj.columns = ["Subject","Count"]
            st.dataframe(top_subj, use_container_width=True, hide_index=True, height=220)

        # ── Domain × Severity heatmap ──────────────────────────────────────
        st.markdown('<div class="section-header">Domain × Severity Heatmap</div>', unsafe_allow_html=True)
        piv = _df.groupby(["domain","severity"]).size().unstack(fill_value=0)
        for s in ["Critical","Major","Minor","Info"]:
            if s not in piv.columns: piv[s] = 0
        piv["Total"] = piv.sum(axis=1)
        piv = piv.sort_values("Total", ascending=False)
        st.dataframe(
            piv.style
               .background_gradient(subset=["Critical"], cmap="Reds")
               .background_gradient(subset=["Major"],    cmap="Oranges")
               .background_gradient(subset=["Total"],    cmap="Blues"),
            use_container_width=True, height=280,
        )

        # ── Field breakdown ────────────────────────────────────────────────
        st.markdown('<div class="section-header">Top 10 Fields with Most Issues</div>', unsafe_allow_html=True)
        fld_c = _df["field"].dropna().value_counts().head(10).reset_index()
        fld_c.columns = ["Field","Count"]
        st.bar_chart(fld_c.set_index("Field")["Count"], height=180)

    # ── ALS + Datasets inventory ──────────────────────────────────────────
    st.divider()
    inv1, inv2 = st.columns(2)
    with inv1:
        st.markdown('<div class="section-header">Loaded Datasets</div>', unsafe_allow_html=True)
        ds_rows = [{"Domain": d, "Rows": ds.row_count, "Cols": len(ds.columns)}
                   for d, ds in sorted(datasets.items())]
        st.dataframe(pd.DataFrame(ds_rows), use_container_width=True,
                     hide_index=True, height=300)
    with inv2:
        if als_sum:
            st.markdown('<div class="section-header">ALS Contract</div>', unsafe_allow_html=True)
            a1,a2,a3,a4,a5 = st.columns(5)
            a1.metric("Forms",      als_sum.get("forms_rows",0))
            a2.metric("Fields",     als_sum.get("fields_rows",0))
            a3.metric("Checks",     als_sum.get("checks_rows",0))
            a4.metric("Codelists",  als_sum.get("codelist_dictionaries",0))
            a5.metric("Custom Fns", als_sum.get("custom_functions_rows",0))

        # Char scan summary on dashboard
        if char_df is not None and not char_df.empty:
            st.markdown('<div class="section-header">⚠️ Special Characters Detected</div>',
                        unsafe_allow_html=True)
            st.warning(
                f"**{len(char_df):,} occurrences** across "
                f"**{char_df['column'].nunique()}** columns in "
                f"**{char_df['domain'].nunique()}** datasets. "
                f"See **🔍 Char Scanner** tab for details."
            )

# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 — ISSUES
# ══════════════════════════════════════════════════════════════════════════════
with tab2:
    if _df.empty:
        st.info("No issues found.")
    else:
        st.subheader(f"Quality Control Issues ({len(_df):,})")

        f1,f2,f3,f4,f5 = st.columns(5)
        sev_opts = sorted(_df["severity"].unique().tolist())
        dom_opts = sorted(_df["domain"].unique().tolist())
        sev_sel  = f1.multiselect("Severity",  sev_opts, default=sev_opts, key="iss_sev")
        dom_sel  = f2.multiselect("Domain",    dom_opts, default=[],        key="iss_dom")
        fld_flt  = f3.text_input("Field",      "",  key="iss_fld")
        subj_flt = f4.text_input("Subject",    "",  key="iss_subj")
        rule_flt = f5.text_input("Rule ID",    "",  key="iss_rule")

        flt = _df[_df["severity"].isin(sev_sel)]
        if dom_sel:  flt = flt[flt["domain"].isin(dom_sel)]
        if fld_flt:  flt = flt[flt["field"].fillna("").str.contains(fld_flt, case=False)]
        if subj_flt: flt = flt[flt["subject_id"].fillna("").str.contains(subj_flt, case=False)]
        if rule_flt: flt = flt[flt["rule_id"].fillna("").str.contains(rule_flt, case=False)]

        st.caption(f"Showing {len(flt):,} of {len(_df):,} issues")

        disp_cols = ["severity","subject_id","dataset","domain","field",
                     "observed_value","expected_behavior",
                     "clinical_explanation","rule_id","visit","issue_id"]
        disp_cols = [c for c in disp_cols if c in flt.columns]

        st.dataframe(
            flt[disp_cols],
            use_container_width=True, height=520,
            column_config={
                "severity":            st.column_config.TextColumn("Sev", width="small"),
                "subject_id":          st.column_config.TextColumn("Subject", width="small"),
                "clinical_explanation":st.column_config.TextColumn("Narrative", width="large"),
                "observed_value":      st.column_config.TextColumn("Observed", width="medium"),
                "expected_behavior":   st.column_config.TextColumn("Expected", width="medium"),
            },
        )

# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 — RULES
# ══════════════════════════════════════════════════════════════════════════════
with tab3:
    rdf = catalog.to_dataframe() if catalog else pd.DataFrame()
    st.subheader(f"Rule Catalog ({len(rdf):,} active rules)")
    if not rdf.empty:
        rc1,rc2 = st.columns(2)
        cls_sel = rc1.multiselect("Rule Class",   sorted(rdf["rule_class"].unique()),
                                  default=sorted(rdf["rule_class"].unique()), key="rules_cls")
        src_sel = rc2.multiselect("Source Sheet", sorted(rdf["source_sheet"].unique()),
                                  default=sorted(rdf["source_sheet"].unique()), key="rules_src")
        fr = rdf[rdf["rule_class"].isin(cls_sel) & rdf["source_sheet"].isin(src_sel)]
        disp = ["rule_id","rule_class","source_sheet","domain","severity","message","als_reference"]
        st.dataframe(fr[[c for c in disp if c in fr.columns]],
                     use_container_width=True, height=520, hide_index=True)

# ══════════════════════════════════════════════════════════════════════════════
# TAB 4 — CHAR SCANNER (results already computed; no separate run needed)
# ══════════════════════════════════════════════════════════════════════════════
with tab4:
    st.subheader("🔍 Special / Non-Printable Character Scanner")
    st.caption(
        "Automatically scanned during QC run. Results show non-printable, "
        "hidden, zero-width, or non-ASCII characters found in raw data."
    )

    if char_df is None:
        st.info("Run QC to populate this tab.")
    elif char_df.empty:
        st.success("✅ No special characters found across all datasets.")
    else:
        st.warning(
            f"⚠️ **{len(char_df):,} occurrences** in "
            f"**{char_df['column'].nunique()}** columns across "
            f"**{char_df['domain'].nunique()}** datasets."
        )
        cf1,cf2 = st.columns(2)
        sc_doms = cf1.multiselect("Domain", sorted(char_df["domain"].unique()),
                                  default=sorted(char_df["domain"].unique()),
                                  key="char_dom")
        sc_cols = cf2.multiselect("Column", sorted(char_df["column"].unique()),
                                  default=sorted(char_df["column"].unique()),
                                  key="char_col")
        show = char_df[char_df["domain"].isin(sc_doms) & char_df["column"].isin(sc_cols)]
        st.caption(f"Showing {len(show):,} of {len(char_df):,}")
        st.dataframe(show, use_container_width=True, height=420, hide_index=True,
            column_config={
                "ordinal": st.column_config.NumberColumn("Ord",  width="small"),
                "hex":     st.column_config.TextColumn("Hex",    width="small"),
                "utf8_bytes":st.column_config.TextColumn("UTF-8",width="small"),
            })
        st.download_button(
            "⬇ Download Char Report (CSV)",
            data=char_df.to_csv(index=False).encode("utf-8-sig"),
            file_name=f"special_chars_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv", key="char_dl",
        )

# ══════════════════════════════════════════════════════════════════════════════
# TAB 5 — ALS EXPLORER
# ══════════════════════════════════════════════════════════════════════════════
with tab5:
    if als_obj is None:
        st.info("Upload an ALS workbook and run QC to explore it here.")
    else:
        als_tab = st.radio("Explore", ["Checks","Fields","Forms","Codelists"],
                           horizontal=True, key="als_explorer_radio")
        if als_tab == "Checks":
            df_c = als_obj.checks.copy() if not als_obj.checks.empty else pd.DataFrame()
            if df_c.empty:
                st.warning("No checks loaded.")
            else:
                if "RuleType" in df_c.columns:
                    rt_opts = sorted(df_c["RuleType"].dropna().unique().tolist())
                    rt_sel  = st.multiselect("Rule Type", rt_opts, default=rt_opts, key="als_rt")
                    df_c    = df_c[df_c["RuleType"].isin(rt_sel)]
                cols = ["CheckID","Domain","TargetFormOID","TargetFieldOID",
                        "RuleType","Severity","Description","QueryMessage"]
                st.caption(f"{len(df_c):,} checks")
                st.dataframe(df_c[[c for c in cols if c in df_c.columns]],
                             use_container_width=True, height=480, hide_index=True)
        elif als_tab == "Fields":
            df_f = als_obj.fields.copy() if not als_obj.fields.empty else pd.DataFrame()
            cols = ["FormOID","FieldOID","Domain","IsRequired","Dictionary",
                    "IsDerived","IsHidden","CriticalRole","DataFormat"]
            st.caption(f"{len(df_f):,} fields")
            st.dataframe(df_f[[c for c in cols if c in df_f.columns]],
                         use_container_width=True, height=480, hide_index=True)
        elif als_tab == "Forms":
            df_frm = als_obj.forms.copy() if not als_obj.forms.empty else pd.DataFrame()
            st.caption(f"{len(df_frm):,} forms")
            st.dataframe(df_frm, use_container_width=True, height=380, hide_index=True)
        elif als_tab == "Codelists":
            codelists = getattr(als_obj, "codelists",
                        getattr(als_obj, "dictionaries", {})) or {}
            if not codelists:
                st.warning("No codelists loaded.")
            else:
                cl_name = st.selectbox("Dictionary", sorted(codelists.keys()), key="als_cl")
                if cl_name:
                    entries = codelists[cl_name]
                    if isinstance(entries, dict):
                        rows = [{"CodedValue": k, "DisplayLabel (UserDataString)": v}
                                for k, v in sorted(entries.items())]
                    else:
                        rows = [{"CodedValue": v} for v in sorted(entries)]
                    st.write(f"**{cl_name}** — {len(rows)} entries "
                             f"(both coded values and UserDataString are valid in raw data)")
                    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

# ══════════════════════════════════════════════════════════════════════════════
# TAB 6 — EXPORT
# ══════════════════════════════════════════════════════════════════════════════
with tab6:
    st.subheader("Export Results")

    exporter = IssueExporter(issues, catalog_df=catalog.to_dataframe() if catalog else None)

    ec1, ec2, ec3 = st.columns(3)

    with ec1:
        st.markdown("#### 📊 Excel (8 sheets, audit-ready)")
        st.caption(
            "Summary · All Issues · Critical · Major · Minor/Info · "
            "**Collapsed Issues** (>10 subjects → 1 row) · "
            "Form Heatmap · Rule Catalog"
        )
        try:
            with tempfile.TemporaryDirectory() as td:
                out = Path(td) / "qc_report.xlsx"
                exporter.to_excel(out)
                st.download_button(
                    "⬇ Download Excel",
                    data=out.read_bytes(),
                    file_name=f"qc_issues_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx",
                    mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    use_container_width=True,
                )
        except Exception as e:
            st.error(f"Excel error: {e}")

    with ec2:
        st.markdown("#### 📄 Issues CSV")
        st.download_button(
            "⬇ Download CSV",
            data=_df.to_csv(index=False).encode("utf-8-sig") if not _df.empty else b"",
            file_name=f"qc_issues_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv", use_container_width=True,
        )

    with ec3:
        st.markdown("#### 📋 Rule Catalog CSV")
        if catalog:
            st.download_button(
                "⬇ Download Rule Catalog",
                data=catalog.to_dataframe().to_csv(index=False).encode("utf-8-sig"),
                file_name="rule_catalog_v5.csv",
                mime="text/csv", use_container_width=True,
            )
