"""
qc/exporter.py  —  V3 Fixed
============================
Excel (7 sheets, colour-coded) / CSV / JSON exporter.

Excel sheets:
  Summary          — KPIs + rule-type breakdown
  All Issues       — full plain-English narrative
  Critical         — critical issues
  Major            — major issues
  Minor_Info       — minor + info
  Form Heatmap     — domain × severity pivot
  Rule Catalog     — all generated rules
"""
from __future__ import annotations
import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
import pandas as pd

from models.issue import QCIssue

logger = logging.getLogger(__name__)

_SEV_FILL   = {"Critical": "FFCCCC", "Major": "FFE5CC", "Minor": "FFFFCC", "Info": "CCE5FF"}
_HDR_FILL   = "1E3A5F"
_HDR_FONT   = "FFFFFF"


class IssueExporter:
    def __init__(self, issues: list[QCIssue],
                 catalog_df: Optional[pd.DataFrame] = None):
        self._issues  = issues
        self._catalog = catalog_df
        self._df: Optional[pd.DataFrame] = None

    @property
    def dataframe(self) -> pd.DataFrame:
        if self._df is None:
            self._df = pd.DataFrame([i.to_row() for i in self._issues]) \
                if self._issues else pd.DataFrame(columns=QCIssue.columns())
        return self._df

    # ── Excel ─────────────────────────────────────────────────────────────────

    def to_excel(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        try:
            from openpyxl import Workbook
        except ImportError:
            self.to_csv(str(path).replace(".xlsx", ".csv"))
            return

        wb  = Workbook()
        df  = self.dataframe

        # 1. Summary
        ws  = wb.active
        ws.title = "Summary"
        self._write_summary(ws, df)

        # 2-4. Issue sheets
        self._write_issues(wb, df, "All Issues")
        for sev in ["Critical", "Major"]:
            sub = df[df["severity"] == sev] if not df.empty else pd.DataFrame()
            if not sub.empty:
                self._write_issues(wb, sub, sev)
        minor_info = df[df["severity"].isin(["Minor", "Info"])] if not df.empty else pd.DataFrame()
        if not minor_info.empty:
            self._write_issues(wb, minor_info, "Minor_Info")

        # 5. Collapsed Issues (>10 unique subjects → 1 row per rule+domain+field)
        if not df.empty:
            self._write_collapsed(wb, df)

        # 6. Form Heatmap
        if not df.empty:
            self._write_heatmap(wb, df)

        # 7. Rule Catalog
        if self._catalog is not None and not self._catalog.empty:
            ws_cat = wb.create_sheet("Rule Catalog")
            self._write_df(ws_cat, self._catalog)

        wb.save(str(path))
        logger.info("Excel: %s", path)

    # ── sheet writers ──────────────────────────────────────────────────────────

    def _write_summary(self, ws, df):
        from openpyxl.styles import Font, PatternFill, Alignment
        from openpyxl.utils import get_column_letter

        now   = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        sev   = df["severity"].value_counts().to_dict() if not df.empty else {}
        total = len(df)

        ws.column_dimensions["A"].width = 38
        ws.column_dimensions["B"].width = 22

        # Title row
        title = ws.cell(1, 1, "ALS Clinical Data QC Report — V3")
        title.font = Font(bold=True, size=14, color=_HDR_FONT)
        title.fill = PatternFill("solid", fgColor=_HDR_FILL)
        ws.merge_cells("A1:B1")

        rows = [
            ("Generated at", now),
            ("Total Issues", total),
            ("", ""),
            ("SEVERITY SUMMARY", ""),
            ("Critical", sev.get("Critical", 0)),
            ("Major",    sev.get("Major",    0)),
            ("Minor",    sev.get("Minor",    0)),
            ("Info",     sev.get("Info",     0)),
        ]
        # Domain breakdown
        if not df.empty:
            rows += [("", ""), ("TOP DOMAINS", "")]
            for dom, cnt in df["domain"].value_counts().head(10).items():
                rows.append((dom, int(cnt)))

        for r_i, (lbl, val) in enumerate(rows, 2):
            ws.cell(r_i, 1, lbl)
            ws.cell(r_i, 2, val)
            if str(lbl).endswith("SUMMARY") or str(lbl) == "TOP DOMAINS":
                ws.cell(r_i, 1).font = Font(bold=True, color=_HDR_FONT)
                ws.cell(r_i, 1).fill = PatternFill("solid", fgColor="2C3E50")
            if lbl in _SEV_FILL:
                for c in [1, 2]:
                    ws.cell(r_i, c).fill = PatternFill("solid", fgColor=_SEV_FILL[lbl])

    def _write_issues(self, wb, df: pd.DataFrame, title: str) -> None:
        from openpyxl.styles import PatternFill, Font, Alignment
        from openpyxl.utils import get_column_letter

        # Reorder columns so plain-English narrative is prominent
        priority_cols = [
            "issue_id", "severity", "subject_id", "dataset", "domain",
            "form", "field", "observed_value", "expected_behavior",
            "clinical_explanation",  # ← plain-text narrative
            "rule_id", "als_reference", "visit", "record_index", "emitted_at"
        ]
        cols = [c for c in priority_cols if c in df.columns] + \
               [c for c in df.columns if c not in priority_cols]

        ws = wb.create_sheet(title[:31])
        if df.empty:
            ws.append(["No issues"])
            return

        ws.append(cols)
        for cell in ws[1]:
            cell.font = Font(bold=True, color=_HDR_FONT)
            cell.fill = PatternFill("solid", fgColor=_HDR_FILL)
            cell.alignment = Alignment(wrap_text=False)

        for _, row in df.iterrows():
            sev  = str(row.get("severity", ""))
            fill = PatternFill("solid", fgColor=_SEV_FILL.get(sev, "FFFFFF"))
            vals = [str(row[c])[:800] if pd.notna(row.get(c)) else "" for c in cols]
            ws.append(vals)
            for cell in ws[ws.max_row]:
                cell.fill = fill
                # Wrap the narrative column
                if cell.column == cols.index("clinical_explanation") + 1 if "clinical_explanation" in cols else -1:
                    cell.alignment = Alignment(wrap_text=True)

        # Column widths
        widths = {
            "issue_id": 16, "severity": 10, "subject_id": 14,
            "dataset": 12, "domain": 10, "form": 12, "field": 18,
            "observed_value": 25, "expected_behavior": 35,
            "clinical_explanation": 70,
            "rule_id": 22, "als_reference": 35,
        }
        for c_i, col in enumerate(cols, 1):
            ws.column_dimensions[get_column_letter(c_i)].width = widths.get(col, 18)

        ws.freeze_panes = "A2"
        ws.row_dimensions[1].height = 22

    def _write_collapsed(self, wb, df: pd.DataFrame) -> None:
        """
        Collapsed Issues sheet: when the same rule fires on >10 unique subjects,
        write one row with subjects collated into a dedicated column.
        Reduces noise for systemic issues while preserving full detail in other sheets.
        """
        ws = wb.create_sheet("Collapsed Issues")
        from openpyxl.styles import PatternFill, Font
        from openpyxl.utils import get_column_letter

        # Group by rule_id + domain + field
        group_cols = [c for c in ["rule_id","domain","field","expected_behavior",
                                  "clinical_explanation","als_reference"] if c in df.columns]
        agg = (
            df.groupby(group_cols, dropna=False)["subject_id"]
            .agg(["nunique", lambda x: list(x.dropna().unique())])
            .reset_index()
        )
        agg.columns = group_cols + ["unique_subjects", "all_subjects"]
        # Keep only rows where unique subject count > 10
        collapsed = agg[agg["unique_subjects"] > 10].copy()
        collapsed = collapsed.sort_values("unique_subjects", ascending=False)

        if collapsed.empty:
            ws.append(["No systemic issues (>10 subjects) found."])
            return

        # Build output rows: first 5 subjects collated, count shown
        out_cols = group_cols + ["unique_subject_count",
                                 "first_5_subjects", "all_subject_count"]
        ws.append(out_cols)
        for cell in ws[1]:
            cell.font = Font(bold=True, color=_HDR_FONT)
            cell.fill = PatternFill("solid", fgColor=_HDR_FILL)

        for _, row in collapsed.iterrows():
            subjs = row["all_subjects"]
            first5 = " | ".join(str(s) for s in subjs[:5])
            out_row = [row.get(c, "") for c in group_cols] +                       [int(row["unique_subjects"]), first5, len(subjs)]
            ws.append([str(v)[:500] if v is not None else "" for v in out_row])

        for c_i, col in enumerate(out_cols, 1):
            widths = {"rule_id":22,"domain":10,"field":18,
                      "expected_behavior":35,"clinical_explanation":50,
                      "als_reference":30,"unique_subject_count":10,
                      "first_5_subjects":50,"all_subject_count":10}
            ws.column_dimensions[get_column_letter(c_i)].width = widths.get(col, 20)
        ws.freeze_panes = "A2"

        # Summary note
        ws.append([])
        note = ws.cell(ws.max_row + 1, 1,
            f"Systemic rules: {len(collapsed)} rules fire on >10 subjects each. "
            f"Full detail is in 'All Issues' sheet.")
        note.font = Font(italic=True, color="666666")

    def _write_heatmap(self, wb, df: pd.DataFrame) -> None:
        ws   = wb.create_sheet("Form Heatmap")
        piv  = df.groupby(["domain", "severity"]).size().unstack(fill_value=0)
        for s in ["Critical", "Major", "Minor", "Info"]:
            if s not in piv.columns:
                piv[s] = 0
        piv["Total"] = piv.sum(axis=1)
        piv = piv.sort_values("Total", ascending=False).reset_index()
        self._write_df(ws, piv)

    def _write_df(self, ws, df: pd.DataFrame) -> None:
        from openpyxl.styles import PatternFill, Font
        from openpyxl.utils import get_column_letter

        ws.append(list(df.columns))
        for cell in ws[1]:
            cell.font = Font(bold=True, color=_HDR_FONT)
            cell.fill = PatternFill("solid", fgColor=_HDR_FILL)
        for _, row in df.iterrows():
            ws.append([str(v)[:500] if pd.notna(v) else "" for v in row])
        for c_i, col in enumerate(df.columns, 1):
            max_len = max(len(str(col)),
                          max((len(str(ws.cell(r, c_i).value or ""))
                               for r in range(1, min(ws.max_row + 1, 20))), default=0))
            ws.column_dimensions[get_column_letter(c_i)].width = min(max_len + 2, 60)

    # ── CSV / JSON ─────────────────────────────────────────────────────────────

    def to_csv(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.dataframe.to_csv(str(path), index=False, encoding="utf-8-sig")

    def to_json(self, path: str | Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(str(path), "w", encoding="utf-8") as f:
            json.dump([i.to_dict() for i in self._issues], f, indent=2, default=str)
